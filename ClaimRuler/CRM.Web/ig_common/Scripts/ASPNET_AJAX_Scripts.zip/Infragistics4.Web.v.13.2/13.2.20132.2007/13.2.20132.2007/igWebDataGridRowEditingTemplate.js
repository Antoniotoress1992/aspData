/*
* igWebDataGridRowEditingTemplate.js
* Version 13.2.20132.2007
* Copyright(c) 2001-2013 Infragistics, Inc. All Rights Reserved.
*/




$IG.RowEditingTemplate = function(obj, objProps, control, parentCollection, hierarchical)
{
	/// <summary locid="T:J#Infragistics.Web.UI.RowEditingTemplate">
	/// Edit row behavior object of the grid. 
	/// </summary>
	$IG.RowEditingTemplate.initializeBase(this, [obj, objProps, control, parentCollection]);

	this._container = this._grid._container;

	this._topCollection = this._grid.get_behaviors();

	this._templateId = this._get_clientOnlyValue("tid");
    this._hierarchical = hierarchical;
	




	this._dropDownZIndex = this._get_clientOnlyValue("ddzi");
	this._offCheckBoxUrl = this._get_clientOnlyValue("off");
	if (this._templateId)
	{
		this._templateDiv = $get(this._templateId);
		var buttonId = this._get_clientOnlyValue("okbtn");
		if (buttonId)
			this._okBtn = $get(buttonId);
		buttonId = this._get_clientOnlyValue("cbtn");
		if (buttonId)
			this._cancelBtn = $get(buttonId);
	}
	this._rowInEditMode = null;
	this._rowSelectors = null;
    this._offset = 0;
	




	this._enableAutomaticPositioning = true;
	
	this._onGridScrollLeftChangedHandler = Function.createDelegate(this, this._onScrollLeft);
	this._grid._gridUtil._registerEventListener(this._grid, "ScrollLeftChanged", this._onGridScrollLeftChangedHandler);
	
	if (this._hierarchical)
	{
		
        this._onRowCollapsingHandler = Function.createDelegate(this, this._onRowCollapsing);
		this._grid._gridUtil._registerEventListener(this._grid, "RowCollapsing", this._onRowCollapsingHandler);
        
        this._onRowExpandedHandler = Function.createDelegate(this, this._onRowExpanded);
		this._grid._gridUtil._registerEventListener(this._grid, "RowExpanded", this._onRowExpandedHandler);
		
        this._onRowPopulatingHandler = Function.createDelegate(this, this._onRowPopulating);
		this._grid._gridUtil._registerEventListener(this._grid, "RowPopulating", this._onRowPopulatingHandler);
		
        this._onRowCollapsedHandler = Function.createDelegate(this, this._onRowCollapsed);
		this._grid._gridUtil._registerEventListener(this._grid, "RowCollapsed", this._onRowCollapsedHandler);
        
        this._ancestorGrids = [];
        this._gridContainers = [];
        this._gridContainers[this._gridContainers.length] = this._grid._container;
	} 
    
	this._divs = [];
	var parentNode = this._hierarchical ? this._grid._get_mainGrid()._element.parentNode : this._grid._element.parentNode;
	this._onDivScrollHandler = Function.createDelegate(this, this._onDivScroll);
    while (parentNode && parentNode.tagName != "FORM" && parentNode.tagName != "BODY" && parentNode.tagName != "HTML")
	{
	    if (parentNode.tagName == "DIV")
	    {
	        this._divs[this._divs.length] = parentNode;
	        $addHandler(parentNode, 'scroll', this._onDivScrollHandler)
	    }
	    parentNode = parentNode.parentNode;
	}
}

$IG.RowEditingTemplate.prototype =
{
	
	get_editModeActions: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.RowEditingTemplate.editModeActions">
		/// Returns/sets the actions that will cause the grid to enter edit mode.
		/// </summary>
		/// <value type="Infragistics.Web.UI.RowEditModeActions"></value>
		return this._editModeActions;
	},

	get_dropDownBehavior: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.RowEditingTemplate.dropDownBehavior">
		/// Gets a reference to the dropdown behavior that the control uses when it is showing.
		/// </summary>
		/// <value type="Infragistics.Web.UI.DropDownBehavior"></value>
		return this._dropDownBehavior;
	},

	get_dropDownEnableAutomaticPositioning: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.RowEditingTemplate.dropDownEnableAutomaticPositioning">
		/// Gets a boolean value that will be passed to the dropdown framework to enable automatic positioning of the object.
		///</summary>
		///<value type="Boolean"></value>
		return this._enableAutomaticPositioning;
	},
	set_dropDownEnableAutomaticPositioning: function(val)
	{
		///<summary locid="P:J#Infragistics.Web.UI.RowEditingTemplate.dropDownEnableAutomaticPositioning">
		/// Sets a boolean value that will be passed to the dropdown framework to enable automatic positioning of the object.
		///</summary>
		///<param name="val" type="Boolean">The new value for automatic positioning of the row edit template.</param>
		this._enableAutomaticPositioning = val;
	},

	

	

	enterEditMode: function(row)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.RowEditingTemplate.enterEditMode">
		/// Causes the grid to enter edit mode on the specified row.
		/// </summary>
		/// <param name="row" type="Infragistics.Web.UI.GridRow">The row to enter edit mode.</param>
        
        
        if (this._grid._get_isAjaxCallInProgress())
            return;

        if (row._updated == $IG.RowUpdateStatus.AddedButDeleted || row._updated == $IG.RowUpdateStatus.Deleted)
            return;

        
		if (this._rowInEditMode != null)
		    this.__internalExitEditMode();

		if (this._hierarchical)
		{
		    var beh = this._grid._get_mainGrid()._get_lastRETGridBehavior();
		    if (beh)
		        beh.__internalExitEditMode(false);
            
            if (this._checkRETVisTimerId == null)
			    this._checkRETVisTimerId = setInterval(Function.createDelegate(this, this._checkRETisVisWHDG), 500);
		}

		if (typeof (Page_ClientValidate) != "undefined")
			Page_ClientValidate();

		var cellCount = row.get_cellCount();

		




		var cell = null;
		


		var cellIndexOffset = this._grid._get_cellIndexOffset();
		
		//var index = 0;
		for (var i = cellIndexOffset; i < cellCount + cellIndexOffset; i++)
		{
			

			cell = row._get_cellElementByIndex(row.get_element(), i);
			
			if (cell && cell.offsetHeight > 5 && cell.offsetWidth > 2)
				break;
			




			



			
			
			//if (!row.get_cell(index).get_column().get_hidden())
			//	break;
			//index++;
		}
		
		if (!cell)
			return;
		var cellPos = $util.getPosition(cell);

		// A.T. I don't know why the dropdown behavior is instantiated every time a RET is opened,
		// but it needs to be certainly disposed, otherwise all kinds of mess happens with the automatic position timers
		// apart from the DOM garbage 
		if (this._dropDownBehavior)
		{
			this._dropDownBehavior.dispose();
		}

		






        
		this._dropDownBehavior = null;
        if (this._hierarchical)
            this._dropDownBehavior = new $IG.DropDownBehavior(cell, false, this._grid._get_mainGrid()._element, true, true);
        else
            this._dropDownBehavior = new $IG.DropDownBehavior(cell, false, this._container, true, true);

		




		this._dropDownBehavior.set_enableAutomaticPositioning(this._enableAutomaticPositioning);
		
		if (this._hierarchical)
		{
            this._getParentGrids();
            if (this._gridContainers != null)
                this._dropDownBehavior.set_extraOuterContainers(this._gridContainers);
            
            
            this._dropDownBehavior.set_movingTargetAllowance(3);
		}

		







		if (!this._templateDiv)
		{
			throw Error.argumentNull("_templateDiv", "The Row Edit Template behavior could not find associated template for editing.  Please ensure a Template is defined for the behavior.");
		}
		this._dropDownBehavior.set_targetContainer(this._templateDiv);
		this._dropDownBehavior.set_enableAnimations(false);
		this._dropDownBehavior.set_visibleOnBlur(false);
		this._dropDownBehavior.set_zIndex(this._dropDownZIndex);
        
        this._onScrollLeft({force : true});

		this._dropDownBehavior.init();
        this._dropDownBehavior.set_visible(true);
        

		this._rowInEditMode = row;

		this._copyValuesToTemplate(row);

		this._setInputFocus(this._templateDiv);

        if (this._hierarchical)
            this._grid._get_mainGrid()._set_lastRETGridBehavior(this);
	},

	_setInputFocus: function(elem)
	{
		if (elem.offsetHeight == 0 || typeof (elem.childNodes) == "undefined")
			return false;
		for (var i = 0; i < elem.childNodes.length; i++)
		{
			var child = elem.childNodes[i];
			
			if (child.tagName == "TEXTAREA" || (child.tagName == "INPUT" && (child.type == "text" || child.type == "checkbox" || child.type == "button" || child.type == "password")))
			{
				try
				{
					child.focus();
					child.select();
				}
				catch (exc)
				{
				}
				return true;
			}
			if (this._setInputFocus(child))
				return true;
		}
		return false;
	},

	exitEditMode: function(saveChanges)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.RowEditingTemplate.exitEditMode">
		/// Causes the grid to exit edit mode.
		/// </summary>
		/// <param name="saveChanges" type="Boolean">Boolean indicating whether the changes in the edit row template must be saved to the row.</param>
		
		if (this._rowInEditMode != null)
		{
			








			this._dropDownBehavior.set_visible(false);

			if (saveChanges)
			{
			    this._copyValuesToRow(this._rowInEditMode);
                
                if (this._editing._batchUpdating)
				    this._editing._commitUpdates(false);
                else
				    this._editing.commit();
			}
            this._rowInEditMode = null;
            if (this._hierarchical)
            {
                this._grid._get_mainGrid()._set_lastRETGridBehavior(null);
                
                if (this._checkRETVisTimerId != null)
			        this._checkRETVisTimerId = clearInterval(this._checkRETVisTimerId);
            }
		}
	},

	get_isInEditMode: function(row)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.RowEditingTemplate.isInEditMode">
		/// Indicates whether the grid is in edit mode.
		/// Optional 'row' parameter helps to determine whether a specific row is in edit mode.
		/// </summary>
		/// <param name="row" type="Infragistics.Web.UI.GridRow" optional="true">Optional. WebDataGrid row object.</param>
		/// <returns type="Boolean"></returns>
		if (row == undefined)
			return (this._rowInEditMode != null);
		return (this._rowInEditMode == row);
	},
	

	
	_getParentGrids: function ()
	{
		

        if (this._foundParents || !this._hierarchical)
            return;
        this._foundParents = true;
		if (this._ancestorGrids == null)
			this._ancestorGrids = [];
		if (this._gridContainers == null)
			this._gridContainers = [];
		var parentRow = this._grid.get_parentRow();
		while (parentRow != null)
		{
			var grid = parentRow.get_grid();
            
            grid._gridUtil._registerEventListener(grid, "ScrollLeftChanged", this._onGridScrollLeftChangedHandler);
            
            grid._gridUtil._registerEventListener(grid, "PostBackStart", this._onpostnotify);
            
            grid._gridUtil._registerEventListener(grid, "RowExpanded", this._onRowExpandedHandler);
			this._ancestorGrids[this._ancestorGrids.length] = grid;
			this._gridContainers[this._gridContainers.length] = grid._container;
			parentRow = grid.get_parentRow();
		}
	},
    
	_onScrollLeft: function (args)
    {
        
        
        if (this._grid && (this._rowInEditMode || (args && args.force)))
        {
            var outerContainerPos = $util.getPosition(this._grid._container);
            if (this._dropDownBehavior)
            {
                var sourceLoc = $util.getPosition(this._dropDownBehavior.get_sourceElement(), true);
                
                if (this._hierarchical)
                {
                    var whdgContainerPos = $util.getPosition(this._grid._get_mainGrid()._element);
                    if (outerContainerPos.absX > whdgContainerPos.absX)
                        this._offset = sourceLoc.x > outerContainerPos.x ? 0 : parseInt(outerContainerPos.x - sourceLoc.x);
                    else
                        this._offset = sourceLoc.x > whdgContainerPos.x ? 0 : parseInt(whdgContainerPos.x - sourceLoc.x);
                }
                else
                    this._offset = sourceLoc.x > outerContainerPos.x ? 0 : parseInt(outerContainerPos.x - sourceLoc.x);
                this._dropDownBehavior.set_offsetX(this._offset);
                
                if (this._dropDownBehavior.get_visible() && this._dropDownBehavior.get_targetContainer().style.display != "none")
                {
                    this._dropDownBehavior.set_visible(false);
                    this._dropDownBehavior.set_visible(true);
                }
            }
        }
    },
	
	_onRowCollapsing: function (args)
    {
        var row = args.row;
        var retInEditMode = this._grid._get_mainGrid()._get_lastRETGridBehavior();
        if (retInEditMode != null)
        {
            var grid = retInEditMode._grid;
            var parentRow = null;
            if (row._get_rowType && row._get_rowType() == "GroupedRow")
            {
                parentRow = this._grid._gridUtil._getParentRowOfDescendent(grid);
                if (parentRow || this._grid == retInEditMode._grid)
                {
                    var startIdx = row.get_element().rowIndex;
                    var rowCollection = row._get_collectionOwner();
                    var endIdx;
                    if (row.get_index() < rowCollection.get_length() - 1)
                        endIdx = rowCollection.get_row(row.get_index() + 1).get_element().rowIndex;
                    else
                    {
                        var rows = $util.getRows(this._grid._elements["rows"]);
                        endIdx = (rows && rows.length ? rows.length : 0);
                    }
                    var parentRowIdx = parentRow ? (parentRow.get_element().rowIndex) : (retInEditMode._rowInEditMode.get_element().rowIndex);
                    if (startIdx < parentRowIdx && parentRowIdx < endIdx)
                    {
                        retInEditMode.__internalExitEditMode(false);
                    }
                }
            }
            else
            {
                parentRow = grid.get_parentRow();
                while (parentRow != null)
                {
                    if (parentRow == row)
                        break;
                    grid = parentRow.get_grid();
                    parentRow = grid.get_parentRow();
                }
                if (parentRow != null)
                    retInEditMode.__internalExitEditMode(false);
            }
        }
        
        if ($util.IsIE8 && row._get_rowType && row._get_rowType() == "GroupedRow")
            setTimeout($util.createDelegate(this._grid, this._grid._onResize, [{ 'clientHeight': this._grid._element.clientHeight }, false]), 0);
    },
	
    _onRowPopulating: function(args)
    {
        var beh = this._grid._get_mainGrid()._get_lastRETGridBehavior();
		if (beh)
		{
			beh.__internalExitEditMode(false);
			this._grid._get_mainGrid()._set_lastRETGridBehavior(null);
		} 
    },
    
    _onRowExpanded: function(args)
    {
        var row = args.row;
        var grid = row._owner;
        if (this._rowInEditMode)
        {
            var tdPos = $util.getPosition(this._dropDownBehavior.get_sourceElement());
            var tdBounds = Sys.UI.DomElement.getBounds(this._dropDownBehavior.get_sourceElement());
            var outerContainerBounds = Sys.UI.DomElement.getBounds(this._grid._get_mainGrid()._element);
			var outerContainerPos = $util.getLocation(this._grid._get_mainGrid()._element);
            if (tdPos.absY > outerContainerPos.y + outerContainerBounds.height)
            {
                setTimeout(Function.createDelegate(this, this._hideRET), $util.IsIE8 ? 300 : 0);
            }
            else if (this._grid == this._gridView)
            {
                var gridContainerBounds = Sys.UI.DomElement.getBounds(this._grid._container);
			    var gridContainerPos = $util.getLocation(this._grid._container);
                if (tdPos.absY > gridContainerPos.y + gridContainerBounds.height)
                    setTimeout(Function.createDelegate(this, this._hideRET), 0);
            }
        }
        
        if ($util.IsIE8 && row._get_rowType && row._get_rowType() == "GroupedRow")
            setTimeout($util.createDelegate(this._grid, this._grid._onResize, [{ 'clientHeight': this._grid._element.clientHeight }, false]), 0);
    },
    
    _onRowCollapsed: function(row)
    {
        if ($util.IsIE8)
            setTimeout($util.createDelegate(this._grid, this._grid._onResize, [{ 'clientHeight': this._grid._element.clientHeight }, false]), 0);
    },
    
    _checkRETisVisWHDG: function()
    {
        if (this._rowInEditMode)
        {
            var tdPos = $util.getPosition(this._dropDownBehavior.get_sourceElement());
            var tdBounds = Sys.UI.DomElement.getBounds(this._dropDownBehavior.get_sourceElement());
            var outerContainerBounds = Sys.UI.DomElement.getBounds(this._grid._get_mainGrid()._element);
			var outerContainerPos = $util.getLocation(this._grid._get_mainGrid()._element);
            if (tdPos.absY > outerContainerPos.y + outerContainerBounds.height)
            {
                setTimeout(Function.createDelegate(this, this._hideRET), 0);
            }
            else if (this._grid == this._gridView)
            {
                var gridContainerBounds = Sys.UI.DomElement.getBounds(this._grid._container);
			    var gridContainerPos = $util.getLocation(this._grid._container);
                if (tdPos.absY > gridContainerPos.y + gridContainerBounds.height)
                    setTimeout(Function.createDelegate(this, this._hideRET), 0);
            }
        }
    },
    _hideRET: function()
    {
        this._dropDownBehavior.set_visible(false);
        this._dropDownBehavior.set_visible(true);
        this._dropDownBehavior.get_targetContainer().style.display = "none";
        this._dropDownBehavior.get_targetContainer().style.visibility = "hidden";
    },
    
    _onDivScroll: function ()
    {
        this.__internalExitEditMode();
    },
	
	_onColumnResize: function(args)
	{
		this.__internalExitEditMode();
	},
	__internalEnterEditMode: function(row)
	{
		
		if (!row || this._grid._isAuxRow(row) || row._updated == $IG.RowUpdateStatus.AddedButDeleted || row._updated == $IG.RowUpdateStatus.Deleted)
            return;
		var args = this.__raiseClientEvent("TemplateOpening", $IG.CancelEditRowEventArgs, [this, row]);
		if (args == null || !args.get_cancel())
		{
			this.enterEditMode(row);
			this.__raiseClientEvent("TemplateOpened", $IG.EditRowEventArgs, [this, row]);
		}
	},

	__internalExitEditMode: function(saveChanges)
	{
		if (!this._rowInEditMode)
			return false;
		var args = this.__raiseClientEvent("TemplateClosing", $IG.CancelEditRowEventArgs, [this, this._rowInEditMode, saveChanges]);
		if (args == null || !args.get_cancel())
		{
			var row = this._rowInEditMode;
			this.exitEditMode(saveChanges);
			this.__raiseClientEvent("TemplateClosed", $IG.EditRowEventArgs, [this, row]);
			return args != null ? args.get_saveChanges() : false;
		}
		return false;
	},

	__createDelegate: function(instance, method, args)
	{
		return function()
		{
			return method.apply(instance, args);
		}
	},

	_onDblclickHandler: function(evnt)
	{
		this.__onMouseClickEvent(evnt, $IG.RowEditMouseClickAction.Double);
	},

	_onClickHandler: function(evnt)
	{
		this.__onMouseClickEvent(evnt, $IG.RowEditMouseClickAction.Single);
	},
	
	__onMouseClickEvent: function(evnt, mouseClickAction)
	{
		if (evnt.button == 0)
		{
			var cell = this._grid._gridUtil.getCellFromElem(evnt.target);
			var row = null;

			if (cell != null && this._editModeActions.get_mouseClick() == mouseClickAction && (!evnt.target.getAttribute('chkState') || !cell._column._editableCheckbox))
				row = cell.get_row();
			else if (cell == null && this._rowSelectors != null)
			{
				var selector = this._rowSelectors.getSelectorFromElement(evnt.target);
				if (selector != null && this._editModeActions.get_rowSelectorMouseClick() == mouseClickAction)
					row = this._grid._gridUtil.getRowFromCellElem(selector);
			}

			if (row != null)
				this.__internalEnterEditMode(row);
		}
	},

	_onKeydownHandler: function(evnt)
	{
		var key = evnt.keyCode;
		if (this._activation && this._rowInEditMode == null)
		{
			if (key == 113) // F2
			{
				if (this._editModeActions.get_enableF2())
				{
					var activeCell = this._activation.get_activeCell();
					if (activeCell != null)
						this.__internalEnterEditMode(activeCell.get_row());
				}
			}
		}
	},

	_onKeypressHandler: function(evnt)
	{
		if (this._editModeActions.get_enableOnKeyPress())
		{
			if (this._activation && this._rowInEditMode == null)
			{
				var key = evnt.charCode;
				if (key == Sys.UI.Key.esc || key == Sys.UI.Key.left || key == Sys.UI.Key.tab || key == Sys.UI.Key.up || key == Sys.UI.Key.right || key == Sys.UI.Key.down)
					return;

				var activeCell = this._activation.get_activeCell();
				if (activeCell != null)
				{
					this.__internalEnterEditMode(activeCell.get_row());
				}
			}
		}
	},

	_activeCellChanged: function(args)
	{
		









		if (args.cell)
		{
			var row = args.cell.get_row();
			if (this._editModeActions.get_enableOnActive())
			{
				if (!this.get_isInEditMode(row))
					this.__internalEnterEditMode(row);
			}
			else if (!this.get_isInEditMode(row))
				this.__internalExitEditMode();
		}
	},

	_onOKBtnClick: function(evnt)
	{
		var isvalid = true;
		if (typeof (Page_Validators) != "undefined")
		{
			for (var i = 0; i < Page_Validators.length && isvalid; i++)
				if ($util.isChild(this._templateDiv, Page_Validators[i]) && Page_Validators[i].getAttribute("isvalid") != null && !Page_Validators[i].getAttribute("isvalid"))
				isvalid = false;
		}
		if (isvalid)
			this.__internalExitEditMode(true);
	},

	_onCancelBtnClick: function(evnt)
	{
		this.__internalExitEditMode();
	},

	_copyValuesToTemplate: function(row)
	{
		for (var i = 0; i < row.get_cellCount(); i++)
		{
			var cell = row.get_cell(i);
			var colKey = cell.get_column().get_key();
			var binding = this._bindings._getObjectByAdr(colKey);
			if (binding)
			{
			    var jsSet = binding.get_javaScriptSetter();
			    if (jsSet.indexOf("_setTriStateImageValue") != -1)
			        jsSet = jsSet.replace("{value})", "{value}, \"" + this._offCheckBoxUrl + "\")");
				
				jsSet = $util.replace(jsSet, "{ClientID}", "\"" + binding.get_clientID() + "\"");
				jsSet = $util.replace(jsSet, "{UniqueID}", "\"" + binding.get_uniqueID() + "\"");
				jsSet = $util.replace(jsSet, "{value}", "cell.get_value()");
				try
				{
					eval(jsSet);
				}
				catch (e)
				{
					alert(e.name + ": " + e.description);
				}
			}
		}
	},

	_copyValuesToRow: function(row)
	{
		for (var i = 0; i < row.get_cellCount(); i++)
		{
			var cell = row.get_cell(i);
			var colKey = cell.get_column().get_key();
			var binding = this._bindings._getObjectByAdr(colKey);
			if (binding)
			{
				var jsGet = binding.get_javaScriptGetter();
				
				jsGet = $util.replace(jsGet, "{ClientID}", "\"" + binding.get_clientID() + "\"");
				jsGet = $util.replace(jsGet, "{UniqueID}", "\"" + binding.get_uniqueID() + "\"");
				try
				{
					cell.set_value(eval(jsGet));
				}
				catch (e)
				{
					alert(e.name + ": " + e.description);
				}
			}
		}
	},

	

	
	_initializeComplete: function()
	{
		this._rowSelectors = this._topCollection.getBehaviorFromInterface($IG.IRowSelectorsBehavior);
		this._activation = this._topCollection.getBehaviorFromInterface($IG.IActivationBehavior);
		if (this._activation)
			this._activation._addActiveCellChangedEventHandler(Function.createDelegate(this, this._activeCellChanged));
		this._editing = this._topCollection.getBehaviorFromInterface($IG.IEditingBehavior);

		






		this._containerDoubleClickHandler = Function.createDelegate(this, this._onDblclickHandler);
		this._grid._addElementEventHandler(this._container, "dblclick", this._containerDoubleClickHandler);
		this._containerClickHandler = Function.createDelegate(this, this._onClickHandler);
		this._grid._addElementEventHandler(this._container, "click", this._containerClickHandler);
		this._gridElementKeyDownHandler = Function.createDelegate(this, this._onKeydownHandler);
		this._grid._addElementEventHandler(this._grid._element, "keydown", this._gridElementKeyDownHandler);
		this._gridElementKeyPress = Function.createDelegate(this, this._onKeypressHandler);
		this._grid._addElementEventHandler(this._grid._element, "keypress", this._gridElementKeyPress);
		
		if (this._okBtn)
		{
			this._okBtnClick = Function.createDelegate(this, this._onOKBtnClick);
			this._grid._addElementEventHandler(this._okBtn, "click", this._okBtnClick);
		}
		if (this._cancelBtn)
		{
			this._cancelBtnClick = Function.createDelegate(this, this._onCancelBtnClick);
			this._grid._addElementEventHandler(this._cancelBtn, "click", this._cancelBtnClick);
		}

		this._onpostnotify = Function.createDelegate(this, this._onPostNotify);
		this._grid._gridUtil._registerEventListener(this._grid, "PostBackStart", this._onpostnotify);

		this._columnResizing = this._grid.get_behaviors().get_columnResizing();
		if (this._columnResizing)
		{
			this._resizingStartingHandler = Function.createDelegate(this, this._onColumnResize)
			this._columnResizing._addStartColumnResizingEventListener(this._resizingStartingHandler);
		}

        
        if (this._hierarchical)
        {
            this._mainGrid = this._grid._get_mainGrid();
            this._gridView = this._mainGrid.get_gridView();
		    this._grid._get_mainGrid().get_gridView()._gridUtil._registerEventListener(this._grid._get_mainGrid(), "PostBackStart", this._onpostnotify);
        }
	},

	_createObjects: function(objectManager)
	{
		$IG.RowEditingTemplate.callBaseMethod(this, "_createObjects", [objectManager]);
		this._editModeActions = new $IG.RowEditModeActions("RowEditModeActions", null, objectManager.get_objectProps(0), this);
		objectManager.register_object(0, this._editModeActions);
	},

	_createCollections: function(collectionsManager)
	{
		this._bindings = collectionsManager.register_collection(0, $IG.ObjectCollection);
		var collectionItems = collectionsManager._collections[0];
		for (var binding in collectionItems)
			this._bindings._addObject($IG.ClientBinding, null, binding);
	},

	_onPostNotify: function()
	{
		if (!this.get_isInEditMode())
			return;
		var row = this._rowInEditMode;
		var saveChanges = this.__internalExitEditMode();
		if (this.get_isInEditMode())
			return true;
		if (saveChanges)
			this._editing.conmmit();

	},
	
	dispose: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.RowEditingTemplate.dispose">
		/// Disposes of the Row Edit Template behavior.
		/// </summary>
		if (!this._grid)
			return;

		
		if (this._onGridScrollLeftChangedHandler)
		{
			this._grid._gridUtil._unregisterEventListener(this._grid, "ScrollLeftChanged", this._onGridScrollLeftChangedHandler);
            
            for (var x = 0; this._ancestorGrids && x < this._ancestorGrids.length; ++x)
            {
                this._ancestorGrids[x]._gridUtil._unregisterEventListener(this._ancestorGrids[x], "ScrollLeftChanged", this._onGridScrollLeftChangedHandler);
                
                this._ancestorGrids[x]._gridUtil._unregisterEventListener(this._ancestorGrids[x], "PostBackStart", this._onpostnotify);
                
                this._ancestorGrids[x]._gridUtil._unregisterEventListener(this._ancestorGrids[x], "RowExpanded", this._onRowExpandedHandler);
            }
            delete this._onGridScrollLeftChangedHandler;
		}
        
        if (this._onRowCollapsingHandler)
        {
            this._grid._gridUtil._unregisterEventListener(this._grid, "RowCollapsing", this._onRowCollapsingHandler);
            delete this._onRowCollapsingHandler;
        }
		
        if (this._onRowPopulatingHandler)
        {
            this._grid._gridUtil._unregisterEventListener(this._grid, "RowPopulating", this._onRowPopulatingHandler);
            delete this._onRowPopulatingHandler;
        }
        
        if (this._onRowExpandedHandler)
        {
            this._grid._gridUtil._unregisterEventListener(this._grid, "RowExpanded", this._onRowExpandedHandler);
            delete this._onRowExpandedHandler;
        }
        
        if (this._onRowCollapsedHandler)
        {
            this._grid._gridUtil._unregisterEventListener(this._grid, "RowCollapsed", this._onRowCollapsedHandler);
            delete this._onRowCollapsedHandler;
        }
        if (this._ancestorGrids)
        {
            for (var x = 0; x < this._ancestorGrids.length; ++x)
                this._ancestorGrids[x] = null;
            delete this._ancestorGrids;
        }
        if (this._gridContainers)
        {
            for (var x = 0; x < this._gridContainers.length; ++x)
                this._gridContainers[x] = null;
            delete this._gridContainers;
        }
        
        if (this._checkRETVisTimerId != null)
            this._checkRETVisTimerId = clearInterval(this._checkRETVisTimerId);
        
        delete this._topCollection;
		delete this._ancestorGrids;
        
        if (this._onDivScrollHandler)
        {
            for (var x = 0; this._divs && x < this._divs.length; ++x)
            {
				
				if (this._divs[x] && this._divs[x]._events && this._divs[x]._events.scroll && this._divs[x]._events.scroll.length > 0)
					$removeHandler(this._divs[x], 'scroll', this._onDivScrollHandler);
                this._divs[x] = null;
            }
            delete this._divs;
            delete this._onDivScrollHandler;
        }
        delete this._rowInEditMode;
	    delete this._rowSelectors;
        delete this._offset;
        
		if (this._columnResizing)
		{
			this._grid._gridUtil._unregisterEventListener(this._columnResizing, "StartColumnResizing", this._resizingStartingHandler);
			this._resizingStartingHandler = null;
			delete this._columnResizing;
		}
        delete this._foundParents;
        
        if (this._dropDownBehavior)
        {
            this._dropDownBehavior.dispose();
        }
		
		if (this._templateId)
		{
			this._grid._removeElementEventHandler(this._container, "click", this._containerClickHandler);
			this._grid._removeElementEventHandler(this._container, "dblclick", this._containerDoubleClickHandler);
			this._grid._removeElementEventHandler(this._grid._element, "keydown", this._gridElementKeyDownHandler);
			this._grid._removeElementEventHandler(this._grid._element, "keypress", this._gridElementKeyPress);
			if (this._okBtnClick)
				this._grid._removeElementEventHandler(this._okBtn, "click", this._okBtnClick);
			if (this._cancelBtnClick)
				this._grid._removeElementEventHandler(this._cancelBtn, "click", this._cancelBtnClick);
			this._grid._gridUtil._unregisterEventListener(this._grid, "PostBackStart", this._onpostnotify);
            
            if (this._hierarchical)
            {
                this._gridView._gridUtil._unregisterEventListener(this._mainGrid, "PostBackStart", this._onpostnotify);
			    delete this._gridView;
                delete this._mainGrid;
            }
            this._onpostnotify = null;
			







			









			
			if (this._templateDiv && this._templateDiv.parentNode)
            {
                
                if (this._grid && this._grid._element && this._grid._element.parentNode)
                {
					
                    if (this._hierarchical)
					{
						this._templateDiv.parentNode.removeChild(this._templateDiv);
						if (this._grid == this._grid._get_mainGrid().get_gridView())
							this._grid._get_mainGrid()._element.appendChild(this._templateDiv);
						else
							this._grid._element.parentNode.appendChild(this._templateDiv);
					}
					else
					{
						this._templateDiv.parentNode.removeChild(this._templateDiv);
						this._grid._element.appendChild(this._templateDiv);
					}
                    





                }
                




            }
		}
        delete this._hierarchical;
		if (!Sys.Application._disposing)
		{
			this._editModeActions.dispose();
			this._editModeActions = null;
		}
		$IG.RowEditingTemplate.callBaseMethod(this, "dispose");
	}
	
}

$IG.RowEditingTemplate.registerClass('Infragistics.Web.UI.RowEditingTemplate', $IG.GridBehavior);




$IG.EditRowProps = new function()
{	
	var count = $IG.GridBehaviorProps.Count;
	/// <summary>
	/// The number of properties on the EditRow client side object model to be stored in client object.
	/// </summary>
	this.Count = count;
};



$IG.RowEditMouseClickAction = function()
{
	/// <summary locid="T:J#Infragistics.Web.UI.RowEditMouseClickAction">
	/// The enumeration defines mouse action that enters the row into edit mode.
	/// </summary>
	/// <field name="None" type="Number" integer="true" static="true">
	/// No editing should be started when a row is clicked.
	/// </field>
	/// <field name="Single" type="Number" integer="true" static="true">
	/// Edit mode should be entered on a single mouse click.
	/// </field>
	/// <field name="Double" type="Number" integer="true" static="true">
	/// Edit mode should be entered on a double mouse click.
	/// </field>
}
$IG.RowEditMouseClickAction.prototype =
{
	None: 0,
	Single: 1,
	Double: 2
};
$IG.RowEditMouseClickAction.registerEnum("Infragistics.Web.UI.RowEditMouseClickAction");



$IG.RowEditModeActionsProps = new function()
{
	this.MouseClick = [$IG.ObjectBaseProps.Count + 0, $IG.RowEditMouseClickAction.None];
	this.EnableF2 = [$IG.ObjectBaseProps.Count + 1, false];
	this.EnableOnActive = [$IG.ObjectBaseProps.Count + 2, false];
	this.EnableOnKeyPress = [$IG.ObjectBaseProps.Count + 3, false];
	this.RowSelectorMouseClick = [$IG.ObjectBaseProps.Count + 4, $IG.RowEditMouseClickAction.Double];
	this.Count = $IG.ObjectBaseProps.Count + 5;
};



$IG.RowEditModeActions = function(obj, element, props, control)
{
	/// <summary locid="T:J#Infragistics.Web.UI.RowEditModeActions">
	/// The object contains actions that will cause a row to enter edit mode. Inherited from the EditModeActions object.
	/// </summary>
	var csm = obj ? new $IG.ObjectClientStateManager(props[0]) : null;
	$IG.RowEditModeActions.initializeBase(this, [obj, element, props, control, csm]);
}

$IG.RowEditModeActions.prototype =
{
	get_mouseClick: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.RowEditModeActions.mouseClick">
		/// Gets/sets the value determining whether single clicks, or double clicks
		/// will cause the grid to enter edit mode.
		/// </summary>
		/// <value type="Infragistics.Web.UI.RowEditMouseClickAction"></value>
		return this._get_value($IG.RowEditModeActionsProps.MouseClick);
	},
	set_mouseClick: function(value)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.RowEditModeActions.mouseClick">
		/// Sets the value determining whether single clicks, or double clicks
		/// will cause the grid to enter edit mode.
		/// </summary>
		/// <param name="value" type="Infragistics.Web.UI.RowEditMouseClickAction">The new cell mouse click action to open the edit template.</param>
		this._set_value($IG.RowEditModeActionsProps.MouseClick, value);
	},

	get_enableF2: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.RowEditModeActions.enableF2">
		/// Gets/sets the value determining whether keying F2
		/// will cause the grid to enter edit mode.
		/// </summary>
		/// <value type="Boolean"></value>
		return this._get_value($IG.RowEditModeActionsProps.EnableF2, true);
	},
	set_enableF2: function(value)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.RowEditModeActions.enableF2">
		/// Gets/sets the value determining whether keying F2
		/// will cause the grid to enter edit mode.
		/// </summary>
		/// <param name="value" type="Boolean">The new enter edit move on F2 press.</param>
		this._set_value($IG.RowEditModeActionsProps.EnableF2, value);
	},

	get_enableOnActive: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.RowEditModeActions.enableOnActive">
		/// Gets/sets the value determining whether the grid will enter edit mode
		/// upon a cell being activated.
		/// </summary>
		/// <value type="Boolean"></value>
		return this._get_value($IG.RowEditModeActionsProps.EnableOnActive, true);
	},
	set_enableOnActive: function(value)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.RowEditModeActions.enableOnActive">
		/// Gets/sets the value determining whether the grid will enter edit mode
		/// upon a cell being activated.
		/// </summary>
		/// <param name="value" type="Boolean">The new enter edit move on cell activation.</param>
		this._set_value($IG.RowEditModeActionsProps.EnableOnActive, value);
	},

	get_enableOnKeyPress: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.RowEditModeActions.enableOnKeyPress">
		/// Gets/sets the value determining whether the grid will enter edit mode
		/// when a cell is active and a key is pressed.
		/// </summary>
		/// <value type="Boolean"></value>
		return this._get_value($IG.RowEditModeActionsProps.EnableOnKeyPress, true);
	},
	set_enableOnKeyPress: function(value)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.RowEditModeActions.enableOnKeyPress">
		/// Gets/sets the value determining whether the grid will enter edit mode
		/// when a cell is active and a key is pressed.
		/// </summary>
		/// <param name="value" type="Boolean">The new enter edit move on key press.</param>
		this._set_value($IG.RowEditModeActionsProps.EnableOnKeyPress, value);
	},

	get_rowSelectorMouseClick: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.RowEditModeActions.rowSelectorMouseClick">
		/// Gets/sets the value determining whether single clicks, or double clicks on the row selectors
		/// will cause the grid to enter edit mode.
		/// </summary>
		/// <value type="Infragistics.Web.UI.RowEditMouseClickAction"></value>
		return this._get_value($IG.RowEditModeActionsProps.RowSelectorMouseClick);
	},
	set_rowSelectorMouseClick: function(value)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.RowEditModeActions.rowSelectorMouseClick">
		/// Gets/sets the value determining whether single clicks, or double clicks on the row selectors
		/// will cause the grid to enter edit mode.
		/// </summary>
		/// <param name="value" type="Infragistics.Web.UI.RowEditMouseClickAction">The new row selector mouse click action to open the edit template.</param>
		this._set_value($IG.RowEditModeActionsProps.RowSelectorMouseClick, value);
	}
}

$IG.RowEditModeActions.registerClass('Infragistics.Web.UI.RowEditModeActions', $IG.ObjectBase);



$IG.ClientBinding = function(adr, element, props, owner, csm)
{
	/// <summary locid="T:J#Infragistics.Web.UI.ClientBinding">
	/// The object contains definition of a client binding that binds a control to a row's cell.
	/// </summary>
	$IG.ClientBinding.initializeBase(this, [adr, element, props, owner, csm]);
}

$IG.ClientBinding.prototype =
{
	get_columnKey: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ClientBinding.columnKey">
		/// Column key of the cell that is bound using this object.
		/// </summary>
		/// <value type="String"></value>
		return this._get_value($IG.ClientBindingProps.ColumnKey);
	},

	get_controlID: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ClientBinding.controlID">
		/// Server ID of the control the cell is bound to.
		/// </summary>
		/// <value type="String"></value>
		return this._get_value($IG.ClientBindingProps.ControlID);
	},

	get_clientID: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ClientBinding.clientID">
		/// Client ID of the control the cell is bound to.
		/// </summary>
		/// <value type="String"></value>
		return this._get_clientOnlyValue("cid");
	},

	get_uniqueID: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ClientBinding.uniqueID">
		/// Unique ID of the control the cell is bound to.
		/// </summary>
		/// <value type="String"></value>
		return this._get_clientOnlyValue("uid");
	},

	get_javaScriptGetter: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ClientBinding.javaScriptGetter">
		/// Java Script string that should be evaluated and used to get a value from the bound control.
		/// </summary>
		/// <value type="String"></value>
		return this._get_value($IG.ClientBindingProps.GetValueJavaScript);
	},

	get_javaScriptSetter: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ClientBinding.javaScriptSetter">
		/// Java Script string that should be evaluated and used to set a value to the bound control.
		/// </summary>
		/// <value type="String"></value>
		return this._get_value($IG.ClientBindingProps.SetValueJavaScript);
	}
}
$IG.ClientBinding.registerClass('Infragistics.Web.UI.ClientBinding', $IG.ObjectBase);



$IG.ClientBindingProps = new function()
{
	var count = $IG.ObjectBaseProps.Count;
	this.ColumnKey = [count++, ""];
	this.ControlID = [count++, ""];
	this.GetValueJavaScript = [count++, ""];
	this.SetValueJavaScript = [count++, ""];
	this.Count = count;
};




$IG.CancelEditRowEventArgs = function(params)
{
	/// <summary locid="T:J#Infragistics.Web.UI.CancelEditRowEventArgs">
	/// Event arguments object that is passed into the TemplateOpening and TemplateClosing event handlers. Provides an option to cancel the events.
	/// </summary>
	$IG.CancelEditRowEventArgs.initializeBase(this);
	this._editRowBehavior = params[0];
	this._row = params[1];
	this._saveChanges = (params[2] === true);
}
$IG.CancelEditRowEventArgs.prototype =
{
	get_editRowBehavior: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.CancelEditRowEventArgs.editRowBehavior">
		/// Returns the edit row template behavior.
		/// </summary>
		/// <value type="Infragistics.Web.UI.RowEditingTemplate"></value>
		return this._editRowBehavior;
	},
	get_row: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.CancelEditRowEventArgs.row">
		/// Returns the row that is being edited.
		/// </summary>
		/// <value type="Infragistics.Web.UI.GridRow"></value>
		return this._row;
	},
	get_saveChanges: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.CancelEditRowEventArgs.saveChanges">
		/// Boolean. Indicates whether the template changes are being saved.
		/// </summary>
		/// <value type="Boolean"></value>
		return this._saveChanges;
	}
}
$IG.CancelEditRowEventArgs.registerClass('Infragistics.Web.UI.CancelEditRowEventArgs', $IG.CancelEventArgs);


$IG.EditRowEventArgs = function(params)
{
	/// <summary locid="T:J#Infragistics.Web.UI.EditRowEventArgs">
	/// Event arguments object that is passed into the TemplateOpened and TemplateClosed event handlers.
	/// </summary>
	$IG.EditRowEventArgs.initializeBase(this);
	this._editRowBehavior = params[0];
	this._row = params[1];
	this._saveChanges = (params[2] === true);
}
$IG.EditRowEventArgs.prototype =
{
	get_editRowBehavior: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.EditRowEventArgs.editRowBehavior">
		/// Returns the edit row template behavior.
		/// </summary>
		/// <value type="Infragistics.Web.UI.RowEditingTemplate"></value>
		return this._editRowBehavior;
	},
	get_row: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.EditRowEventArgs.row">
		/// Returns the row that is being edited.
		/// </summary>
		/// <value type="Infragistics.Web.UI.GridRow"></value>
		return this._row;
	},
	get_saveChanges: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.EditRowEventArgs.saveChanges">
		/// Boolean. Indicates whether the template changes are being saved.
		/// </summary>
		/// <value type="Boolean"></value>
		return this._saveChanges;
	}
}
$IG.EditRowEventArgs.registerClass('Infragistics.Web.UI.EditRowEventArgs', $IG.EventArgs);


function _setTriStateImageValue(checkBox, value)
{
    if (checkBox == null || !checkBox.setAttribute)
        return;
    if (arguments[2] != null)
        checkBox.setAttribute("src", arguments[2]);
    if (value == null)
    {
        checkBox.setAttribute("src", checkBox.getAttribute("src").replace("off.gif", "partial.gif"));
        var alt = "Partial";
        checkBox.setAttribute("alt", alt);
        checkBox.setAttribute("title", alt);
        checkBox.setAttribute("chkState", 2);
    }
    else if (value == true)
    {
        checkBox.setAttribute("src", checkBox.getAttribute("src").replace("off.gif", "on.gif"));
        var alt = "True";
        checkBox.setAttribute("alt", alt);
        checkBox.setAttribute("title", alt);
        checkBox.setAttribute("chkState", 1);
    }
    else
    {
        checkBox.setAttribute("src", checkBox.getAttribute("src").replace("off.gif", "off.gif"));
        var alt = "False";
        checkBox.setAttribute("alt", alt);
        checkBox.setAttribute("title", alt);
        checkBox.setAttribute("chkState", 0);
    }
}

function _triStateImageClick(checkBox)
{
    if (checkBox && checkBox.getAttribute)
    {
        var chkState = parseInt(checkBox.getAttribute("chkState"));
        if (chkState == 1 || chkState == 2)
        {
        	var url = "";
            if (chkState == 1)
                url = "on.gif";
            else
                url = "partial.gif";
            checkBox.setAttribute("src", checkBox.getAttribute("src").replace(url, "off.gif"));
            checkBox.setAttribute("alt", "False");
            checkBox.setAttribute("title", "False");
            checkBox.setAttribute("chkState", 0);
        }
        else
        {
            checkBox.setAttribute("src", checkBox.getAttribute("src").replace("off.gif", "on.gif"));
            checkBox.setAttribute("alt", "True");
            checkBox.setAttribute("title", "True");
            checkBox.setAttribute("chkState", 1);
        }
    }
}

function _getTriStateImageValue(checkBox)
{
    if (checkBox && checkBox.getAttribute)
    {
        var chkState = parseInt(checkBox.getAttribute("chkState"));
        if (chkState == 0)
            return false;
        else if (chkState == 1)
            return true;
        else
            return null;
    }
    return null;
}
