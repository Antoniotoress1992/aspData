/*
* igWebDataGridEditorProviders.js
* Version 13.2.20132.2007
* Copyright(c) 2001-2013 Infragistics, Inc. All Rights Reserved.
*/




$IG.SliderProvider = function(adr, element, props, owner, csm)
{
	/// <summary locid="T:J#Infragistics.Web.UI.SliderProvider">
	/// The object defines the WebSlider editor provider for a column. 
	/// Overrides the EditorProvider object.
	/// </summary>
	if (!element)
		return;
	var i = -1, nodes = element.childNodes;
	
	while (++i < nodes.length)
	{
		if (nodes[i].nodeName != 'DIV')
			continue;
		var id = nodes[i].id;
		if (!$util.isEmpty(id))
			if (this._editor = $find(id))
			break;
		if (nodes[i].getAttribute("_wrapper"))
		{
			this._wrapper = nodes[i];
			nodes = nodes[i].childNodes;
			i = -1;
		}
	}
	if (!this._editor)
		return;

	$IG.SliderProvider.initializeBase(this, [adr, element, props, owner, csm]);
	this._input = this._editor._input;
}

$IG.SliderProvider.prototype =
{
	get_value: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.SliderProvider.value">
		/// Overrides the EditorProvider object's property.
		/// Gets/sets the value to/from the underlying slider. 
		/// </summary>
		/// <value type="Number">Current value in editor.</value>
		var val = this._editor ? this._editor.get_value() : this._old;
		return this._areEqual(val, this._old) ? this._old0 : val;
	},
	set_value: function(val)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.SliderProvider.value">Sets initial value in editor.</summary>
		/// <param name="val" type="Number">Value for editor.</param>
		
		
		this._old0 = this._old = val;
		var editor = this._editor;
		if (!editor)
			return;
		editor.set_value(val);
		this._old = editor.get_value();
	},
	
	_onMouse: function(e)
	{
		var elem = e ? e.target : null;
		if (!elem)
			return;
		
		while ((elem = elem.parentNode) != null)
			if (elem == this._element)
			return;
		
		this.notifyLostFocus(e);
	},
	
	_removeHandlers: function()
	{
		if (this._onMouseFn && this._hasLsnr && this._grid)
			$removeHandler(this._grid, 'mousedown', this._onMouseFn);
		this._grid = null;
		$IG.SliderProvider.callBaseMethod(this, '_removeHandlers');
	},
	
	_show: function(top, left, width, height, cssClass, parent, cell)
	{
		var elem = this._element, slider = this._editor._element;
		
		slider.style.visibility = 'hidden';
		var wrapper = this._getWrapper(slider, cssClass);
		this._setBounds(top, left, height, elem.style, parent, cell, wrapper);
		wrapper.style.width = slider.offsetWidth + 'px';
		slider.style.visibility = 'visible';
		this._focus(this._input);
		if (this._hasLsnr)
			return;
		this._addHandlers();
		
		if (this._grid)
			elem = this._grid;
		else
		{
			
			while ((elem = elem.parentNode) != null)
			{
				var id = elem.id;
				if (id && elem.nodeName == 'DIV' && id.length > 1 && id.charAt(0) != ':')
					break;
			}
			if (!elem)
				return;
			
			this._grid = elem;
		}
		if (!this._onMouseFn)
			this._onMouseFn = Function.createDelegate(this, this._onMouse);
		$addHandler(elem, 'mousedown', this._onMouseFn);
	}
}

$IG.SliderProvider.registerClass('Infragistics.Web.UI.SliderProvider', $IG.EditorProvider);



$IG.TextEditorProvider = function(adr, element, props, owner, csm)
{
	/// <summary locid="T:J#Infragistics.Web.UI.TextEditorProvider">
	/// The object defines the WebTextEditor editor provider for a column. 
	/// Overrides the EditorProvider object.
	/// </summary>
	if (!element)
		return;
	
	var i = -1, id = null, suffix = '_clientState', nodes = element.childNodes;
	
	while (++i < nodes.length)
	{
		id = nodes[i];
		id = (id.nodeName == 'INPUT') ? id.id : null;
		var len = id ? id.length : 0;
		if (len > 15 && id.indexOf(suffix) > len - 13)
		{
			this._editor = $find(id.substring(0, len - suffix.length));
			break;
		}
	}
	if (!this._editor)
		return;
	$IG.TextEditorProvider.initializeBase(this, [adr, element, props, owner, csm]);
	this._input = this._editor._elem;
	
	this._editor._inGrid = true;
}

$IG.TextEditorProvider.prototype =
{
	get_value: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.TextEditorProvider.value">
		/// Overrides the EditorProvider's function.
		/// </summary>
		/// <value type="String">Current value in editor.</value>
		var val = this._editor ? this._editor.get_value() : this._old;
		return this._areEqual(val, this._old) ? this._old0 : val;
	},
	set_value: function (val)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.TextEditorProvider.value">Sets initial value in editor.</summary>
		/// <param name="val" type="String">Value for editor.</param>
		
		
		this._old0 = this._old = val;
		var editor = this._editor;
		if (!editor)
			return;
		editor.set_value(val);
		this._old = editor.get_value();
		
		
		editor._gridKey = this._charKey || -1;
	},
	_show: function (top, left, width, height, cssClass, parent, cell)
	{
		var editor = this._editor;
		var elem = editor._element, wrapper = null, borderWidth = 0, input = editor._elem;
		
		var css0 = editor._ep_css, oldIW = '';
		if (!css0)
			css0 = editor._ep_css = editor._css[0];
		
		editor._css = editor._cssI = null;
		
		
		if (elem.nodeName == 'TABLE')
		{
			
			input.parentNode.className = elem.className = '';
			wrapper = this._getWrapper(elem, cssClass);
			
			css0 = input.className;
			input.className += ' ' + cssClass;
			var style = input.style, rs = $util.getRuntimeStyle(input);
			style.color = $util.getStyleValue(rs, 'color');
			style.fontStyle = $util.getStyleValue(rs, 'fontStyle');
			style.fontWeight = $util.getStyleValue(rs, 'fontWeight');
			style.fontSize = $util.getStyleValue(rs, 'fontSize');
			style.fontFamily = $util.getStyleValue(rs, 'fontFamily');
			
			if (this._oldIW)
				style.width = this._oldIW;
			
			oldIW = $util.getStyleValue(rs, 'width');
			
			input.className = css0;
			
			borderWidth = $util.toIntPX(null, 'borderTopWidth', 0, wrapper) * 2;
			width -= borderWidth;
			height -= borderWidth;
		}
		else
		
			elem.className = css0 + ' ' + cssClass;
		
		
		this._setBounds(top, left, height, this._element.style, parent, cell);
		editor._fixSize(width + 'px', height + 'px');
		this._addHandlers();
		var shiftW = elem.offsetWidth - width, shiftH = elem.offsetHeight - height, w = width;
		if (wrapper && this._shared)
			shiftW = 0;
		
		if (shiftH > 4)
			shiftH = 0;
		if (shiftW > 0 || shiftH > 0)
			if ((w -= shiftW) > 5 && (height -= shiftH) > 5)
				editor._fixSize(w + 'px', height + 'px');
		
		var heightOffsetDiff = cell.get_element().offsetHeight - elem.offsetHeight;
		if ($util.IsChrome || $util.IsSafari && heightOffsetDiff < 0)		
			editor._fixSize(w + 'px', (height + heightOffsetDiff + ($util.IsChrome ? 1 : 0)) + 'px');
			
		if (wrapper)
		{
			
			if ((w = elem.offsetWidth) > width + 2 && (shiftW = input.offsetWidth) > 20)
			{
				
				if ((w = width - w + shiftW) < 5)
					w = 15;
				
				this._oldIW = oldIW;
				input.style.width = w + 'px';
			}
			
			wrapper.style.width = (this._shared ? width : elem.offsetWidth) + 'px';
		}
		this._focus(input);
	}
}
$IG.TextEditorProvider.registerClass('Infragistics.Web.UI.TextEditorProvider', $IG.EditorProvider);



$IG.DropDownProvider = function (adr, element, props, owner, csm)
{
	/// <summary locid="T:J#Infragistics.Web.UI.DropDownProvider">
	/// The object defines the WebDropDown editor provider for a column. 
	/// Overrides the EditorProvider object.
	/// </summary>
	if (!element)
		return;
	this._grid = owner;
	var controlElem = element.firstChild;
	while (controlElem && (typeof (controlElem.tagName) == "undefined" || controlElem.tagName != "DIV"))
		controlElem = controlElem.nextSibling;
	this._editor = $find(controlElem.id);
	if (!this._editor)
		return;
	$IG.DropDownProvider.initializeBase(this, [adr, element, props, owner, csm]);
	
	if (this._editor.behavior && (this._editor.get_dropDownOrientation() == $IG.DropDownPopupPosition.Default || this._editor.get_dropDownOrientation() == $IG.DropDownPopupPosition.BottomLeft))
		this._editor.behavior.set_enableAutomaticPositioning(true);
	this._dropDown = this._editor._elements.DropDown;
	this._input = this._editor._elements.Input;
	this._stretchHeight = this._get_clientOnlyValue("sh");
	this._verticalAlign = this._get_clientOnlyValue("va");

	
	this._onInternalDropDownOpeningHandler = Function.createDelegate(this, this._onInternalDropDownOpening);
	this._editor._registerEventListener(this._editor, "InternalDropDownOpening", this._onInternalDropDownOpeningHandler);
}

$IG.DropDownProvider.prototype =
{
	get_value: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.DropDownProvider.value">
		/// Overrides the EditorProvider object's property.
		/// Gets/sets the value to/from the underlying drop down. 
		/// </summary>
		/// <value type="Object">Current value in editor.</value>
		var item = this._editor.get_selectedItem();
		
		var val = item && !this._useTxt ? item.get_value() : null;
		if (val == null && item)
			val = item.get_text();
		if (val == null || val === '')
			val = this._editor.get_currentValue();
		
		var initVal = this._initValue;
		if (initVal && initVal.val === val)
			return initVal.cell; 
		return val;
	},
	set_value: function (val)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.DropDownProvider.value">Sets initial value in editor.</summary>
		/// <param name="val" type="Object">Value for editor.</param>
		var editor = this._editor;
		
		delete this._useTxt;
		
		delete this._initValue;
		if (!editor)
			return;

		var item = editor.get_selectedItem(), cellVal = val;
		if (item)
		{
			
			item.inactivate();
			item.unselect();
			editor.set_selectedItemIndex(-1);
			editor.set_activeItemIndex(-1);
			editor._activeItem = null;
			editor.set_currentValue("");
		}
		
		if (this._editor.get_displayMode() > 1)
			this._charKey = null;
		
		if (this._charKey)
		{
			
			editor.__inKeyUp = false;
			return;
		}
		var items = editor.get_items();
		var i = (val == null || val === '') ? -1 : items.getLength();

		

		var valType = typeof (val);
		var compareVal = val;
		if (valType == "boolean")
			compareVal = (val ? "True" : "False");
		
		while (i-- > 0)
		{
			var itemVal = items.getItem(i).get_value();
			// combo-value was found by matching index
			if (itemVal == val || itemVal == compareVal)
				break;
		}
		
		if (i == -1)
		{
			i = items.getLength();
			while (i-- > 0)
			{
				var itemVal = items.getItem(i).get_text();
				if (itemVal == val || itemVal == compareVal)
				{
					// combo-value was found by matching text
					
					this._useTxt = true;
					break;
				}
			}
		}
		if (i >= 0)
		{
			item = items.getItem(i);
			item.select();
			editor.set_selectedItemIndex(i);
			
			item.activate();
			editor.set_activeItemIndex(i);
			if (!$util.isEmpty(i = item.get_text()))
				val = i;
		}
		editor.set_currentValue(val, true);
		
		this._initValue = { val: this.get_value(), cell: cellVal };
	},
	get_text: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.DropDownProvider.text">
		/// Gets formatted text from the editor. 
		/// </summary>
		/// <value type="String">Current text in editor.</value>
		var item = this._editor.get_selectedItem();
		return item ? item.get_text() : '' + this._editor.get_currentValue();
	},
	
	_onInternalDropDownOpening: function (args)
	{
		
		if (this._grid && !this._grid._cellInEditMode)
			args.cancel = true;
	},
	
	_onMouse: function (e)
	{
		var parent = e.target.parentNode;
		while (parent && parent.tagName && parent.tagName != "BODY" && parent != this._element && parent != this._dropDown)
			parent = parent.parentNode;
		if (parent != this._element && parent != this._dropDown)
			this.notifyLostFocus(e);
		//this.__internalClick = true;
	},
	_addHandlers: function ()
	{
		if (this._hasLsnr)
			return;
		$IG.DropDownProvider.callBaseMethod(this, '_addHandlers');
		if (!this._onMouseFn)
			this._onMouseFn = Function.createDelegate(this, this._onMouse);
		$addHandler(document, 'mousedown', this._onMouseFn);
	},
	_removeHandlers: function ()
	{
		if (this._onMouseFn && this._hasLsnr && this._grid)
			$removeHandler(document, 'mousedown', this._onMouseFn);
		$IG.DropDownProvider.callBaseMethod(this, '_removeHandlers');
	},
	_show: function (top, left, width, height, cssClass, parent, cell)
	{
		var elem = this._editor.get_element();
		var cellElement = cell.get_element();
		if (!this._stretchHeight)
		{
			this._element.style.display = '';
			this._element.style.visibility = 'visible';
			



			if (this._verticalAlign == 0 || this._verticalAlign == 2) // NotSet or Middle
				top += Math.round((cellElement.offsetHeight - elem.offsetHeight) / 2);
			else if (this._verticalAlign == 3) // Bottom
				top += cellElement.offsetHeight - elem.offsetHeight;
		}
		this._setBounds(top, left, height, this._element.style, parent, cell);
		
		elem.style.width = width + "px";
		if (this._stretchHeight)
			elem.style.height = cellElement.clientHeight + "px";
		
		this._focus(this._input);
		
		this._firstKey(this._charKey);
		this._addHandlers();
	},

	_onBlurHandler: function (e)
	{
	    
	    // K.D. August 7th, 2013 Bug #148674 The blur handler fires first for the EditorProvider under IE7/IE8
        // Forcing the blur handler of the editor itself.
	    if (this._editor) {
	        this._editor._onBlurHandler(e);
	    }
		if (this._editor && this._editor.__blurFlag)
		{
			this.notifyLostFocus(e);
			
			var inv = this._invalid;
			if (inv && new Date().getTime() - inv < 50)
				return;
			var cellEditing, rowAdding, filtering = this._grid.get_behaviors().get_filtering();
			var editingCore = this._grid.get_behaviors().get_editingCore();
			if (editingCore)
			{
				cellEditing = editingCore.get_behaviors().get_cellEditing();
				rowAdding = editingCore.get_behaviors().get_rowAdding();
			}
			if (cellEditing && cellEditing.get_cellInEditMode())
				cellEditing.exitEditMode(false);
			else if (rowAdding && rowAdding.get_cellInEditMode())
				rowAdding.exitEditMode(false);
			else if (filtering && filtering.get_cellInEditMode())
				filtering.exitEditMode(false);
		}
	},

	notifyLostFocus: function (e)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.DropDownProvider.notifyLostFocus">
		/// The method is called whenever the editor loses focus. 
		/// </summary>
		/// <param name="e" type="Sys.UI.DomEvent">
		/// Event object associated with the event that triggered losing focus by the editor.
		/// </param>

		
		if (this._editor != null)
			this._editor.closeDropDown();
	},

	dispose: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.DropDownProvider.dispose">
		/// Called whenever the object is being disposed of.
		/// </summary>
		
		if (this._onInternalDropDownOpeningHandler && this._editor)
		{
			this._editor._unregisterEventListener(this, "InternalDropDownOpening", this._onInternalDropDownOpeningHandler);
			this._onInternalDropDownOpeningHandler = null;
		}
		this._editor = null;
		this._grid = null;
		$IG.DropDownProvider.callBaseMethod(this, 'dispose');
	}
}

$IG.DropDownProvider.registerClass('Infragistics.Web.UI.DropDownProvider', $IG.EditorProvider);



$IG.MonthCalendarProvider = function(adr, element, props, owner, csm)
{
	/// <summary locid="T:J#Infragistics.Web.UI.MonthCalendarProvider">
	/// The object defines the WebTextEditor editor provider for a column. 
	/// Overrides the EditorProvider object.
	/// </summary>
	if (!element)
		return;
	
	var i = -1, id = null, suffix = '_clientState', nodes = element.childNodes;
	
	while (++i < nodes.length)
	{
		id = nodes[i];
		id = (id.nodeName == 'INPUT') ? id.id : null;
		var len = id ? id.length : 0;
		if (len > 15 && id.indexOf(suffix) > len - 13)
		{
			this._editor = $find(id.substring(0, len - suffix.length));
			break;
		}
	}
	if (!this._editor)
		return;
	
	this._editor._master = this;
	$IG.MonthCalendarProvider.initializeBase(this, [adr, element, props, owner, csm]);
	this._input = this._editor._elements[7];
}

$IG.MonthCalendarProvider.prototype =
{
	get_value:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.MonthCalendarProvider.value">
		/// Overrides the EditorProvider's function.
		/// </summary>
		/// <value type="Date">Current value in editor.</value>
		var val = this._editor ? this._editor.get_selectedDate() : this._old;
		return this._areEqual(val, this._old) ? this._old0 : val;
	},
	set_value:function(val)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.MonthCalendarProvider.value">Sets initial value in editor.</summary>
		/// <param name="val" type="Date">Value for editor.</param>
		
		
		this._old0 = this._old = val;
		var editor = this._editor;
		if(!editor)
			return;
		editor.set_selectedDate(val);
		this._old = editor.get_selectedDate();
	},
	
	_onMouse: function(e)
	{
		var elem = e ? e.target : null;
		if (!elem)
			return;
		
		while ((elem = elem.parentNode) != null)
			if (elem == this._element)
			return;
		
		this.notifyLostFocus(e);
	},
	
	_removeHandlers: function()
	{
		if (this._onMouseFn && this._hasLsnr && this._grid)
			$removeHandler(this._grid, 'mousedown', this._onMouseFn);
		this._grid = null;
		$IG.MonthCalendarProvider.callBaseMethod(this, '_removeHandlers');
	},
	
	_show: function(top, left, width, height, cssClass, parent, cell)
	{
		var elem = this._element, calendar = this._editor._element;
		
		calendar.style.visibility = 'hidden';
		var wrapper = this._getWrapper(calendar, cssClass);
		this._setBounds(top, left, height, elem.style, parent, cell, wrapper);
		wrapper.style.width = calendar.offsetWidth + 'px';
		calendar.style.visibility = 'visible';
		this._focus(this._input);
		if (this._hasLsnr)
			return;
		this._addHandlers();
		
		if (this._grid)
			elem = this._grid;
		else
		{
			
			while ((elem = elem.parentNode) != null)
			{
				var id = elem.id;
				if (id && elem.nodeName == 'DIV' && id.length > 1 && id.charAt(0) != ':')
					break;
			}
			if (!elem)
				return;
			
			this._grid = elem;
		}
		if (!this._onMouseFn)
			this._onMouseFn = Function.createDelegate(this, this._onMouse);
		$addHandler(elem, 'mousedown', this._onMouseFn);
	},
	
	_doCal: function()
	{
		
		this.notifyLostFocus();
	},
	dispose: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.MonthCalendarProvider.dispose">
		/// Called whenever the object is being disposed of.
		/// </summary>
		if (!this._editor)
			return;
		delete this._editor._master;
		delete this._editor;
		this._grid = null;
		$IG.MonthCalendarProvider.callBaseMethod(this, 'dispose');
	}
}
$IG.MonthCalendarProvider.registerClass('Infragistics.Web.UI.MonthCalendarProvider', $IG.EditorProvider);












































































































$IG.RatingProvider = function(adr, element, props, owner, csm)
{
	/// <summary locid="T:J#Infragistics.Web.UI.RatingProvider">
	/// The object defines the WebRating editor provider for a column. 
	/// Overrides the EditorProvider object.
	/// </summary>
	if (!element)
		return;
	var i = -1, nodes = element.childNodes;
	
	while (++i < nodes.length)
	{
		if (nodes[i].nodeName != 'DIV')
			continue;
		var id = nodes[i].id;
		if (!$util.isEmpty(id))
			if (this._editor = $find(id))
				break;
		if (nodes[i].getAttribute("_wrapper"))
		{
			nodes = nodes[i].childNodes;
			i = -1;
		}
	}
	if (!this._editor)
		return;
	$IG.RatingProvider.initializeBase(this, [adr, element, props, owner, csm]);
	this._input = this._editor.get_element();
}

$IG.RatingProvider.prototype =
{
	get_value: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.RatingProvider.value">
		/// Overrides the EditorProvider's function.
		/// </summary>
		/// <value type="Number">Current value in editor.</value>
		var val = this._editor ? this._editor.get_value() : this._old;
		return this._areEqual(val, this._old) ? this._old0 : val;
	},
	set_value: function(val)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.RatingProvider.value">Sets initial value in editor.</summary>
		/// <param name="val" type="Number">Value for editor.</param>
		
		
		this._old0 = this._old = val;
		var editor = this._editor;
		if (!editor)
			return;
		editor.set_value(val);
		this._old = editor.get_value();
	},
	
	_show: function(top, left, width, height, cssClass, parent, cell)
	{
		var elem = this._element, rating = this._editor._element;
		this._editor._provider = this;
		
		rating.style.visibility = 'hidden';
		var wrapper = this._getWrapper(rating, cssClass);
		this._setBounds(top, left, height, elem.style, parent, cell, wrapper);
		wrapper.style.width = rating.offsetWidth + 'px';
		rating.style.visibility = 'visible';
		this._focus(this._input);
		this._addHandlers();
	},
	_onKeyDownHandler: function(e)
	{
		var key = e.keyCode;
		
		if (key == Sys.UI.Key.enter)
			this._editor.set_value(this._editor._realValFromLengthVal(this._editor._keyHover));
		if (key == Sys.UI.Key.tab || key == Sys.UI.Key.space || key == Sys.UI.Key.esc || (key == Sys.UI.Key.enter && !e.shiftKey && !e.ctrlKey && this._getExitEditModeOnEnter()))
			this.notifyLostFocus(e);
	}
	



}
$IG.RatingProvider.registerClass('Infragistics.Web.UI.RatingProvider', $IG.EditorProvider);


