/*
* 4_igEnums.js
* Version 13.2.20132.2007
* Copyright(c) 2001-2013 Infragistics, Inc. All Rights Reserved.
*/


Type.registerNamespace("Infragistics.Web.UI");


$IG.Orientation = function () 
{
    ///<summary locid="T:J#Infragistics.Web.UI.Orientation">
    /// Specifies the type of Orientation that should be applied.
    ///</summary>
    ///<field name="Horizontal" type="Number" integer="true" static="true"> horizontal orientation </field>
	///<field name="Vertical" type="Number" integer="true" static="true"> vertical orientation </field>
}
$IG.Orientation.prototype = 
{
   Horizontal:0, 
   Vertical:1
};
$IG.Orientation.registerEnum("Infragistics.Web.UI.Orientation");



$IG.PostBackAction = function()
{
    /// <summary locid="T:J#Infragistics.Web.UI.PostBackAction">
    /// The type of action that should occur when listening to a client event.
    /// </summary>
	///<field name="None" type="Number" integer="true" static="true"> no postback </field>
	///<field name="FullPostBack" type="Number" integer="true" static="true"> full postback </field>
	///<field name="AsyncPostBack" type="Number" integer="true" static="true"> Async (Ajax) postback </field>
}
$IG.PostBackAction.prototype =
{
	None:0,
	FullPostBack:1,
	AsyncPostBack:2
};
$IG.PostBackAction.registerEnum("Infragistics.Web.UI.PostBackAction");



$IG.DefaultableBoolean = function()
{
    ///<summary locid="T:J#Infragistics.Web.UI.DefaultableBoolean">
    /// Defaultable boolean values allow the user to either directly set the value to control a behavior or inherit from a parent object that 
    /// will be set.
    ///</summary>
    ///<field name="NotSet" type="Number" integer="true" static="true"> inherits the value from its parent object </field>
	///<field name="True" type="Number" integer="true" static="true"> true </field>
	///<field name="False" type="Number" integer="true" static="true"> false  </field>
}
$IG.DefaultableBoolean.prototype =
{
	NotSet:0,
	True:1,
	False:2
};
$IG.DefaultableBoolean.registerEnum("Infragistics.Web.UI.DefaultableBoolean");



$IG.ClientUIFlags = function()
{
    /// <summary locid="T:J#Infragistics.Web.UI.ClientUIFlags">
    /// Indicates which state flags are set for rendering client state objects.
    /// </summary>
    ///<field name="Visible" type="Number" integer="true" static="true"> indicates object is visible </field>
	///<field name="Enabled" type="Number" integer="true" static="true"> indicates that the object is enabled </field>
	///<field name="Selectable" type="Number" integer="true" static="true"> indicates that the object is selectable </field>
	///<field name="Selected" type="Number" integer="true" static="true"> indicates that the object is currently selected </field>
	///<field name="Hoverable" type="Number" integer="true" static="true"> indicates the object is hoverable  </field>
	///<field name="Hovered" type="Number" integer="true" static="true"> indicates that the object is currently hovered </field>
	///<field name="Editable" type="Number" integer="true" static="true"> indicates the object is editable  </field>
	///<field name="Focusable" type="Number" integer="true" static="true"> indicates the object is focusable </field>
	///<field name="Focused" type="Number" integer="true" static="true"> indicates the object is currently focused </field>
	///<field name="Draggable" type="Number" integer="true" static="true"> indicates the object is draggable </field>
	///<field name="Droppable" type="Number" integer="true" static="true"> indicates the object is droppable </field>
	///<field name="KBNavigable" type="Number" integer="true" static="true"> indicates that the object can be navigated with the keyboard </field>
}
$IG.ClientUIFlags.prototype =
{    
	Visible : 0x2,
    Enabled : 0x8,
    Selectable : 0x20,
    Selected : 0x40,
    Hoverable : 0x100,
    Hovered : 0x200, 
    Editable : 0x800,
    Focusable : 0x2000,
    Focused : 0x4000,
    Draggable : 0x10000,
    Droppable : 0x40000,
    KBNavigable : 0x100000
	
};
$IG.ClientUIFlags.registerEnum("Infragistics.Web.UI.ClientUIFlags");



$IG.LayoutControlProps = new function()
{
    this.Count = $IG.ControlMainProps.Count + 0;
};



$IG.DragDropPoint = function()
{
    /// <summary locid="T:J#Infragistics.Web.UI.DragDropPoint">
    /// Indicates the drop point of object that is dropped in a drag & drop operation.
    /// </summary>
    ///<field name="On" type="Number" integer="true" static="true">Indicates that the object is dropped over an object. </field>
    ///<field name="Before" type="Number" integer="true" static="true">Indicates that the object is dropped before an object.</field>
    ///<field name="After" type="Number" integer="true" static="true">Indicates that the object is dropped after an object.</field>
}
$IG.DragDropPoint.prototype =
{
    On: 0,
    Before: 1,
	After: 2
};
$IG.DragDropPoint.registerEnum("Infragistics.Web.UI.DragDropPoint");

