/*
* igCalendar.js
* Version 13.2.20132.2007
* Copyright(c) 2001-2013 Infragistics, Inc. All Rights Reserved.
*/


//vs 073010
Type.registerNamespace('Infragistics.Web.UI');

$IG.WebMonthCalendar = function(elem)
{
	/// <summary locid="T:J#Infragistics.Web.UI.WebMonthCalendar">Class which implements client side functionality of WebMonthCalendar.</summary>
	/// <param name="elem" domElement="true" mayBeNull="false">Reference to html element.</param>
	$IG.WebMonthCalendar.initializeBase(this, [elem]);

	$IG.WebMonthCalendar.find = $find;
	$IG.WebMonthCalendar.from = $IG._from;
}
$IG.WebMonthCalendar.prototype =
{
	_thisType:'calendar',
	_elemID:-2,
	_focID:-1,
	_selID:-1,
	_selChange:0,
	_listID:0,
	initialize:function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebMonthCalendar.initialize">Initializes instance of WebMonthCalendar.</summary>
		$IG.WebMonthCalendar.callBaseMethod(this, 'initialize');
		var q = ',', id = this._id;
		var prop = this._get_clientOnlyValue('dates').split(q);
		this._animation = new $IG.SlideFadeAnimation(this._get_clientOnlyValue('anim'));
		
		this._today = this._toYMD(new Date());
		var year = this._int_i(prop, 0), month = this._int_i(prop, 1);
		
		this._min = this._ymdAtI(prop, 2);
		this._max = this._ymdAtI(prop, 5);
		this._selDates = new Array();
		this._range = new Array();
		
		this._myp = this._get_clientOnlyValue('myp');
		
		var i = 8, o = 0;
		
		if(this._val_i(prop, i) == 'x')
		{
			
			this._range[0] = this._ymdAtI(prop, ++i);
			this._range[1] = this._ymdAtI(prop, i += 3);
			i += 3;
		}
		
		for(;i + 2 < prop.length; i += 3)
			this._selDates[o++] = this._ymdAtI(prop, i);
		
		prop = this._get_clientOnlyValue('prop').split(q);
		i = this._int_i(prop, 0);
		
		
		
		this._enabled = i & 3;
		this._allowNull = (i & 4) != 0;
		this._changeMonth = (i & 8) != 0;
		this._hideOther = (i & 16) != 0;
		
		this._multiSel = (i >> 5) & 3;
		var initFoc = (i & 128) != 0;
		this._readOnly = (i & 256) != 0;
		
		this._selFire = (i >> 9) & 3;
		this._causeValidation = (i & 2048) != 0;
		
		i = this._int_i(prop, 1);
		
		this._listCols = [this._int_i(prop, 3), i, (i > 2) ? ((i > 5) ? 3 : 2) : i];
		this._yearRow = this._int_i(prop, 2);
		
		this._wn = this._int_i(prop, 4);
		this._dow = this._int_i(prop, 5);
		this._nextFormat = this._int_i(prop, 6);
		this._yearFix = ((i = this._int_i(prop, 7)) == -1) ? 0 : i;
		
		this._hotKeys = new Array(9);
		
		for(i = 0; i < 9; i++)
			this._hotKeys[i] = this._hotKey(prop[i + 8]);
		
		this._noGroup = $util.isEmpty(this._hotKeys[2]);
		this._validationGroup = this._val_i(prop, 17);
		
		this._we1 = this._int_i(prop, 18);
		this._we2 = this._int_i(prop, 19);
		this._css = new Array(19);
		
		
		
		for(i = 20; i < 39; i++)
			this._css[i - 20] = this._val_i(prop, i);
		
		prop = this._get_clientOnlyValue('str').split(q);
		i = prop ? prop.length : 0;
		while(i-- > 0)
			prop[i] = prop[i].replace(/&coma;/g, q).replace(/&quot;/g, '\"');
		for(i = 0; i < 12; i++)
		{
			var name = prop[i];
			if(this._nextFormat > 0)
				if($util.isEmpty(prop[12 + i]))
					prop[12 + i] = (this._nextFormat == 1) ? name.substring(0, 3) : name;
		}
		this._months = prop;
		
		prop = this._get_clientOnlyValue('img');
		if(prop)
			prop = prop.split(q);
		var elem, elems = this._elements;
		
		for(i = 0; i < 5; i++)
		{
			elem = elems[i];
			if(!elem)
				continue;
			
			if(i > 4 || (i == 2 && this._listCols[0] == 0) || (i == 3 && this._listCols[1] == 0))
				continue;
			elem._calID = 500 + i;
			
			
			elem._css = elem.className;
			var css = (i < 2) ? 9 : ((i < 4) ? 11 : 13);
			elem._cssH = this._css[css];
			elem._cssP = this._css[css + 1];
			if(i > 1 || !prop)
				continue;
			
			var img = elem.firstChild;
			if(!img || !img.src)
				continue;
			
			elem._src = elem._src0 = img.src;
			
			elem._srcH = prop[i * 2];
			elem._srcP = prop[i * 2 + 1];
		}
		
		
		elem = elems[5];
		var wn = (this._wn == 0) ? 0 : 1;
		this._days = new Array(42 + wn * 6);
		for(i = 0; i < 6; i++)
		{
			var j = -1, nodes = elem.childNodes, tds = new Array();
			while(++j < nodes.length)
				if(nodes[j].nodeName == 'TD')
					tds[tds.length] = nodes[j];
			j = -1;
			while(++j < tds.length)
			{
				var d = i * 7 + (j - wn);
				if(j == 0 && wn == 1)
					d = 42 + i;
				var td = tds[j];
				td._calID = d;
				this._days[d] = new $IG.CalendarDay(td, d, (d > 41) ? -1 : (this._dow + (d % 7)) % 7, d < 42 && (d % 7 == this._we1 || d % 7 == this._we2));
			}
			elem = elem.nextSibling;
		}
		
		prop = this._getBackState(0);
		
		
		if(prop && prop.length > 5)
		{
			
			this._elemID = -1;
			prop = prop.split(q);
			i = parseInt(prop[1]);
			if(i != Number.NaN && i > 1)
			{
				year = i;
				month = parseInt(prop[2]);
				var range = parseInt(prop[0].charAt(0));
				
				range = (range != Number.NaN && (range & 2) == 2);
				this._selDates = new Array();
				o = 0;
				for(i = 5; i < prop.length; i += 3)
				{
					var d = this._ymdAtI(prop, i - 2);
					if(range)
					{
						
						this._range[o++] = d;
						if(o > 1)
						{
							range = false;
							o = 0;
						}
					}
					else
						this._selDates[o++] = d;
				}
			}
		}
		
		if(!$util.isEmpty(prop = this._get_clientOnlyValue('cd')))
		{
			prop = prop.replace(/&coma;/g, q).replace(/&quot;/g, '\"');
			prop = prop.split(q);
			this._cd = new Array();
			for(i = j = 0; i < prop.length; i += 7)
				this._cd[j++] = {year:this._int_i(prop, i), month:this._int_i(prop, i + 1), day:this._int_i(prop, i + 2), dow:this._int_i(prop, i + 3), css:this._val_i(prop, i + 4), text:this._val_i(prop, i + 5), disabled:!$util.isEmpty(prop[i + 6])};
		}
		
		prop = $util.getRuntimeStyle(this._element);
		this._masterTimer = $util.toIntPX(prop, 'marginLeft') == 0 && $util.toIntPX(prop, 'marginTop') == 0 && $util.toIntPX(prop, 'left') == 0 && $util.toIntPX(prop, 'top') == 0;
		
		if(initFoc)
			this.focus();
		
		prop = this._get_clientOnlyValue('tday');
		if(prop)
		{
			prop = prop.split('=');
			if((i = parseInt(prop[0])) != (j = this._today.day))
			{
				
				this._elemID = -1;
				o = prop[(Math.abs(i - j) < 2) ? ((i > j) ? 2 : 1) : (i > j) ? 1 : 2];
				if(o && elems[4])
					elems[4].innerHTML = o;
			}
		}
		this.repaint(year, month);
		this._elemID = -1;
		if(!this._onTimer())
		{
			
			ig_ui_timer(this);
			this._timerOn = 1;
		}
		this._initEnd();
	},
	_hotKey:function(prop)
	{
		if($util.isEmpty(prop))
			return null;
		prop = prop.split(':');
		for(var i = 0; i < prop.length; i++)
			prop[i] = parseInt(prop[i]);
		return prop;
	},
	
	_ymdAtI:function(prop, i)
	{
		return {year:this._int_i(prop, i), month:this._int_i(prop, i + 1), day:this._int_i(prop, i + 2)};
	},
	get_minDate:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebMonthCalendar.minDate">
		/// Gets sets minimum date as Date.
		/// Notes: New value does not persist to server.
		/// The set method does not update html. In order to refresh image, application should call refresh().
		/// </summary>
		/// <value type="Date" mayBeNull="true">Minimum date</value>
		return this._newDate(this._min.year, this._min.month, this._min.day);
	},
	set_minDate:function(date)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebMonthCalendar.minDate">Sets minimum date</summary>
		/// <param name="date" type="Date" mayBeNull="true">Minimum date</param>
		this._min = this._toYMD(date, 1);
	},
	get_maxDate:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebMonthCalendar.maxDate">
		/// Gets sets maximum date as Date.
		/// The set method does not update html. In order to refresh image, application should call refresh().
		/// Note: new value does not persist to server.
		/// </summary>
		/// <value type="Date" mayBeNull="true">Maximum date</value>
		return this._newDate(this._max.year, this._max.month, this._max.day);
	},
	set_maxDate:function(date)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebMonthCalendar.maxDate">Sets maximum date</summary>
		/// <param name="date" type="Date" mayBeNull="true">Maximum date</param>
		this._max = this._toYMD(date, 2);
	},
	get_visibleMonth:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebMonthCalendar.visibleMonth">
		/// Gets sets visible month as Date.
		/// The get returns 1st day of visible month.
		/// </summary>
		/// <value type="Date">Visible date</value>
		return this._newDate(this._days[15].year, this._days[15].month, 1);
	},
	set_visibleMonth:function(date)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebMonthCalendar.visibleMonth">Sets visible month</summary>
		/// <param name="date" type="Date" mayBeNull="true">Visible month</param>
		if(date && date.getDay)
			this.repaint(this._ymd(date, 0), this._ymd(date, 1), true);
	},
	get_selectedDate:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebMonthCalendar.selectedDate">
		/// Gets sets selected date as Date.
		/// In case of multiselection, the get returns first selected date within array of selected dates.
		/// </summary>
		/// <value type="Date" mayBeNull="true">Selected date</value>
		var sel = this._selDates[0];
		if(!sel)
			sel = this._range[0];
		return sel ? this._newDate(sel.year, sel.month, sel.day) : null;
	},
	set_selectedDate:function(date, e)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebMonthCalendar.selectedDate">Sets selected date</summary>
		/// <param name="date" type="Date" mayBeNull="true">Selected date</param>
		/// <param name="e" mayBeNull="true">Browser event. Internal use only.</param>
		var y = -1, m = -1, d = -1, sel = this._selDates;
		if(!date)
		{
			if(!this._allowNull)
				date = this._today;
			else if(sel.length == 0)
				return;
		}
		if(date)
		{
			if(date.getDay)
				date = this._toYMD(date);
			if(!(y = date.year))
				return;
			m = date.month;
			d = date.day;
		}
		if(d > 0)
		{
			if(sel.length == 1 && this.isSelected(y, m, d))
			{
				if(this._master && e)
				{
					this._master._doCal(e, false, true);
					return;
				}
				sel = null;
			}
			else if(this._limit(y, m, d))
				return;
		}
		if(sel)
		{
			this._selID = -1;
			
			this._select(y, m, d, false, e, -3);
		}
		if(d < 1)
			return;
		
		if(e && (!e.shiftKey || !this._selKey))
			this._selKey = {year:y, month:m, day:d};
		
		
		if(this._multiSel != 1 && (y != this._days[15].year || m != this._days[15].month))
			this.repaint(y, m);
		
		this._focChange(this._selID);
	},
	get_days:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebMonthCalendar.days">
		/// Gets array of objects which represent days in calendar and week numbers.
		/// Array which contains CalendarDay objects.
		/// If week numbers are enabled, then its length is 47, otherwise, its length is 42.
		/// Note: that object should not be modified.
		/// </summary>
		/// <value type="Array" elementType="Infragistics.Web.UI.CalendarDay">Days in calendar</value>
		return this._days;
	},
	get_customDays:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebMonthCalendar.customDays">
		/// Gets array of objects which used by calendar to modify default rendering of days.
		/// Each item may contain following optional members:
		/// day: day in month in range of 1..31;
		/// month: month in year in range of 1..12;
		/// year: year in range of 2..9999;
		/// dow: day of the week in range of 0..6;
		/// disabled: value of true makes day disabled;
		/// css: name of custom css class;
		/// text: html used to render day. If it contains {0}, then it is replaced by the day of the month.
		///</summary>
		/// <value type="Array" mayBeNull="true">Custom days in calendar</value>
		return this._cd;
	},
	addCustomDay:function(year, month, day, dow, disabled, text, css)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebMonthCalendar.addCustomDay">Adds new custom day. Note: new day does not persist after a postback.</summary>
		/// <param name="year" type="Number">Year of custom day. Range: 0..9999.</param>
		/// <param name="month" type="Number">Month of year. Range: 0..12.</param>
		/// <param name="day" type="Number">Day of month. Range: 0..31.</param>
		/// <param name="dow" type="Number">Day of the week. Range: -1..6.</param>
		/// <param name="disabled" type="Boolean" optional="true" mayBeNull="true">Request to render day with disabled style.</param>
		/// <param name="text" type="String" optional="true" mayBeNull="true">Html used for day. It may contain {0}.</param>
		/// <param name="css" type="String" optional="true" mayBeNull="true">Custom css.</param>
		if(!this._cd)
			this._cd = new Array();
		this._cd[this._cd.length] = {year:year ? year : 0, month:month ? month : 0, day:day ? day : 0, dow:dow ? dow : -1, disabled:disabled, text:text ? text : '', css:css};
	},
	get_animation:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebMonthCalendar.animation">
		/// Gets reference to container of properties related to animation. That is type of Infragistics.Web.UI.SlideFadeAnimation
		/// </summary>
		/// <value type="Infragistics.Web.UI.SlideFadeAnimation" mayBeNull="true">Reference to animation</value>
		return this._animation;
	},
	showList:function(id)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebMonthCalendar.showList">Show list of months, years or year groups.</summary>
		/// <param name="id" type="Number">Possible values: 1 - list of months, 2 - list of years, 3 - list of year groups.</param>
		this._doList(null, id);
	},
	closeList:function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebMonthCalendar.closeList">Close list of months, years or year groups.</summary>
		this._doList(null, 0);
	},
	getOpenedListID:function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebMonthCalendar.getOpenedListID">Checks which list is currently opened.</summary>
		/// <returns type="Number">Possible values: 0 - no list, 1 - list of months is opened, 2 - list of years, 3 - list of year groups.</returns>
		return this._listID;
	},
	get_firstDayOfWeek:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebMonthCalendar.firstDayOfWeek">Gets first day of the week. 0 is Sunday, 6 is Saturday</summary>
		/// <value type="Number" integer="true">First day of week</value>
		return this._dow;
	},
	get_enabled:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebMonthCalendar.enabled">
		/// Gets sets enabled state of control as boolean.
		/// </summary>
		/// <value type="Boolean">True: control is enabled</value>
		return (this._enabled & 1) == 1;
	},
	set_enabled:function(val)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebMonthCalendar.enabled">Sets enabled state</summary>
		/// <param name="val" type="Boolean">True: control is enabled</param>
		this._enabled = (this._enabled & 2) + (val ? 1 : 0);
	},
	get_readOnly:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebMonthCalendar.readOnly">
		/// Gets sets read-only state of control as boolean.
		/// <value type="Boolean">True: control is read only</value>
		return this._readOnly;
	},
	set_readOnly:function(val)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebMonthCalendar.readOnly">Sets read only state</summary>
		/// <param name="val" type="Boolean">True: control is read only</param>
		this._readOnly = val == true;
	},
	focus:function(delay)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebMonthCalendar.focus">Ses input focus to control with delay.</summary>
		/// <param name="delay" type="Number" integer="true" optional="true">Delay in milliseconds.</param>
		if(this._master)
			return;
		window.setTimeout("try{ig_controls['" + this._id + "'].setFocus();}catch(e){}", delay ? delay : 0);
	},
	setFocus:function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebMonthCalendar.setFocus">Ses input focus to control without delay.</summary>
		var elem = this._master ? null : this._elements[7];
		
		if(elem && this._enabled == 3 && this._element.offsetWidth > 20 && !this._foc) try
		{
			elem.focus();
		}catch(ex){}
	},
	hasFocus:function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebMonthCalendar.hasFocus">Checks if control has input focus.</summary>
		/// <returns type="Boolean">Value of true means that control has focus.</returns>
		return this._foc == true;
	},
	get_selectedRange:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebMonthCalendar.selectedRange">
		/// Creates and returns array which contains minumum and maximum dates or current range.
		/// The get returns null or array of 2 Date objects.
		/// The set should contain array of minimum and maximum dates. The set does not change possible selected dates and it has effect only when multi selection is enabled.
		/// </summary>
		/// <value type="Array" mayBeNull="true" elementType="Date">Array of dates</value>
		return this._toDates(this._range, true);
	},
	get_selectedDates:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebMonthCalendar.selectedDates">
		/// Gets sets selected dates.
		/// The get method creates and returns array of selected dates in calendar as Date objects.
		/// The set method removes possible selected range.
		/// Note: when dates are set, then they should be sorted in ascending order.
		/// </summary>
		/// <value type="Array" mayBeNull="true" elementType="Date">Array of dates</value>
		var a = this._range, sel = this._selDates;
		if(a[1])
		{
			var i = sel.length, range = new Array(), sel0 = new Array();
			while(i-- > 0)
				sel0[i] = sel[i];
			sel = sel0;
			this._doRange(range, a[0], a[1].year, a[1].month, a[1].day);
			this._addRange(sel, range);
		}
		return this._toDates(sel);
	},
	set_selectedDates:function(dates)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebMonthCalendar.selectedDates">
		/// Sets selected dates.
		/// Note: dates should be sorted in ascending order.
		/// </summary>
		/// <param name="dates" type="Array" mayBeNull="true" elementType="Date">Array of dates</param>
		if(this._multiSel < 2)
		{
			this.set_selectedDate(dates ? dates[0] : null);
			return;
		}
		this._selDates = this._toYMDs(dates);
		this._range = new Array();
		this.repaint();
		this._saveCS(1);
	},
	set_selectedRange:function(dates)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebMonthCalendar.selectedRange">
		/// Sets range of selected dates.
		/// Note: It does not change possible selected dates and it has effect only when multi selection is enabled.
		/// </summary>
		/// <param name="dates" type="Array" mayBeNull="true" elementType="Date">Array of minimum and maximum dates</param>
		if(this._multiSel < 2)
			return;
		this._range = this._toYMDs(dates);
		this.repaint();
		this._saveCS(1);
	},
	getIndividualSelectedDates:function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebMonthCalendar.getIndividualSelectedDates">Creates and returns array of individually selected dates in calendar.</summary>
		/// <returns type="Array" elementType="Date">Array of Date objects.</returns>
		return this._toDates(this._selDates);
	},
	setSelectedRangeMinMax:function(min, max)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebMonthCalendar.setSelectedRangeMinMax">Sets range of selected dates. That is a wrapper for set_selectedRange([min, max]).</summary>
		/// <param name="min" type="Date">Minimum date.</param>
		/// <param name="max" type="Date">Maximum date.</param>
		this.set_selectedRange([min, max]);
		this._saveCS(1);
	},
	setSelectedDatesAndRange:function(dates, range)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebMonthCalendar.setSelectedDatesAndRange">Sets selected dates. That method has effect only when multi selection is enabled.</summary>
		/// <param name="dates" type="Array" elementType="Date">Array of selected dates. Note: dates should be sorted in ascending order.</param>
		/// <param name="range" type="Array" elementType="Date">Array of minimum and maximum dates for range.</param>
		if(this._multiSel < 2)
			return;
		this._selDates = this._toYMDs(dates);
		this._range = this._toYMDs(range);
		this.repaint();
		this._saveCS(1);
	},
	addDateToSelection:function(date, repaint)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebMonthCalendar.addDateToSelection">Add new date to selection. Note: that method will move range of selected dates into array or selected dates.</summary>
		/// <param name="date" type="Date">Selected date.</param>
		/// <param name="repaint" type="Boolean" optional="true">True: request to repaint calendar.</param>
		/// <returns type="Boolean">True if date was added.</returns>
		return this._toggle(date, true, repaint);
	},
	removeDateFromSelection:function(date, repaint)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebMonthCalendar.removeDateFromSelection">Remove date from selection. Note: that method will move range of selected dates into array or selected dates.</summary>
		/// <param name="date" type="Date">Selected date.</param>
		/// <param name="repaint" type="Boolean" optional="true">True: request to repaint calendar.</param>
		/// <returns type="Boolean">True if date was removed.</returns>
		return this._toggle(date, false, repaint);
	},
	isDateSelected:function(date)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebMonthCalendar.isDateSelected">Checks if date is selected.</summary>
		/// <param name="date" type="Date">Date.</param>
		/// <returns type="Boolean">True if date is selected.</returns>
		date = this._toYMD(date);
		return date && this.isSelected(date.year, date.month, date.day);
	},
	isSelected:function(year, month, day)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebMonthCalendar.isSelected">Checks if date at year, month and day is selected.</summary>
		/// <param name="year" type="Number" integer="true">Year of date.</param>
		/// <param name="month" type="Number" integer="true">Month of date in range of 1-12.</param>
		/// <param name="day" type="Number" integer="true">Day of date.</param>
		/// <returns type="Boolean">True if date is selected.</returns>
		return this._getSelIndex(null, year, month, day, 0) >= 0 || this._inRange(year, month, day);
	},
	_toggle:function(date, add, repaint)
	{
		date = this._toYMD(date);
		if(!date)
			return false;
		var y = date.year, m = date.month, d = date.day;
		if(add == this.isSelected(y, m, d) || (add && this._limit(y, m, d)))
			return false;
		var a = this._range, range = new Array();
		if(a[1])
			this._doRange(range, a[0], a[1].year, a[1].month, a[1].day);
		var sel = this._selDates;
		if(range.length > 0)
			this._addRange(sel, range);
		var len = sel.length;
		
		var i = this._selIndex(sel, y, m, d, -1);
		
		if(i < 0)
			sel[len] = date;
		
		else
		{
			var j = len + 1;
			while(--j > i)
				sel[j] = sel[j - 1];
			sel[i] = date;
		}
		if(repaint)
			this._repaint();
		this._saveCS(1);
		return true;
	},
	
	
	_toDates:function(a, r)
	{
		var d, i = -1, dates = new Array();
		if(a) while(++i < a.length)
		{
			if(!(d = a[i]))
				break;
			dates[i] = this._newDate(d.year, d.month, d.day);
		}
		return (!r || i == 2) ? dates : null;
	},
	
	
	_toYMDs:function(dates)
	{
		var i = 0, j = -1, len = dates ? dates.length : 0, a = new Array();
		while(++j < len)
		{
			var ymd = this._toYMD(dates[j]);
			if(!ymd)
				continue;
			var last = (i > 0) ? a[i - 1] : null;
			var limit = this._limit(ymd.year, ymd.month, ymd.day, 0, last);
			if(limit)
				ymd = limit;
			if(!this._same(ymd, last))
				a[i++] = ymd;
			if(this._multiSel < 1 || (i == 7 && this._multiSel == 1))
				break;
		}
		return a;
	},
	
	_toYMD:function(d, minMax)
	{
		return (d && d.getDay) ? {year:d.getFullYear(), month:d.getMonth() + 1, day:d.getDate()} : (minMax ? {year:500 + minMax * 1000, month:1 + (minMax - 1) * 11, day:1 + (minMax - 1) * 30} : null);
	},
	
	_inRange:function(y, m, d)
	{
		
		if(this._range[1])
			if(!this._limit(y, m, d, 0, this._range[0], this._range[1]))
				return true;
		return false;
	},
	_getSelIndex:function(sel, year, month, day, i, end)
	{
		if(!sel)
			sel = this._selDates;
		if(!end)
			end = sel.length - 1;
		while(i <= end)
		{
			var d = sel[i++];
			if(d.day == day && d.month == month && d.year == year)
				return i - 1;
		}
		return -1;
	},
	
	_removeRange:function(sel, range, i0)
	{
		var i, len = sel.length, j = -1;
		if(i0 < 0)
			i0 = 0;
		while(++j < range.length)
		{
			if(this._same(sel[i = i0], range[j]))
			{
				while(++i < len)
					sel[i - 1] = sel[i];
				sel.length = --len;
			}
		}
	},
	
	_addRange:function(sel, range)
	{
		var len = sel.length, j = -1, i = -1, append = false;
		while(++j < range.length)
		{
			var d = range[j];
			
			if(!append)
				append = (i = this._selIndex(sel, d.year, d.month, d.day, i)) < 0;
			
			if(append)
				sel[len++] = d;
			
			else if(!this._same(d, sel[i]))
			{
				var x = ++len;
				while(--x > i)
					sel[x] = sel[x - 1];
				sel[i] = d;
			}
		}
	},
	
	_select:function(year, month, day, toggle, e, focID, range, week, keep)
	{
		if(focID > 47)
			focID = -3;
		
		var sel0 = this._selDates, selRange0 = this._range, master = this._master, days = this._days;
		
		
		var sel = sel0, selRange = selRange0, i = -1, len = sel0.length, fire = e && (this._selFire == 1 || master);
		
		var multi = this._multiSel, key = this._selKey;
		if(multi < 2)
		{
			range = false;
			if(!this._allowNull)
				toggle = false;
		}
		if(fire)
		{
			sel = new Array();
			while(++i < len)
				sel[i] = sel0[i];
			selRange = [selRange[0], selRange[1]];
		}
		if(day < 1)
		{
			if(len < 1)
				return;
			sel.length = 0;
		}
		
		if(multi == 1)
			week = true;
		var ymd = {year:year, month:month, day:day};
		
		var oDay, j = -1, iSel = -1;
		if(!week && range && key)
		{
			
			if(e && (e.type == 'mousedown' || toggle))
				sel.length = 0;
			selRange[0] = key;
			selRange[1] = ymd;
			if(year <= key.year && (year < key.year || (month <= key.month && (month < key.month || day < key.day))))
			{
				selRange[1] = key;
				selRange[0] = ymd;
			}
			if(this._same(key, ymd))
				selRange[1] = null;
		}
		else
		{
			if(selRange[1])
			{
				var aR = new Array();
				this._doRange(aR, selRange[0], selRange[1].year, selRange[1].month, selRange[1].day);
				this._addRange(sel, aR);
				len = sel.length;
				selRange[1] = null;
			}
			iSel = this._getSelIndex(sel, year, month, day, 0);
		}
		
		
		var same = (len == 1 || multi == 1) && this._same(sel[0], ymd);
		if(week)
		{
			week = new Array();
			var end = focID, weekID = this._elemID;
			
			if(end < 0)
			{
				for(end = 0; end < 36; end++)
					if(this._same(days[end], ymd))
						break;
				if(end > 35)
				{
					this.repaint(year, month);
					for(end = 0; end < 42; end++)
						if(this._same(days[end], ymd))
							break;
				}
			}
			if(end > 41)
				end = (end - 42) * 7;
			i = end -= end % 7;
			oDay = days[i];
			end += 6;
			
			if(range && weekID > 41 && focID > 41)
			{
				j = 20;
				if(weekID > focID)
				{
					this._copy(days[(focID - 42) * 7], ymd);
					end = (weekID - 42) * 7 + 6;
				}
				else if(weekID < focID)
					this._copy(days[(weekID - 42) * 7], ymd);
			}
			
			else if(oDay.day != day)
				this._copy(oDay, ymd);
			
			end = days[end];
			this._doRange(week, ymd, end.year, end.month, end.day, true);
			
			while(++j < 7)
			{
				oDay = days[i + j];
				if(!oDay.disabled)
				{
					
					end = null;
					if(!oDay.selected)
						break;
				}
			}
			
			same = j == 7;
			
			if(same)
			{
				if(!toggle && len == week.length && len < 8)
					return;
				
				same = toggle;
			}
			
			if(!range && end)
				return;
			range = false;
		}
		
		if(focID > 41)
		{
			focID = (focID - 42) * 7 - 1;
			for(j = 0; j < 7; j++)
			{
				oDay = days[++focID];
				if(!this._limit(oDay.year, oDay.month, oDay.day, 1))
					break;
			}
		}
		
		if(toggle && ((!this._allowNull && len < 2) || (multi <= 1 && !same)))
			toggle = false;
		
		
		if(!range) if(!toggle)
		{
			if(same && !master)
				return;
			if(day > 0)
			{
				if(week)
					sel = week;
				else
				{
					sel[0] = ymd;
					sel.length = 1;
				}
			}
		}
		
		else if(week)
		{
			if(same)
				this._removeRange(sel, week, iSel);
			else
				this._addRange(sel, week);
		}
		
		else
		{
			
			i = iSel;
			
			if(i >= 0)
			{
				while(++i < len)
					sel[i - 1] = sel[i];
				sel.length--;
			}
			
			else
			{
				
				i = this._selIndex(sel, year, month, day, -1);
				
				if(i < 0)
					sel[len] = ymd;
				
				else
				{
					j = len + 1;
					while(--j > i)
						sel[j] = sel[j - 1];
					sel[i] = ymd;
				}
			}
		}
		if(fire)
		{
			if(!range && sel.length == len && (len == 0 || (len == 1 && same)))
			{
				
				if(focID >= 0)
					this._focChange(focID);
				if(master)
					master._doCal(e, false, len == 1);
				return;
			}
			
			var args = this._raiseClientEvent('SelectionChanging', 'CalendarSelectionChanging', e, null, sel, sel0, selRange, selRange0, this);
			if(args)
			{
				if(args.get_cancel())
				{
					
					if(focID >= 0 && this._focMD)
						this._focChange(focID);
					return false;
				}
				sel = args._props[2];
				selRange = args._props[4];
				range = selRange && selRange.length == 2;
			}
		}
		
		this._selDates = sel;
		this._range = selRange;
		if(!range && sel.length == 1 && multi == 2)
			this._selKey = sel[0];
		
		if(focID >= 0 || (focID != -1 && sel.length > 0 && this._foc))
			this._selID = this._focID = focID;
		
		if(keep || week)
			year = month = null;
		this.repaint(year, month, false, e);
		
		this._selChange = 1;
		
		this._saveCS(1);
		
		if(fire || this._selFire > 1)
		{
			
			this._raiseClientEvent('SelectionChanged', 'CalendarSelectionChanged', e, null, sel, sel0, selRange, selRange0, this);
			if(master)
				master._doCal(e, false, true);
		}
		return true;
	},
	
	_isWeekSel:function(id)
	{
		if(id > 41)
			id = (id - 42) * 7;
		else
			id -= id % 7;
		for(var i = 0; i < 7; i++)
		{
			var d = this._days[id + i];
			if(!d.selected && !d.disabled)
				return false;
		}
		return true;
	},
	
	
	_doRange:function(sel, start, y, m, d, limit)
	{
		var y1 = start.year, m1 = start.month, d1 = start.day;
		
		if(y1 >= y && (y1 > y || (m1 >= m && (m1 > m || d1 > d))))
		{
			start = {year:y, month:m, day:d};
			y = y1;
			m = m1;
			d = d1;
		}
		sel.length = i = 0;
		while(i++ < 10000)
		{
			if(!limit || !this._limit(start.year, start.month, start.day))
				sel[sel.length] = start;
			if(start.year >= y && start.month == m && start.day == d)
				return;
			start = this._toYMD(new Date(start.year, start.month - 1, start.day + 1));
		}
	},
	repaint:function(year, month, check, e, focD)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebMonthCalendar.repaint">Adjusts month and year of calendar and repaints it.</summary>
		/// <param name="year" type="Number" integer="true" optional="true">Year.</param>
		/// <param name="month" type="Number" integer="true" optional="true">Month.</param>
		/// <param name="check" type="Boolean" optional="true">Internal use only. Check current month.</param>
		/// <param name="e" optional="true">Internal use only. Browser event.</param>
		/// <param name="focD" optional="true">Internal use only. Override value of focus day.</param>
		var id = (year == null), days = this._days;
		var oDay = days[15];
		if(id || year < 1)
			year = oDay.year;
		if(month == null)
			month = oDay.month;
		if(month < 1)
		{
			month = 12;
			year--;
		}
		if(month > 12)
		{
			month -= 12;
			year++;
		}
		var elems = this._elements;
		var i, oldD = null, d = this._limit(year, month, 1);
		if(d)
		{
			year = d.year;
			month = d.month;
		}
		
		if(oDay.year != year || oDay.month != month)
		{
			
			var args = e ? this._raiseClientEvent('VisibleMonthChanging', 'VisibleMonthChanging', e, null, d ? d : this._newDate(year, month, 1), oldD = this._newDate(oDay.year, oDay.month, 1)) : null;
			if(args)
			{
				if(args.get_cancel())
					return false;
				d = args.get_date();
				i = (d && d.getDay) ? this._ymd(d, 0) : 0;
				if(i > 0)
				{
					year = i;
					month = this._ymd(d, 1);
				}
			}
			check = true;
			
			i = this._focID;
			if(!focD && i >= 0 && i < 42)
			{
				
				d = days[i].day;
				
				if(d > 30)
					d = 30;
				if(month == 2 && d > 28)
					if(this._ymd(this._newDate(year, month, d = 29), 1) != month)
						d = 28;
				focD = d;
			}
			this._selID = -1;
		}
		else if(check)
			return;
		
		if(focD)
			this._focID = 50;
		var numDays = (month == 2) ? 28 : 30;
		d = this._newDate(year, month, numDays + 1);
		if(this._ymd(d, 1) == month)
			numDays++;
		d = this._newDate(year, month, 1);
		i = this._ymd(d, 3) - this._dow;
		var day1 = (i < 0) ? i + 7 : i;
		d = this._newDate(year, month, 0);
		var day0 = this._ymd(d, 2) - day1 + 1;
		var y = this._ymd(d, 0), m = this._ymd(d, 1);
		
		var min = this._limit(y, m, day0, 1) != null;
		
		var max = this._limit(y, m, day0, 2) ? 1 : 0;
		if(max == 0)
		{
			d = this._newDate(year, month + 1, 14);
			y = this._ymd(d, 0);
			m = this._ymd(d, 1);
			if(this._limit(y, m, 14, 1))
				max = 1;
			else if(this._limit(y, m, 14, 2))
				max = -1;
		}
		
		if(focD && (min || max) && this._limit(year, month, focD))
			
			focD = 50;
		this._1stID = this._todayID = this._weeks = -1;
		var cells = (this._wn > 0) ? 48 : 42;
		var dd, iSel1 = -1, iSel0 = -2;
		for(i = 0; i < cells; i++)
		{
			oDay = days[i];
			
			oDay.year = year;
			oDay.month = month;
			oDay.other = oDay.today = false;
			if(i > 41)
				oDay.text = '' + (oDay.weekNumber = this._weekNum(year, month, i - 42));
			else
			{
				oDay.hide = this._hideOther;
				if(i < day1)
				{
					oDay.day = day0 + i;
					if(--oDay.month < 1)
					{
						oDay.month = 12;
						oDay.year--;
					}
					oDay.other = true;
				}
				else if(i < day1 + numDays)
				{
					oDay.day = i - day1 + 1;
					oDay.hide = false;
					if(this._1stID < 0)
						this._1stID = i;
				}
				else
				{
					oDay.day = i + 1 - (day1 + numDays);
					if(++oDay.month > 12)
					{
						oDay.month = 1;
						oDay.year++;
					}
					oDay.other = true;
				}
				y = oDay.year; m = oDay.month; d = oDay.day;
				if(iSel0 < -1)
				{
					
					var d2 = new Date(this._newDate(y, m, d).getTime() + 43 * 24 * 3600000);
					iSel0 = this._selIndex(null, y, m, d, -1);
					if(iSel0 >= 0)
						iSel1 = this._selIndex(null, d2.getFullYear(), d2.getMonth() + 1, d2.getDate(), iSel0 - 1, true);
					if(iSel1 < iSel0)
						iSel0 = -1;
				}
				if(!oDay.hide && this._same(oDay, this._today))
				{
					oDay.today = true;
					if(i >= day1 && i <= day1 + numDays)
						this._todayID = i;
				}
				if(i == 0)
					this._doCD(oDay);
				oDay.text = '' + (oDay.hide ? ' ' : oDay.day);
				
				oDay.selected = dd = oDay.hide ? false : ((iSel0 >= 0 && this._getSelIndex(null, y, m, d, iSel0, iSel1) >= 0) || this._inRange(y, m, d));
				if(dd && !focD && this._focID < 0 && this._foc)
					this._focID = i;
				if(dd && this._selID < 0)
					this._selID = i;
			}
			
			if(max < 1)
			{
				if(min)
					min = this._limit(y, m, d, 1) != null;
				else if(max < 0 && this._limit(y, m, d, 2))
					max = 1;
			}
			if(i < 42)
				oDay.disabled = max == 1 || min;
			
			
			if(focD && m == month && (d == focD || (focD == 50 && !oDay.disabled)))
			{
				this._focID = i;
				
				focD = null;
			}
			
			this._drawDay(i);
		}
		this._fixLbls();
		if(!check || !e)
			return;
		if(oldD)
		{
			this._saveCS();
			
			this._raiseClientEvent('VisibleMonthChanged', 'VisibleMonthChanged', e, null, this._newDate(year, month, 1), oldD);
		}
	},
	_fixLbls:function()
	{
		if(this._elemID < -1)
			return;
		var oDay = this._days[15], elems = this._elements, list = this._listID;
		var m = oDay.month, y = oDay.year, mm = this._months;
		if(this._nextFormat > 0 && elems[0])
		{
			elems[1].innerHTML = (list > 0) ? '&raquo;' : mm[12 + (m + 12) % 12];
			elems[0].innerHTML = (list > 0) ? '&laquo;' : mm[12 + (m + 10) % 12];
		}
		
		mm = mm[m - 1];
		
		if(this._myp)
		{
			
			if(list == 0)
				mm = this._myp.replace('##', mm).replace('#', m).replace('%', y + this._yearFix);
			
			else if(list == 1 || this._noGroup)
				mm = y;
			
			else
				mm = this._yearLbl;
		}
		this._setTxt(elems[2], mm);
		
		this._setTxt(elems[3], y + this._yearFix);
	},
	idFromMouse:function(e)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebMonthCalendar.idFromMouse">Gets id of active element in calendar from the mouse event of browser. That is method used internally and can be used publically by advanced applications.</summary>
		/// <param name="e">Event of browser.</param>
		/// <returns type="Number">
		/// List of possible values:
		/// -1 - unknown;
		/// 0..41 - day in calendar grid;
		/// 42..47 - week number, where week in grid=id-42;
		/// 500 - previous month button;
		/// 501 - next month button;
		/// 502 - drop down button for list of months;
		/// 503 - drop down button for list of years;
		/// 504 - today button (footer);
		/// 601..612 - item in drop down list of months, where month=id-600;
		/// 701..10699 - item in drop down list of years, where year=id-700.
		/// </returns>
		var id, i = 0, src = e.target;
		if(!src)
			src = e.srcElement;
		while(src && i++ < 10)
		{
			this._src = src;
			if((id = src._calID) != null)
				return id;
			src = src.parentNode;
		}
		return -1;
	},
	_selIndex:function(sel, year, month, day, i, up)
	{
		if(!sel)
			sel = this._selDates;
		var len = sel.length;
		while(++i < len)
		{
			var d = sel[i];
			if(year <= d.year && (year < d.year || (month <= d.month && (month < d.month || day <= d.day))))
				return up ? i - 1 : i;
		}
		return up ? i - 1 : -1;
	},
	
	_same:function(a, b){ return a && b && a.year == b.year && a.month == b.month && a.day == b.day; },
	
	_copy:function(a, b)
	{
		if(!a || !b)
			return;
		b.year = a.year;
		b.month = a.month;
		b.day = a.day;
	},
	
	_doCD:function(day)
	{
		var i = this._cd ? this._cd.length : 0;
		
		var y0 = day.year, m0 = day.month, d0 = day.day;
		
		var m1 = (d0 > 9) ? (m0 + 1) % 12 : m0;
		if(m1 == 0)
			m1 = 12;
		
		var m2 = (m1 + 1) % 12;
		if(m2 == 0)
			m2 = 12;
		var cds = null;
		while(i-- > 0)
		{
			var cd = this._cd[i];
			var y = cd.year, m = cd.month, d = cd.day;
			
			if(y > 0 && (y < y0 || y > y0 + 1 || (y > y0 && m0 < 11)))
				continue;
			
			if(m > 0 && !(m == m1 || (m == m0 && d > 0 && d >= d0) || (m == m2 && d > 0 && d < 14)))
				continue;
			if(!cds)
				cds = new Array();
			cds[cds.length] = cd;
		}
		this._cd0 = cds;
	},
	
	
	_drawDay:function(id)
	{
		var day = this._days[id];
		if(!day)
			return;
		
		day.css = this._css[0];
		day.focus = this._focID == id;
		if(day.weekend)
			day.css += ' ' + this._css[1];
		if(day.other)
			day.css += ' ' + this._css[2];
		if(day.today)
			day.css += ' ' + this._css[3];
		if(day.weekNumber > 0)
			day.css += ' ' + this._css[5];
		if(day.hover)
			day.css += ' ' + this._css[6];
		if(day.focus)
			day.css += ' ' + this._css[7];
		
		var draw = this._elemID != -2, i = this._cd0 ? this._cd0.length : 0;
		while(i-- > 0)
		{
			var cd = this._cd0[i];
			if(cd.day > 0 && cd.day != day.day)
				continue;
			if(cd.month > 0 && cd.month != day.month)
				continue;
			if(cd.year > 0 && cd.year != day.year)
				continue;
			if(cd.dow >= 0 && cd.dow != day.dow)
				continue;
			draw = true;
			if(cd.css)
				day.css += ' ' + cd.css;
			if(cd.disabled)
				day.disabled = true;
			if(cd.text.length > 0)
				day.text = cd.text.replace('{0}', day.day);
		}
		if(day.selected)
		{
			if(day.disabled)
				day.selected = false;
			else
				day.css += ' ' + this._css[4];
		}
		var args = this._raiseClientEvent('RenderDay', 'CalendarRenderDay', null, null, day);
		if(args)
		{
			if(args.get_cancel())
				return;
		}
		else if(!draw)
			return;
		if(day.disabled)
			day.css += ' ' + this._css[8];
		day.element.className = day.css;
		i = day.text;
		day.element.innerHTML = (i.length > 0 && i != ' ') ? i : '&nbsp;';
	},
	
	
	
	
	
	
	
	_doList:function(e, show, next)
	{
		var i, j, val, td, style, elem, elems = this._elements, list = this._list;
		
		var cols = this._listCols[show - 1];
		
		var sel = -1, dad = elems[6], id = this._listID;
		
		if(!dad || (show == 3 && this._noGroup) || (show > 0 && (cols < 1 || (id == show && !next))) || (id == 0 && show == 0))
			return false;
		
		if(show == 0)
		{
			if(next && next > 600)
				sel = next - ((next > 700) ? 700 : 600);
			next = null;
		}
		
		if(show > 0 && show != id)
		{
			
			if(id > 0)
				
				if(this._doList(e, 0, (id == 3 && next) ? next + 700 : null))
					
					if(id == 3)
						next = null;
			id = show;
			if(!list)
				list = this._list = new Array();
		}
		var args = e ? this._raiseClientEvent((show > 0) ? 'ListOpening' : 'ListClosing', 'CalendarList' + ((show > 0) ? 'Opening' : 'Close'), e, null, id, sel) : null;
		if(args && args.get_cancel() && (show > 0 || sel > 0))
			return true;
		var rows = (id == 1) ? 12 / cols : this._yearRow;
		list = list[id - 1];
		if(!list)
		{
			var elem = document.createElement('TBODY');
			
			var head = 0, child = dad.firstChild, cal = this._element;
			this._list[id - 1] = list = document.createElement('TABLE');
			style = list.style;
			style.position = 'absolute';
			
			if(dad.colSpan > 3)
			{
				
				head = dad.offsetHeight + 2;
				if((val = dad.clientHeight) < 8)
					if((val = head - 6) < 2)
						head = val = 2;
				style.marginTop = val + 'px';
			}
			
			if((val = cal.clientHeight) < 40)
				val = cal.offsetHeight - 4;
			val -= head;
			
			if(elems[4])
				val -= elems[4].offsetHeight + 3;
			if(val < 100)
				val = 100;
			style.height = val + 'px';
			
			
			if(head > 0)
				cal = dad;
			if((val = cal.clientWidth) < 20)
				val = cal.offsetWidth - 4;
			if((i = child.offsetLeft) > 6)
				i = 2;
			style.width = (val - i - i) + 'px';
			style.tableLayout = 'fixed';
			
			list.className = this._css[15];
			list.appendChild(elem);
			for(i = 0; i < rows; i++)
			{
				var tr = document.createElement('TR');
				elem.appendChild(tr);
				for(j = 0; j < cols; j++)
				{
					td = document.createElement('TD');
					
					td._css = this._css[16];
					td._cssH = this._css[17];
					td._cssP = this._css[18];
					var val = 601 + i + j * rows;
					tr.appendChild(td);
					if(id == 1)
					{
						td.innerHTML = this._months[i + j * rows];
						td._calID = val;
					}
				}
			}
			dad.insertBefore(list, child);
			
			if(head == 0)
			{
				var p1 = $util.getPosition(list), p2 = $util.getPosition(cal);
				val = p1.x - p2.x - 3;
				if(val > 0 && val < 50)
					style.marginLeft = -val + 'px';
				val = p1.y - p2.y - 2;
				if(val > 0 && val < 30)
					style.marginTop = -val + 'px';
			}
			else
				style.marginLeft = (dad.offsetWidth - list.offsetWidth) / 2 + 'px';
		}
		if(show > 0)
		{
			var sel, count = cols * rows, nodes = list.firstChild.childNodes, day = this._days[15];
			
			var shift = count >> 1, year = day.year, min = this._min.year, max = this._max.year;
			
			var year0 = this._listYear, stop = this._stopYear, group = (id == 3) ? rows * this._listCols[1] : 1;
			if(!next)
			{
				this._listYear = year;
				this._stopYear = 0;
			}
			
			else if(next > 1)
			{
				this._listYear = year = next + shift;
				this._stopYear = 0;
				next = null;
			}
			else if(year0)
			{
				
				if(next > 0 && stop < 1)
					year = year0 + count * group;
				
				else if(next < 0 && stop >= 0)
					year = year0 - count * group;
				
				else
					return true;
				this._listYear = year;
			}
			
			if(max - min + 2 < count * group)
			{
				count = Math.floor((max - min) / group) + 1;
				shift = Math.floor((year - min) / group);
				year = min + shift * group;
				next = this._listYear = null;
				if(show == 2)
					this._noGroup = true;
			}
			else
			{
				stop = 0;
				
				if(year - shift * group < min)
				{
					shift = Math.floor((year - min) / group);
					
					year = min + shift * group;
					
					stop = -1;
				}
				else if(year - (shift - count) * group > max)
				{
					shift = Math.floor((year - max) / group) + count - 1;
					
					year = max + (shift - count) * group + 1;
					
					stop = 1;
				}
				this._stopYear = stop;
			}
			var last = '';
			for(i = 0; i < rows; i++) for(j = 0; j < cols; j++)
			{
				td = nodes[i].childNodes[j];
				val = i + j * rows;
				if(show > 1)
				{
					val = year + (val - shift) * group;
					if(i == 0 && j == 0)
						this._yearLbl = val;
					td.innerHTML = (val > max) ? '&nbsp;' : ((show == 3) ? (val + '-' + (val + group - 1)) : val);
					if(val <= max)
						last = (show == 3) ? (val + group - 1) : val;
					td._calID = (val > max) ? null : 700 + val;
					
					sel = (val == day.year) ? 0 : 1;
					if(show == 3)
						sel = (val <= day.year && val + group - 1 >= day.year) ? 0 : 1;
				}
				else
					
					sel = val + 1 - day.month;
				td._press = sel == 0;
				this._fixCss(td);
			}
			this._yearLbl += ' - ' + last;
		}
		this._listID = show;
		if(show == 0 || (show > 0 && !next))
			this._animation.play(list, show > 0, null, null, this, this._stop, id);
		
		elem = this._elements[(id == 1) ? 2 : 3];
		
		if(!this._myp && elem)
		{
			elem._press = show > 0;
			this._fixCss(elem);
		}
		td = this._hovKey;
		if(td && show == 0)
		{
			td._hov = false;
			this._hovKey = null;
		}
		this._fixLbls();
		if(e)
		{
			args = this._raiseClientEvent((show > 0) ? 'ListOpened' : 'ListClosed', 'CalendarList' + ((show > 0) ? 'Opened' : 'Close'), e, null, id, sel);
			if(show == 0 && args && args.get_cancel())
				return true;
		}
		return false;
	},
	
	_fixCss:function(elem)
	{
		var v, cn = elem._css;
		if(elem._hov && !$util.isEmpty(v = elem._cssH))
			cn += ' ' + v;
		if(elem._press && !$util.isEmpty(v = elem._cssP))
			cn += ' ' + v;
		if(elem.className != cn)
			elem.className = cn;
		
		v = elem._press ? elem._srcP : (elem._hov ? elem._srcH : elem._src0);
		
		if(!$util.isEmpty(v) && v != elem._src)
		{
			if(!(cn = elem.firstChild))
				return;
			cn.src = v;
			
			elem._src = cn.src;
		}
	},
	
	_val_i:function(o, i)
	{
		o = (o == null || o.length <= i) ? null : o[i];
		return (o == null) ? '' : o;
	},
	
	_int_i:function(o, i)
	{
		return $util.isEmpty(o = this._val_i(o, i)) ? -1 : parseInt(o);
	},
	
	_newDate:function(y, m, d)
	{
		d = new Date(y, --m, d);
		if(y < 100 && d.setFullYear != null)
			d.setFullYear(y);
		return d;
	},
	
	_ymd:function(d, i)
	{
		if(i == 0)
			return d.getFullYear();
		if(i == 1)
			return d.getMonth() + 1;
		return (i == 2) ? d.getDate() : d.getDay();
	},
	
	
	
	_limit:function(y, m, d, one, min, max)
	{
		if(!max) max = this._max;
		if(one != 1 && y >= max.year && (y > max.year || (m >= max.month && (m > max.month || d > max.day))))
			return max;
		if(!min) min = this._min;
		if(one != 2 && y <= min.year && (y < min.year || (m <= min.month && (m < min.month || d < min.day))))
			return min;
		return null;
	},
	
	_weekNum:function(y, m, i)
	{
		var d, mo = m, weeks = this._weeks, yi0 = this._year0;
		if(weeks < 0)
		{
			if(!yi0 || yi0.y != y)
			{
				yi0 = this._year0 = this._yearInfo(y);
				this._yearP = this._yearInfo(y - 1);
			}
			
			weeks = yi0.jan1;
			
			while(--mo > 0)
			{
				var day = (mo == 2) ? 28 : 30;
				if(this._ymd(this._newDate(y, mo, day + 1), 1) == mo)
					day++;
				weeks += day;
			}
			
			this._weeks = weeks = Math.floor(weeks / 7) + 1 - yi0.prev;
		}
		
		if(m == 12 && i > 3) if((d = yi0.next) > 0)
		{
			
			if(i == 5)
				return (d > 1) ? 2 : 1;
			
			if(i == 4 && d > 1)
				return 1;
		}
		
		return (m == 1 && i == 0 && yi0.prev) ? this._yearP.weeks : i + weeks;
	},
	
	_yearInfo:function(y)
	{
		
		var days = 365, wn = this._wn - 1;
		if(this._ymd(this._newDate(y, 2, 29), 1) == 2)
			days++;
		
		var w = this._ymd(this._newDate(y, 1, 1), 3) - this._dow;
		var w1 = this._ymd(this._newDate(y + 1, 1, 1), 3) - this._dow;
		if(w < 0)
			w += 7;
		if(w1 < 0)
			w1 += 7;
		
		
		var weeks = Math.floor((days + w) / 7) + 1, prev = 0;
		
		if(wn > 6 - w)
		{
			weeks--;
			prev++;
		}
		
		if(w1 > 0 && wn < 7 - w1)
			weeks++;
		
		
		
		var next = (w1 < 3 && (w1 == 0 || wn < 6)) ? 1 : 0;
		
		if(w1 > 2)
			next += (wn > 6 - w1) ? 1 : 2;
		
		return {weeks:weeks, jan1:w, prev:prev, next:next, y:y};
	},
	
	_setTxt:function(e, t)
	{
		if(!e) return;
		var nodes = e.childNodes;
		var i = -1, ii = nodes ? nodes.length : 0;
		if(t != ' ') while(++i < ii)
		{
			var ei = (i < 0) ? e : nodes[i];
			if(ei.nodeName == '#text')
			{
				if(t != null)
				{
					ei.nodeValue = t;
					t = null;
				}
				else
					ei.nodeValue = '';
			}
		}
		if(t == null)
			return;
		if(e.text != null)
			e.text = t;
		else
			e.innerHTML = (t == ' ') ? '&nbsp;' : t;
	},
	_initEnd:function()
	{
		var elem = this._element;
		var evts = {mousedown:this._onEvt, mouseover:this._onEvt, mouseout:this._onEvt, selectstart:this._onEvt, 'touchstart':this._onTStart, 'touchend':this._onTEnd};
		if(this._multiSel > 1)
		{
			evts.mouseup = this._onEvt;
			evts.touchmove = this._onTMove;
		}
		$addHandlers(elem, evts, this);
		elem = this._elements;
		if(elem && elem[7])
			$addHandlers(elem[7], {'focus':this._onEvt, 'blur':this._onEvt, 'keydown':this._onEvt}, this);
		this._raiseClientEvent('Initialize');
	},
	
	_onTimer:function()
	{
		var elem = this._element, master = this._master;
		if(!elem)
			return true;
		
		if(master && this._masterTimer)
		{
			
			var up = this._slideUp, t = new Date().getTime(), old = this._dropShift, p0 = master._element, p1 = $util.getLocation(elem);
			if(!p0)
				return true;
			
			if(up && up + 600 > t)
				return false;
			this._once = true;
			p0 = $util.getLocation(p0);
			
			p0.x -= p1.x;
			p0.y -= p1.y;
			if(!old)
				this._dropShift = p0;
			else if(Math.abs(p0.x - old.x) > 2 || Math.abs(p0.y - old.y) > 2)
			{
				master._doCal();
				return true;
			}
			return false;
		}
		
		if(this._once)
			return true;
		var width = elem ? elem.offsetWidth : 0;
		if(width == 0)
			return false;
		this._once = true;
		return true;
	},
	
	
	_saveCS:function(sel)
	{
		this._setBackState(0, this._saveAdditionalClientState(sel));
	},
	
	
	
	_saveAdditionalClientState:function(sel)
	{
		var last = this._lastVS, range = this._range;
		if(sel || !last)
			sel = this._selDates;
		
		var d = this._days[15], val = '' + (this._selChange + (range[1] ? 2 : 0));
		
		val += ((this._enabled & 1) + (this._readOnly ? 2 : 0) + ((this._foc || this._focMD) ? 4 : 0)) + ',';
		
		if(d.year < 1000)
			val += '0';
		if(d.year < 100)
			val += '0';
		if(d.year < 10)
			val += '0';
		val += d.year + ',';
		if(d.month < 10)
			val += '0';
		val += d.month;
		
		if(!sel)
			val += last.substring(10);
		else
		{
			
			if(range[1])
				val += ',' + range[0].year + ',' + range[0].month + ',' + range[0].day + ',' + range[1].year + ',' + range[1].month + ',' + range[1].day;
			for(var i = 0; i < sel.length; i++)
				val += ',' + sel[i].year + ',' + sel[i].month + ',' + sel[i].day;
		}
		
		this._lastVS = val;
		return val;
	},
	
	_fakePress:function(id)
	{
		this._onFakePress();
		if(id != 0 && id != 1 && id != 4 && !(id == 2 && this._myp))
			return;
		var elem = this._pressElem = this._elements[id];
		if(!elem)
			return;
		if(!this._fakePressFn)
			this._fakePressFn = Function.createDelegate(this, this._onFakePress);
		
		this._pressID = window.setTimeout(this._fakePressFn, 250);
		elem._press = true;
		this._fixCss(elem);
	},
	
	_onFakePress:function()
	{
		if(!this._pressID)
			return;
		window.clearTimeout(this._pressID);
		var elem = this._pressElem;
		this._pressID = this._pressElem = null;
		if(elem)
		{
			elem._press = false;
			this._fixCss(elem);
		}
	},
	
	_focChange:function(id)
	{
		var old = this._focID;
		if(old == id)
			return;
		this._focID = id;
		
		if(old >= 0 && old < 42)
			this._drawDay(old);
		
		this._drawDay(id);
	},
	
	_doDown:function(e)
	{		
		var days = this._days;
		var oDay = days[15], keep = null;
		var y = oDay.year, m = oDay.month, today = this._today;
		var list = this._listID, id = this._elemID;
		if(id < 0)
			return;
		
		if(id > 600)
		{
			
			if(list == 3)
			{
				
				this._doList(e, list - 1, id - 700);
				return;
			}
			
			if(list == 2 && this._myp)
			{
				
				this.repaint(id - 700, m, true, e);
				
				this._doList(e, 1);
				return;
			}
			if(this._doList(e, 0, id))
				return;
			if(id < 613)
				this.repaint(y, id - 600, true, e);
			else
				this.repaint(id - 700, m, true, e);
		}
		
		if(id == 502 || id == 503)
		{
			
			if(this._myp || (id == 503 && list > 1))
				list++;
			else
				list = (list == id - 501) ? 0 : id - 501;
			if(list > 3 || (list == 3 && this._noGroup))
				return;
			this._doList(e, list);
		}
		this._fakePress(id - 500);
		
		if(id == 500 || id == 501)
		{
			
			if(list > 1)
			{
				this._doList(e, list, (id == 500) ? -1 : 1);
				return;
			}
			if(list == 1)
				y += (id == 500) ? -1 : 1;
			else
				m += (id == 500) ? -1 : 1;
			this.repaint(y, m, true, e);
		}
		if(this._readOnly)
		{
			if(id == 504)
			{
				this._doList(e, 0);
				this.repaint(today.year, today.month, true, e);
			}
			return;
		}
		
		
		var d, i = -3, toggle = e.ctrlKey, multi = this._multiSel;
		
		if(id == 504)
		{
			this._doList(e, 0);
			this.set_selectedDate(today, e);
			return;
		}
		
		else
		{
			if(id > 47)
				return;
			oDay = null;
			
			if(id > 41)
				
				oDay = (multi > 0) ? days[i = (id - 42) * 7] : null;
			else
				oDay = days[i = id];
			if(!oDay || (oDay.disabled && id < 42))
				return;
			
			if(multi == 1 && id < 42)
				oDay = days[id - id % 7];
			y = oDay.year;
			m = oDay.month;
			d = oDay.day;
			if(this._hideOther && days[15].month != m && id < 42)
				return;
			keep = !this._changeMonth;
		}
		if(this._limit(y, m, d))
		{
			if(id < 42 && multi != 1)
				return;
			
			var x = 0, i0 = i - i % 7;
			while(++x < 7)
			{
				oDay = days[i0 + x];
				if(!this._limit(oDay.year, oDay.month, oDay.day))
					break;
			}
			if(x > 6)
				return;
		}
		
		if(!e.shiftKey || !this._selKey)
			this._selKey = {year:y, month:m, day:d};
		
		this._select(y, m, d, toggle, e, (id > 41) ? id : i, toggle ? false : e.shiftKey, id > 41 && id < 48, keep);
	},
	
	_doFoc:function(foc)
	{
		var id = this._focID;
		if(id < 0 && !foc)
			return;
		if(foc)
		{
			
			id = (this._focMD && this._hovDay) ? this._hovDay.index : -1;
			if(id < 0 || id > 41) if((id = this._selID) < 0)
				if((id = this._todayID) < 0)
					id = this._1stID;
			
			var i = id;
			while(this._days[id].disabled)
				if(++id > 41)
					break;
			if(id > 41)
			{
				id = i;
				while(this._days[id].disabled)
					if(--id < 0)
						break;
				
				if(id < 0)
					id = 15;
			}
			this._focID = id;
		}
		else
			this._focID = -1;
		if(id >= 0 && id < 42)
			this._drawDay(id);
	},
	
	_dayKey:function(e, k, foc)
	{
		var days = this._days;
		var dd = days[15], keep = null;
		var year = dd.year, month = dd.month;
		var y = year, m = month, d = 1;
		if(e.ctrlKey)
		{
			
			if(k == 37)
				k = 33;
			
			else if(k == 39)
				k = 34;
			else if(k > 32)
				return;
		}
		var sel = false;
		if(foc < 0)
			foc = 0;
		else
		{
			if(k == 38)
				foc -= 7;
			else if(k == 40)
				foc += 7;
			else if(k == 39)
				foc++;
			else if(k == 37)
				foc--;
			else if(k == 36)
			{
				
				for(foc = 0; foc < 10; foc++)
					if(!days[foc].other)
						break;
			}
			else if(k == 35)
			{
				
				for(foc = 26; foc < 40; foc++)
					if(days[foc + 1].other)
						break;
			}
			else if(k == 33 || k == 34)
			{
				this._fakePress(k - 33);
				this.repaint(year, month + 1 + (k - 34) * 2, true, e);
				return;
			}
			else if(k == 32 || k == 13)
			{
				dd = days[foc];
				y = dd.year;
				m = dd.month;
				d = dd.day;
				sel = true;
				keep = !this._changeMonth;
			}
			else return;
		}
		
		
		if(k > 34) if(foc > 41)
		{
			dd = days[41];
			y = dd.year;
			m = dd.month;
			d = dd.day + foc - 41;
		}
		
		else if(foc >= 0)
		{
			dd = days[foc];
			y = dd.year;
			m = dd.month;
			d = dd.day;
		}
		
		else
		{
			if((m = month - 1) < 1)
			{
				y--;
				m = 12;
			}
			d = days[0].day + foc;
			if(d < 1)
			{
				if(this._ymd(this._newDate(y, m, (dd = (m == 2) ? 28 : 30) + 1), 1) == m)
					dd++;
				d += dd;
			}
		}
		
		if(this._limit(y, m, d))
			return;
		if(foc < 0 || foc > 41 || days[foc].hide)
			foc = -3;
		if(sel || (e.shiftKey && this._multiSel > 1))
		{
			sel = sel && e.ctrlKey;
			
			if(e.shiftKey && !this._selKey) if((dd = days[this._focID]) != null)
			{
				this._selKey = {year:dd.year, month:dd.month, day:dd.day};
				
				sel = true;
			}
			
			this._select(y, m, d, sel, e, foc, e.shiftKey, null, keep);
			return;
		}
		if(foc < 0)
		{
			
			this.repaint(y, m, true, e, d);
			return;
		}
		this._focChange(foc);
	},
	
	
	_listKey:function(e, k, id)
	{
		if(e.shiftKey || e.ctrlKey || e.altKey)
			return;
		
		if(k == 33 || k == 34)
		{
			
			k += k - 67;
			
			if(id > 1)
				this._doList(e, id, k);
			
			else
				this.repaint(this._days[15].year + k, this._days[15].month, false, e);
			return;
		}
		var list = this._list[id - 1], calID = -1;
		
		var cols = this._listCols[id - 1];
		var rows = (id == 1) ? 12 / cols : this._yearRow;
		var val, hov = -1, sel = -1, nodes = list.firstChild.childNodes;
		
		for(var i = 0; i < rows; i++) for(var j = 0; j < cols; j++)
		{
			td = nodes[i].childNodes[j];
			val = i + j * rows;
			
			if(td._press)
				sel = val;
			if(td._hov)
			{
				hov = val;
				calID = td._calID;
			}
		}
		
		id = (hov < 0) ? sel : hov;
		if(k == 38)
			id--;
		else if(k == 40)
			id++;
		else if(k == 39)
			id += rows;
		else if(k == 37)
			id -= rows;
		else if(k == 36)
			id = 0;
		else if(k == 35)
			id = rows * cols - 1;
		else if(k == 32 || k == 13)
		{
			if(k == 13)
				$util.preventDefaults(e);
				//$util.cancelEvent(e);
			
			if(this._listID == 3)
			{
				
				this._doList(e, 2, calID - 700);
				return;
			}
			if(this._doList(e, 0, calID))
				return;
			
			if(calID > 700)
				this.repaint(calID - 700, this._days[15].month, true, e);
			
			else if(calID > 600)
				this.repaint(this._days[15].year, calID - 600, true, e);
			return;
		}
		else
			return;
		
		if(id < 0 || id >= rows * cols)
			return;
		
		for(var i = rows - 1; i >= 0; i--) for(var j = cols - 1; j >= 0; j--)
		{
			val = i + j * rows;
			if(val == id || val == hov)
			{
				td = nodes[i].childNodes[j];
				
				if(!td._calID)
					return;
				td._hov = val == id;
				if(val == id)
					this._hovKey = td;
				this._fixCss(td);
			}
		}
	},
	
	_doHotKey:function(e, k, id)
	{
		var i = -1, cancel = false, flags = this._hotKeys;
		if(e.shiftKey)
			k += 1000;
		if(e.ctrlKey)
			k += 2000;
		if(e.altKey)
			k += 4000;
		
		while(++i < 9)
		{
			
			if(id < 1 && i == 5)
				i = 7;
			var keys = flags[i];
			var j = keys ? keys.length : 0;
			while(j-- > 0)
				if(keys[j] == k)
					break;
			if(j >= 0)
				break;
		}
		
		if(i < 3)
		{
			this._doList(e, (id == ++i) ? 0 : i);
			return true;
		}
		
		if(i == 3)
		{
			
			if(id < 3 && flags[id])
			{
				this._doList(e, id + 1);
				return true;
			}
			if(id < 2 && flags[id + 1])
			{
				this._doList(e, id + 2);
				return true;
			}
			return false;
		}
		
		if(i == 4)
		{
			if(id < 1)
				return false;
			if(id > 2 && !flags[id - 1])
				id--;
			if(id > 1 && !flags[id - 1])
				id--;
			this._doList(e, id - 1);
			return true;
		}
		
		if(i < 7)
		{
			
			i = 11 - i - i;
			
			if(id > 1)
				this._doList(e, id, i);
			
			if(id == 1)
				this.repaint(this._days[15].year + i, this._days[15].month, false, e);
			return true;
		}
		if(i > 8 || id > 0)
			return false;
		id = this._today;
		var y = id.year, m = id.month, d = id.day;
		
		if(i == 8)
			this.repaint(y, m, false, e);
		else if(!this._limit(y, m, d))
			
			this._select(y, m, d, false, e, -3);
		return true;
	},
	
	_doKey:function(e)
	{
		var k = e.keyCode, foc = this._focID, id = this._listID;
		if(k >= 32 && k < 42)
			$util.preventDefaults(e);
			//$util.cancelEvent(e);
		
		var args = this._raiseClientEvent('KeyDown', 'Cancel', e);
		if(args && args.get_cancel())
			return;
		if(k < 999 && this._doHotKey(e, k, id))
		{
			$util.preventDefaults(e);
			//$util.cancelEvent(e);
			return;
		}
		if(!k || k < 13 || k > 40)
			return;
		if(k == 27)
			this._doList(e, 0);
		else if(id > 0)
			this._listKey(e, k, id);
		else if(foc < 42)
			this._dayKey(e, k, foc);
	},
	
	_onEvt:function(evt)
	{
		// touch-zoom
		if(this._toch == 2)
			return;
		var e = evt ? evt.rawEvent : null, days = this._days;
		e = e || evt;
		
		if(!e || this._enabled != 3 || !days)
			return;
		var type = evt.type || e.type;
		if(type == 'selectstart')
		{
			$util.cancelEvent(e);
			return;
		}
		var foc = type == 'focus';
		if(foc || type == 'blur')
		{
			
			// window.external - test for modal IE window
			var ie8Bug = !foc && this._focMD && (!this._foc || (($util.IsIE7 || $util.IsIE8) && typeof window.external == 'object'));
			
			this._focMD = foc && this._focMD;
			this._foc = foc;
			
			this._raiseClientEvent(foc ? 'Focus' : 'Blur', null, e);
			if(!foc && !ie8Bug)
				this._doList(e, 0);
			else if (ie8Bug)
				this.setFocus();
			this._doFoc(foc);
			return;
		}
		
		this._focMD = false;
		if(type == 'keydown')
		{
			this._doKey(e);
			return;
		}
		var over = type == 'mouseover', down = type == 'mousedown', out = type == 'mouseout';
		
		if(down)
		{
			
			this._focMD = true;
			
			var args = this._raiseClientEvent('MouseDown', 'Cancel', e);
			if (document.hasFocus && !document.hasFocus())
				this.focus();
			else
			{
				$util.cancelEvent(e);
				this.setFocus();
			}
			if(args && args.get_cancel())
				return;
		}
		var i = 0, src = evt.target, list = this._listID;
		if(over && src && src.unselectable != 'on' && src.nodeName != 'INPUT')
			src.unselectable = 'on';
		var id = this.idFromMouse(e), hovDay = this._hovDay;
		if(this._drag)
			if(type == 'mouseup' || (out && $util.isOut(e, this._element)))
				this._drag = false;
		if(id < 0)
		{
			if(hovDay)
			{
				hovDay.hover = false;
				this._drawDay(hovDay.index);
				this._hovDay = null;
			}
			return;
		}
		src = this._src;
		
		if(list > 0 && id < 500)
			return;
		
		
		if(id == 503 || (id == 502 && this._myp))
			
			
			if(list == 3 || ((this._listCols[list] == 0 || (list == 2 && this._noGroup)) && (!this._hov || !out)))
				return;
		if(down)
		{
			this._drag = id < 48 && this._multiSel > 1;
			this._elemID = id;
			this._doDown(e);
		}
		if(over || out)
		{
			var hov = this._hovKey;
			if((over && this._hovID == id) || (hovDay && !$util.isOut(e, hovDay.element)))
				return;
			this._hovID = out ? -1 : id;
			
			this._raiseClientEvent(over ? 'MouseOver' : 'MouseOut', null, e);
			if(hov)
			{
				hov._hov = false;
				this._fixCss(hov);
				this._hovKey = null;
			}
			hov = this._hov;
			if(over && hov)
			{
				hov._hov = false;
				this._fixCss(hov);
			}
			if(src._cssH)
			{
				src._hov = over;
				this._fixCss(src);
				this._hov = over ? src : null;
			}
			else if(id < 48)
			{
				var oDay = days[id];
				if(over && hovDay == oDay)
					return;
				if(hovDay)
				{
					hovDay.hover = false;
					this._drawDay(hovDay.index);
					this._hovDay = null;
				}
				if(over && oDay.text != ' ')
				{
					oDay.hover = true;
					this._hovDay = oDay;
					if(this._drag)
					{
						
						if(this._elemID > 41 && id > 41)
							oDay = days[(id - 42) * 7]; 
						
						else if(this._elemID > 41 || id > 41 || oDay.disabled)
							oDay = null;
						
						if(oDay && (id < 42 || !e.ctrlKey))
							
							if(this._select(oDay.year, oDay.month, oDay.day, false, e, id, true, id > 41, true))
								return;
					}
					this._drawDay(id);
				}
			}
		}
	},
	_onTStart:function(e)
	{
		var t = e.rawEvent.touches;
		// touch-zoom
		if(t && t.length > 1)
		{
			if(this._toch === 1)
			{
				e.type = 'mouseout';
				this._onEvt(e);
			}
			if(this._tE)
			{
				this._onTEnd(e);
				delete this._tE;
			}
			this._toch = 2;
			return;
		}
		this._toch = this._toch || 1;
		delete this._tE;
		// not touch-zoom
		if (this._toch == 1)
		{
			e.type = 'mouseover';
			this._onEvt(e);
			e.type = 'mousedown';
			this._onEvt(e);
			t = (t && this._multiSel > 1) ? t[0] : null;
			e = t ? e.target : null;
			if(e && e.nodeName == '#text')
				e = e.parentNode;
			var id = e ? e._calID : null;
			if(id != null && id >= 0 && id < 42)
				this._tE = {i:id, w:e.offsetWidth, h:e.offsetHeight, x:t.pageX, y:t.pageY, l:id};
		}
	},
	_onTMove:function(e)
	{
		if(this._toch == 2)
			return;
		$util.cancelEvent(e);
		var te = this._tE, t = te ? e.rawEvent.touches : null;
		if(!t || !t[0]) return;
		var x = t[0].pageX - te.x, y = t[0].pageY - te.y, last = te.l, id = te.i;
		id += Math.floor(x / te.w + 0.5) + Math.floor(y / te.h + 0.5) * 7;
		id = Math.max(0, Math.min(id, 41));
		if(id === last) return;
		e = this._days[te.l = id].element;
		this._onEvt({type:'mouseout', target:this._days[last].element, toElement:e});
		this._onEvt({type:'mouseover', target:e});
	},
	_onTEnd:function(e)
	{
		if (this._toch === 1)
		{
			e.type = 'mouseup';
			this._onEvt(e);
			e.type = 'mouseout';
			this._onEvt(e);
		}
		var t = e.rawEvent.touches;
		if(!t || !t.length)
			delete this._toch;
	},
	
	
	_drop:function(master, date)
	{
		var elem = this._element, old = this._master, frame = this._frame;
		this._doList(null, 0);
		var animation = master ? master._animation : this._animationDP;
		if(!animation)
			animation = this._animation;
		if(master)
		{
			delete this._focMD;
			delete this._drag;
			this._elemID = -1;
			
			if(this._animationDP)
				this._animationDP.play();
			this._animationDP = animation;
		}
		else
		{
			if(this._hasFrame)
				frame.parentNode.removeChild(frame);
			this._hasFrame = false;
			animation.play(elem, false, !!this._slideUp, null, old, old ? old._stop : null);
		}
		var style = elem ? elem.style : null;
		if(!style || !master)
			return;
		
		var d, i = -1, days = this._days;
		while(++i < 47) if(d = days[i]) if(d.hover || (d.focus && !date))
		{
			
			if(!date)
			{
				this._focID = this._selID = -1;
				d.focus = false;
			}
			d.hover = false;
			this._drawDay(i);
		}
		this._hovDay = null;
		
		this._master = master;
		
		this.set_selectedDate(date);
		if(!date)
			this.repaint(this._today.year, this._today.month);
		style.left = style.top = style.marginTop = style.marginLeft = '0px';
		style.position = 'absolute';
		var zi = $util._zIndexTop(master._element, Math.max($util.toInt(style.zIndex, 0), 99999));
		style.zIndex = zi + 1;
		
		style.display = '';
		var p = $util._getDropPoint(master._element, elem);
		style.marginTop = p.y += 'px';
		style.marginLeft = p.x += 'px';
		
		if(!frame)
		{
			this._frame = frame = document.createElement('IFRAME');
			frame.textContent = 'Your browser does not support iframes';
			frame.src = 'javascript:"<html></html>"';
			frame.frameBorder = 0;
			frame.scrolling = 'no';
			frame.allowtransparency = 'true';
		}
		style = frame.style;
		style.position = 'absolute';
		style.zIndex = zi;
		style.left = style.top = '0px';
		style.marginTop = p.y;
		style.marginLeft = p.x;
		style.width = elem.offsetWidth + 'px';
		style.height = elem.offsetHeight + 'px';
		this._hasFrame = true;
		elem.parentNode.insertBefore(frame, elem);
		$util.setOpacity(frame, 0);
		
		if(animation)
			animation.play(elem, true, this._slideUp = p.up ? new Date().getTime() : false, null, master, master._stop);
		
		elem.style.visibility = 'visible';
		
		this._dropShift = null;
		
		if(this._masterTimer && this._once)
		{
			ig_ui_timer(this);
			this._timerOn = 1;
		}
	},
	
	_stop:function(show, id)
	{
		
		this._raiseClientEvent('ListAnimationStopped', 'CalendarListAnimationStopped', null, null, show, id);
	},
	dispose:function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebMonthCalendar.dispose">Disposes object and event handlers.</summary>
		
		if (this._timerOn)
			ig_ui_timer(this, true);
		var dp = this._master, d = this._days;
		var i = d ? d.length : 0;
		while(i-- > 0)
			d[i].element = null;
		if(dp && dp._doCal)
			dp._doCal();
		this._master = null;
		var elem = this._hasFrame ? this._frame : null;
		if(elem)
			elem.parentNode.removeChild(elem);
		this._frame = this._hasFrame = null;
		elem = this._element;
		if(elem)
			$clearHandlers(elem);
		elem = this._elements;
		if(elem && elem[7])
			$clearHandlers(elem[7]);
		if(this._animation)
			this._animation.dispose();
		elem = this._list;
		if(elem)
			elem[0] = elem[1] = null;
		this._pressElem = this._animation = this._list = this._hov = this._hovKey = this._hovDay = this._days = null;
		
		this._onFakePress();
		$IG.WebMonthCalendar.callBaseMethod(this, 'dispose');
	}
}
$IG.WebMonthCalendar.registerClass('Infragistics.Web.UI.WebMonthCalendar', $IG.ControlMain);

$IG.WebMonthCalendar.find = function (clientID)
{
	///<summary locid="M:J#Infragistics.Web.UI.WebMonthCalendar.find">Finds WebMonthCalendar by its client ID.</summary>
	///<param name="clientID" type="String">Client ID of the control to look for.</param>
	///<returns type="Infragistics.Web.UI.WebMonthCalendar">Reference to the WebMonthCalendar control object that corresponds to specified client ID.</returns>
};

$IG.WebMonthCalendar.from = function (obj)
{
	///<summary locid="M:J#Infragistics.Web.UI.WebMonthCalendar.from">Casts passed in object to the WebMonthCalendar type.</summary>
	///<param name="obj">Object to convert to the WebMonthCalendar type.</param>
	///<returns type="Infragistics.Web.UI.WebMonthCalendar">Reference to the same object that is passed in, only type converted to the WebMonthCalendar type.</returns>
};


$IG.CalendarDay = function(elem, id, dow, weekend)
{
	/// <summary locid="T:J#Infragistics.Web.UI.CalendarDay">Class used for days in WebMonthCalendar.</summary>
	/// <param name="elem" domElement="true" mayBeNull="false">Reference to html element.</param>
	/// <param name="id" type="Number" integer="true">Index of day.</param>
	/// <param name="dow" type="Number" integer="true">Day of the week.</param>
	/// <param name="weekend" type="Boolean">True: day is weekend.</param>
	this.element = elem;
	this.index = id;
	this.dow = dow;
	this.weekend = weekend;
	this.hover = false;
	this.day = -1;
	this.weekNumber = -1;
}
$IG.CalendarDay.prototype =
{
	get_day:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.CalendarDay.day">
		/// Gets value of day in month.
		/// Range of values: 1..31. Note: if day is a week number, then -1 is returned.
		/// </summary>
		/// <value type="Number" integer="true">Day of month</value>
		return this.day;
	},
	get_month:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.CalendarDay.month">Gets value of month. Range of values: 1..12.</summary>
		/// <value type="Number" integer="true">Month</value>
		return this.month;
	},
	get_year:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.CalendarDay.year">Gets value of year. Range of values: 2..9999.</summary>
		/// <value type="Number" integer="true">Year</value>
		return this.year;
	},
	get_weekNumber:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.CalendarDay.weekNumber">Gets value of week number. Range of values: 1..53. Note: if it is a day in calendar, then the -1 is returned.</summary>
		/// <value type="Number" integer="true">Week number</value>
		return this.weekNumber;
	},
	get_dow:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.CalendarDay.dow">Gets value of day of the week. Range of values: 0..6. Note: if day is a week number, then -1 is returned.</summary>
		/// <value type="Number" integer="true">Day of week</value>
		return this.dow;
	},
	get_css:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.CalendarDay.css">
		/// Gets sets value of css class used by day's TD element.
		/// Notes: If day is disabled, then the "get" method does not include css for disabled state.
		/// The "set" method will override all default values, so, it is recommended to append new classes to existing. Example:
		/// day.set_css(day.get_css() + ' myCss');
		/// </summary>
		/// <value type="String">Css class name</value>
		return this.css;
	},
	set_css:function(val)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.CalendarDay.css">Sets css class used by day's TD element.</summary>
		/// <param name="val" type="String">Name of css class</param>
		this.css = val;
	},
	get_text:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.CalendarDay.text">Gets sets value of text used by day. It is used for text/innerHTML of day's TD element.</summary>
		/// <value type="String">Text in day</value>
		return this.text;
	},
	set_text:function(val)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.CalendarDay.text">Sets text.</summary>
		/// <param name="val" type="String">Text displayed in day</param>
		this.text = val;
	},
	isHover:function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.CalendarDay.isHover">Checks if day has hover style.</summary>
		/// <returns type="Boolean">True: day has hover style.</returns>
		return this.hover == true;
	},
	isSelected:function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.CalendarDay.isSelected">Checks if day has selected style.</summary>
		/// <returns type="Boolean">True: day has selected style.</returns>
		return this.selected == true;
	},
	isFocus:function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.CalendarDay.isFocus">Checks if day has focus style.</summary>
		/// <returns type="Boolean">True: day has focus style.</returns>
		return this.focus == true;
	},
	get_disabled:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.CalendarDay.disabled">Gets sets disabled state of day as boolean.</summary>
		/// <value type="Boolean">True: day is disabled</value>
		return this.disabled == true;
	},
	set_disabled:function(val)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.CalendarDay.disabled">Sets disabled state.</summary>
		/// <param name="val" type="Boolean">True: day is disabled</param>
		this.disabled = val;
	},
	isOtherMonth:function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.CalendarDay.isOtherMonth">Checks if day belongs to the previous or next month.</summary>
		/// <returns type="Boolean">True: day is located in previous or next month.</returns>
		return this.other == true;
	},
	isToday:function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.CalendarDay.isToday">Checks if day is today.</summary>
		/// <returns type="Boolean">True: day is today.</returns>
		return this.today == true;
	},
	isWeekend:function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.CalendarDay.isWeekend">Checks if day is weekend.</summary>
		/// <returns type="Boolean">True: day is weekend.</returns>
		return this.weekend == true;
	},
	get_element:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.CalendarDay.element">Gets reference to the TD html element used by day.</summary>
		/// <returns domElement="true">Reference to html element</returns>
		return this.element;
	},
	get_index:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.CalendarDay.index">Gets value of index within grid of calendar. Range of values: 0..47. Day in calendar: 0..41, week number: 42..47.</summary>
		/// <value type="Number" integer="true">Index of day</value>
		return this.index;
	}
}
$IG.CalendarDay.registerClass('Infragistics.Web.UI.CalendarDay');


$IG.VisibleMonthChangingEventArgs = function()
{
	/// <summary locid="T:J#Infragistics.Web.UI.VisibleMonthChangingEventArgs">Class used as EventArgs while raising events before visible month change in WebMonthCalendar.</summary>
	$IG.VisibleMonthChangingEventArgs.initializeBase(this);
}
$IG.VisibleMonthChangingEventArgs.prototype =
{
	
	get_date:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.VisibleMonthChangingEventArgs.date">Gets sets new date.</summary>
		/// <value type="Date">New date</value>
		return this._props[2];
	},
	get_oldDate:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.VisibleMonthChangingEventArgs.oldDate">Gets old date.</summary>
		/// <value type="Date">Old date</value>
		return this._props[3];
	},
	set_date:function(val)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.VisibleMonthChangingEventArgs.date">Sets selected date</summary>
		/// <param name="val" type="Date">Selected date</param>
		this._props[2] = val;
	}
}
$IG.VisibleMonthChangingEventArgs.registerClass('Infragistics.Web.UI.VisibleMonthChangingEventArgs', $IG.CancelEventArgs);


$IG.VisibleMonthChangedEventArgs = function()
{
	/// <summary locid="T:J#Infragistics.Web.UI.VisibleMonthChangedEventArgs">Class used as EventArgs while raising events after visible month was changed in WebMonthCalendar.</summary>
	$IG.VisibleMonthChangedEventArgs.initializeBase(this);
}
$IG.VisibleMonthChangedEventArgs.prototype =
{
	
	get_date:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.VisibleMonthChangedEventArgs.date">Gets new date.</summary>
		/// <value type="Date">New date</value>
		return this._props[2];
	},
	get_oldDate:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.VisibleMonthChangedEventArgs.oldDate">Gets old date.</summary>
		/// <value type="Date">Old date</value>
		return this._props[3];
	}
}
$IG.VisibleMonthChangedEventArgs.registerClass('Infragistics.Web.UI.VisibleMonthChangedEventArgs', $IG.PostBackEventArgs);


$IG.CalendarSelectionChangingEventArgs = function()
{
	/// <summary locid="T:J#Infragistics.Web.UI.CalendarSelectionChangingEventArgs">Class used as EventArgs while raising events before selection in WebMonthCalendar is changed.</summary>
	$IG.CalendarSelectionChangingEventArgs.initializeBase(this);
}
$IG.CalendarSelectionChangingEventArgs.prototype =
{
	
	get_dates:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.CalendarSelectionChangingEventArgs.dates">
		/// Gets sets array of new dates.
		/// If dates are set, then they should be sorted in ascending order.
		/// </summary>
		/// <value type="Array" mayBeNull="true" elementType="Date">Array of dates</value>
		return this._props[6]._toDates(this._props[2]);
		
	},
	get_oldDates:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.CalendarSelectionChangingEventArgs.oldDates">Gets array of old dates.</summary>
		/// <value type="Array" mayBeNull="true" elementType="Date">Array of dates</value>
		return this._props[6]._toDates(this._props[3]);
		
	},
	
	get_range:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.CalendarSelectionChangingEventArgs.range">
		/// Gets sets array of 2 dates which point to start and end of range.
		/// </summary>
		/// <value type="Array" mayBeNull="true" elementType="Date">Array of dates</value>
		return this._props[6]._toDates(this._props[4], true);
		
	},
	get_oldRange:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.CalendarSelectionChangingEventArgs.oldRange">Gets array of 2 dates if old range selection was available.</summary>
		/// <value type="Array" mayBeNull="true" elementType="Date">Array of dates</value>
		return this._props[6]._toDates(this._props[5], true);
		
	},
	set_range:function(dates)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.CalendarSelectionChangingEventArgs.range">
		/// Sets range of selected dates.
		/// Note: It does not change possible selected dates and it has effect only when multi selection is enabled.
		/// </summary>
		/// <param name="dates" type="Array" mayBeNull="true" elementType="Date">Array of minimum and maximum dates</param>
		this._props[4] = this._props[6]._toYMDs(dates);
		
	},
	set_dates:function(dates)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.CalendarSelectionChangingEventArgs.dates">
		/// Sets selected dates.
		/// Note: dates should be sorted in ascending order.
		/// </summary>
		/// <param name="dates" type="Array" mayBeNull="true" elementType="Date">Array of dates</param>
		this._props[2] = this._props[6]._toYMDs(dates);
		
	}
}
$IG.CalendarSelectionChangingEventArgs.registerClass('Infragistics.Web.UI.CalendarSelectionChangingEventArgs', $IG.CancelEventArgs);


$IG.CalendarSelectionChangedEventArgs = function()
{
	/// <summary locid="T:J#Infragistics.Web.UI.CalendarSelectionChangedEventArgs">Class used as EventArgs while raising events after selection in WebMonthCalendar was changed.</summary>
	$IG.CalendarSelectionChangedEventArgs.initializeBase(this);
}
$IG.CalendarSelectionChangedEventArgs.prototype =
{
	
	get_dates:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.CalendarSelectionChangedEventArgs.dates">Gets array of new dates.</summary>
		/// <value type="Array" mayBeNull="true" elementType="Date">Array of dates</value>
		return this._props[6]._toDates(this._props[2]);
		
	},
	get_oldDates:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.CalendarSelectionChangedEventArgs.oldDates">Gets array of old dates.</summary>
		/// <value type="Array" mayBeNull="true" elementType="Date">Array of dates</value>
		return this._props[6]._toDates(this._props[3]);
		
	},
	
	get_range:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.CalendarSelectionChangedEventArgs.range">Gets array of 2 dates if range selection is available.</summary>
		/// <value type="Array" mayBeNull="true" elementType="Date">Array of dates</value>
		return this._props[6]._toDates(this._props[4], true);
		
	},
	get_oldRange:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.CalendarSelectionChangedEventArgs.oldRange">Gets array of 2 dates if old range selection was available.</summary>
		/// <value type="Array" mayBeNull="true" elementType="Date">Array of dates</value>
		return this._props[6]._toDates(this._props[5], true);
		
	}
}
$IG.CalendarSelectionChangedEventArgs.registerClass('Infragistics.Web.UI.CalendarSelectionChangedEventArgs', $IG.PostBackEventArgs);


$IG.CalendarRenderDayEventArgs = function()
{
	/// <summary locid="T:J#Infragistics.Web.UI.CalendarRenderDayEventArgs">Class used as EventArgs while raising events before a day in WebMonthCalendar is rendered.</summary>
	$IG.CalendarRenderDayEventArgs.initializeBase(this);
}
$IG.CalendarRenderDayEventArgs.prototype =
{
	
	get_day:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.CalendarRenderDayEventArgs.day">Gets reference to CalendarDay object which contains properties related to rendered day.</summary>
		/// <value type="Infragistics.Web.UI.CalendarDay">Day</value>
		return this._props[2];
	}
}
$IG.CalendarRenderDayEventArgs.registerClass('Infragistics.Web.UI.CalendarRenderDayEventArgs', $IG.CancelEventArgs);


$IG.CalendarListOpeningEventArgs = function()
{
	/// <summary locid="T:J#Infragistics.Web.UI.CalendarListOpeningEventArgs">Class used as EventArgs while raising events before list of months, years or year groups in WebMonthCalendar is opened.</summary>
	$IG.CalendarListOpeningEventArgs.initializeBase(this);
}
$IG.CalendarListOpeningEventArgs.prototype =
{
	
	get_id:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.CalendarListOpeningEventArgs.id">Gets id of list involved in event.</summary>
		/// <value type="Number">Possible values: 1 - list of months, 2 - list of years, 3 - list of year groups.</value>
		return this._props[2];
	}
}
$IG.CalendarListOpeningEventArgs.registerClass('Infragistics.Web.UI.CalendarListOpeningEventArgs', $IG.CancelEventArgs);


$IG.CalendarListOpenedEventArgs = function()
{
	/// <summary locid="T:J#Infragistics.Web.UI.CalendarListOpenedEventArgs">Class used as EventArgs while raising events after list of months, years or year groups in WebMonthCalendar was opened.</summary>
	$IG.CalendarListOpenedEventArgs.initializeBase(this);
}
$IG.CalendarListOpenedEventArgs.prototype =
{
	
	get_id:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.CalendarListOpenedEventArgs.id">Gets id of list involved in event.</summary>
		/// <value type="Number">Possible values: 1 - list of months, 2 - list of years, 3 - list of year groups.</value>
		return this._props[2];
	}
}
$IG.CalendarListOpenedEventArgs.registerClass('Infragistics.Web.UI.CalendarListOpenedEventArgs', $IG.EventArgs);


$IG.CalendarListCloseEventArgs = function()
{
	/// <summary locid="T:J#Infragistics.Web.UI.CalendarListCloseEventArgs">Class used as EventArgs while raising events before and after list of months, years or year groups in WebMonthCalendar is closed.</summary>
	$IG.CalendarListCloseEventArgs.initializeBase(this);
}
$IG.CalendarListCloseEventArgs.prototype =
{
	
	get_selectedValue:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.CalendarListCloseEventArgs.selectedValue">
		/// Gets value selected in list.
		/// </summary>
		/// <value type="Number">Possible values: -1 means no selected item. In case of list of months, the range of values is 1-12, otherwise, value is selected year.</value>
		return this._props[3];
	},
	
	get_id:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.CalendarListCloseEventArgs.id">Gets id of list involved in event.</summary>
		/// <value type="Number">Possible values: 1 - list of months, 2 - list of years, 3 - list of year groups.</value>
		return this._props[2];
	}
}
$IG.CalendarListCloseEventArgs.registerClass('Infragistics.Web.UI.CalendarListCloseEventArgs', $IG.CancelEventArgs);


$IG.CalendarListAnimationStoppedEventArgs = function()
{
	/// <summary locid="T:J#Infragistics.Web.UI.CalendarListAnimationStoppedEventArgs">Class used as EventArgs while raising events after animation of list was stopped.</summary>
	$IG.CalendarListAnimationStoppedEventArgs.initializeBase(this);
}
$IG.CalendarListAnimationStoppedEventArgs.prototype =
{
	
	get_opened:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.CalendarListAnimationStoppedEventArgs.opened">Checks if list was opened or closed.</summary>
		/// <value type="Boolean">True: list was opened, false: list was closed.</value>
		return this._props[2];
	},
	
	get_id:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.CalendarListAnimationStoppedEventArgs.id">Gets id of list involved in event.</summary>
		/// <value type="Number">Possible values: 1 - list of months, 2 - list of years, 3 - list of year groups.</value>
		return this._props[3];
	}
}
$IG.CalendarListAnimationStoppedEventArgs.registerClass('Infragistics.Web.UI.CalendarListAnimationStoppedEventArgs', $IG.EventArgs);
