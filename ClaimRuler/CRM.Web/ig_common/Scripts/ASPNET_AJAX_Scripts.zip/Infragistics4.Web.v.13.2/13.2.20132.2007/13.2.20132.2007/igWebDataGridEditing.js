/*
* igWebDataGridEditing.js
* Version 13.2.20132.2007
* Copyright(c) 2001-2013 Infragistics, Inc. All Rights Reserved.
*/



$IG.EditingCore = function(obj, objProps, control, parentCollection, hierarchical)
{
	///<summary locid="T:J#Infragistics.Web.UI.EditingCore">
	///Updating behavior object of the grid.
	///</summary>
	$IG.EditingCore.initializeBase(this, [obj, objProps, control, parentCollection]);

	this._hierarchical = hierarchical;
	this._rowsToDelete = new $IG.GridAffectedItems();
	this._addRowCellValues = null;	

	this._cellValueChangingListener = Function.createDelegate(this, this._cellValueChanging);
	control._gridUtil._registerEventListener(control, "CellValueChanging", this._cellValueChangingListener);
	
	this._onTriggerCommit = Function.createDelegate(this, this._forceUpdateCommit);
	control._gridUtil._registerEventListener(control, "TriggerCommit", this._onTriggerCommit);

	this._cellValueChangedListener = Function.createDelegate(this, this._cellValueChanged);
	control._gridUtil._registerEventListener(control, "CellValueChanged", this._cellValueChangedListener);
	this._onRowsDeletingListener = Function.createDelegate(this, this._onRowsDeleting);
	control._gridUtil._registerEventListener(control, "RowsDeleted", this._onRowsDeletingListener);
	this._onRowAddingListener = Function.createDelegate(this, this._onRowAdding);
	control._gridUtil._registerEventListener(control, "RowAdded", this._onRowAddingListener);
	
	this._onHeaderCheckBoxClickedListener = Function.createDelegate(this, this._onHeaderCheckBoxClicked);
	control._gridUtil._registerEventListener(control, "HeaderCheckBoxClicked", this._onHeaderCheckBoxClickedListener);
	
	this._actions = {};
	
    this._batchUpdating = this._get_clientOnlyValue("bu");
    if (this._batchUpdating)
    {
        this._itemCssClass = this._get_clientOnlyValue("ric");
        this._altItemCssClass = this._get_clientOnlyValue("rac");
        this._updatedRowCssClass = this._get_clientOnlyValue("urc");
        this._deletedRowCssClass = this._get_clientOnlyValue("drc");
        this._addingRowCssClass = this._get_clientOnlyValue("aric");
        this._addedRowCssClass = this._get_clientOnlyValue("arc");
        this._expansionColClass = this._get_clientOnlyValue("ecc");
        this._groupIndentCellClass = this._get_clientOnlyValue("gic");
		this._undoBtnHoverClass = this._get_clientOnlyValue("ubh");
        this._undoBtnPressedClass = this._get_clientOnlyValue("ubp");
        this._dataKeyFields = new Object();
        this._emptyDataKeyString = this._get_clientOnlyValue("adk");
        this._addRowCounter = 0;
        var dataKeys = this._get_clientOnlyValue('dkf').split(',');
	    for (var x = 0; x < dataKeys.length; ++x)
        {
            this._dataKeyFields[dataKeys[x]] = x;
        }
        this._addingActions = {};
        this._deletingActions = {};
        this._undoSpan = $get(this._grid._id + "_undoBtnDiv");
        if (this._undoSpan)
        {
            this._undoBtn = this._undoSpan.firstChild;
            if (this._undoBtn.tagName != "INPUT")
                this._undoBtn = this._undoBtn.nextSibling;
			this._onMouseOverUndoBtnHandler = Function.createDelegate(this, this._onMouseOverUndoBtn);
		    $addHandler(this._undoBtn, 'mouseover', this._onMouseOverUndoBtnHandler);
			this._onMouseOutUndoBtnHandler = Function.createDelegate(this, this._onMouseOutUndoBtn);
		    $addHandler(this._undoBtn, 'mouseout', this._onMouseOutUndoBtnHandler);
            this._onMouseDownUndoBtnHandler = Function.createDelegate(this, this._onMouseDownUndoBtn);
		    $addHandler(this._undoBtn, 'mousedown', this._onMouseDownUndoBtnHandler);
			this._onMouseClickUndoBtnHandler = Function.createDelegate(this, this._onMouseClickUndoBtn);
		    $addHandler(this._undoBtn, 'click', this._onMouseClickUndoBtnHandler);
            this._onKeyDownUndoBtnnHandler = Function.createDelegate(this, this._onKeyDownUndoBtn);
		    $addHandler(this._undoBtn, 'keydown', this._onKeyDownUndoBtnnHandler);
            
	        this._onScrollTopChangeHandler = Function.createDelegate(this, this._onScrollTopChange);
	        this._grid._gridUtil._registerEventListener(this._grid, "ScrollTopChange", this._onScrollTopChangeHandler);
        }

        this._gridElementKeyDownHandler = Function.createDelegate(this, this._onKeydownHandler);
        this._grid._addElementEventHandler(this._grid._container, "keydown", this._gridElementKeyDownHandler);
		
        if (this._hierarchical && this._grid._enableAjax)
		{
			this._batchUpdatingActionList = new $IG.GridActionTransactionList();
			this._onSavingActionsHandler = Function.createDelegate(this, this._onSavingActions);
	        this._grid._gridUtil._registerEventListener(this._grid, "SavingActions", this._onSavingActionsHandler);
		}
		else
			this._batchUpdatingActionList = this._grid._actionList;
    }
	else
        this._batchUpdatingActionList = this._grid._actionList;
}

$IG.EditingCore.prototype =
{
	commit: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.EditingCore.commit">
		/// Commits all of the changes to the server.
		/// </summary>
		
		var shouldPost = this._commitUpdates(false);
		shouldPost = this._commitDeletes(false) || shouldPost;
		shouldPost = this._commitAdds(false) || shouldPost;

		if (this._batchUpdating && !shouldPost)
		{
			for (var actionKey in this._actions)
			{
				var action = this._actions[actionKey];
				if (!action._commited)
				{
					action._commited = true;
					shouldPost = true;
				}
				if (action._commited)
					delete this._actions[actionKey];
			}
			for (var actionKey in this._addingActions)
			{
				var action = this._addingActions[actionKey];
				if (!action._commited)
				{
					action._commited = true;
					shouldPost = true;
				}
				if (action._commited)
					delete this._addingActions[actionKey];
			}
			for (var actionKey in this._deletingActions)
			{
				var action = this._deletingActions[actionKey];
				if (!action._commited)
				{
					action._commited = true;
					shouldPost = true;
				}
				if (action._commited)
					delete this._deletingActions[actionKey];
			}
		}

		var eventArgs = new $IG.CancelBehaviorEventArgs(this);
		if (shouldPost)
			eventArgs._props[1] = this._get_owner()._enableAjax ? 2 : 1;
		this._get_owner()._raiseClientEventEnd(eventArgs);
	},

	_commitUpdates: function (fireServerEvent)
	{
		if (typeof fireServerEvent == "undefined")
			fireServerEvent = true;
		var commitUpdate = false;
		for (var actionKey in this._actions)
		{
			var action = this._actions[actionKey];
			if (!action._commited && !action._only_fromHeaderChecked())
			{
				var clientRendering = this._owner.get_enableClientRendering();
				var row = action._object;
				var updatedCells = action.get_updatedCells();
				var eventArgs = (!clientRendering ? new $IG.CancelUpdateRowEventArgs(this, row, updatedCells)
					: new $IG.ClientCancelUpdateRowEventArgs(this, row, updatedCells));

				if (this._clientEvents["RowUpdating"])
					this._owner._raiseSenderClientEventStart(this, this._clientEvents["RowUpdating"], eventArgs);

				if (!eventArgs.get_cancel())
				{
					if (this._clientEvents["RowUpdating"])
					{
						
						if (this._clientEvents["RowUpdating"].postBack > 0)
						{
							action._commited = true;
							commitUpdate = true;
						}
						if (fireServerEvent)
							this._get_owner()._raiseClientEventEnd(eventArgs);
					}
					if (this._batchUpdating && this._clientEvents["RowUpdated"])
					{
						var rowUpdatedEventArgs = new $IG.RowUpdatedEventArgs(this, row);
						this._owner._raiseSenderClientEvent(this, this._clientEvents["RowUpdated"], rowUpdatedEventArgs);
					}
					
					// clear/remove update action/transaction flags for event, which will be raised on server
					var posted = fireServerEvent || commitUpdate ? this._get_owner()._posted : 0;
					// delay (<100): IE:40-45, Firefox:5-9, Safari:10-35, Chrome:3-10
					if (posted && new Date().getTime() - posted < 100)// || this._get_owner()._get_isAjaxCallInProgress())
					{
						updatedCells.clear();
						this._batchUpdatingActionList.remove_transaction(action, true);
						delete this._actions[actionKey];
					}
				}
				else if (clientRendering && eventArgs.get_cancel() && eventArgs.get_selfUpdate())
					action._commited = true;
				else
				{
					for (var i = 0; i < updatedCells.get_length(); i++)
					{
						var change = updatedCells.getItem(i);
						var column = this._grid.get_columns().get_columnFromIDPair(change.colIdPair);
						var cell = row.get_cellByColumn(column);
						
						cell._set_value_internal(change.oldValue, change.oldText);
					}
					updatedCells.clear();
					this._batchUpdatingActionList.remove_transaction(action, true);
					
					delete this._actions[actionKey];
					if (this._batchUpdating)
					{
						row._updated = null;
						this._owner._gridUtil._removeStyleFromRow(row.get_element(), this._updatedRowCssClass);
					}
				}
				if (action && action._commited)
					delete this._actions[actionKey];
			}
			
			else if (action._only_fromHeaderChecked())
			{
				commitUpdate = true;
				delete this._actions[actionKey];
			}
		}
		return commitUpdate;
	},

	_commitDeletes: function (fireServerEvent)
	{
		if (typeof fireServerEvent == "undefined")
			fireServerEvent = true;
		if (this._rowsToDelete.get_length() > 0)
		{
			var RowsDeletingEventArgs = new $IG.CancelRowsDeletingEventArgs(this, this._rowsToDelete);

			if (this._clientEvents["RowsDeleting"])
				this._owner._raiseSenderClientEventStart(this, this._clientEvents["RowsDeleting"], RowsDeletingEventArgs);

			if (!RowsDeletingEventArgs.get_cancel())
			{

				rows = RowsDeletingEventArgs.get_rows();
				var numRows = rows.get_length();
				var row;
				var rowIdPairs = new Array();

				//Loop through collection of rows targeted for deletion and save the rowIdPairs
				for (var i = numRows - 1; i >= 0; i--)
				{
					row = rows.getItem(i);
					if (row.get_idPair) 
						rowIdPairs[i] = row.get_idPair();
					else 
						rowIdPairs[i] = row;
				}

				//Sort the rowIdPairs to ensure that the rows are deleted in the correct order
				rowIdPairs.sort(this._sortRowIdPairs);

				//Clear the selected rows
				if (this._selection)
				{
					this._selection._selectedRowCollection.clear();
					this._selection._selectedCellCollection.clear();
				}

				if (this._batchUpdating)
				{
					for (var x = 0; x < numRows; ++x)
					{
						var smallArray = [];
						smallArray[0] = rowIdPairs[x];
						var action = new $IG.GridAction("DeleteRow", "EditingCore", this._get_owner(), smallArray);
						this._addDeleteAction(action, rowIdPairs[x]);
						this._batchUpdatingActionList.add_transaction(action, true);
					}
				}
				else
					this._get_owner()._actionList.add_transaction(new $IG.GridAction("DeleteRow", "EditingCore", this._get_owner(), rowIdPairs));
				if (fireServerEvent)
					this._get_owner()._raiseClientEventEnd(RowsDeletingEventArgs);
				if (this._batchUpdating)
				{
					var grid = this._get_owner();
					var rows = grid.get_rows();
					var rowArray = [];
					var rowCount = rows.get_length();
					var needFixing = false;
					for (var i = 0; i < rowIdPairs.length; ++i)
					{
						row = rows.get_rowFromIDPair(rowIdPairs[i]);
						if (row)
						{
							row._updated = row._updated == $IG.RowUpdateStatus.Added ? $IG.RowUpdateStatus.AddedButDeleted : $IG.RowUpdateStatus.Deleted;
							rowArray[rowArray.length] = row;
						}
					}
					for (var i = 0; i < rowArray.length; ++i)
					{
						row = rowArray[i];
						if (row._updated == $IG.RowUpdateStatus.AddedButDeleted)
						{
							var action = this._removeAddAction(row);
							var oldAction = this._getDeleteAction(row);
							this._removeDeleteAction(row);
							this._addDeleteAction(action, row);
							this._batchUpdatingActionList.remove_transaction(oldAction, true);
							grid._gridUtil._removeStyleFromRow(row.get_element(), this._addingRowCssClass);
							grid._gridUtil._removeStyleFromRow(row.get_element(), this._addedRowCssClass);
						}
						grid._gridUtil._removeStyleFromRow(row.get_element(), this._updatedRowCssClass);
						grid._gridUtil._addStyleToRow(row.get_element(), this._deletedRowCssClass);
						if (row._get_rowType && row._get_rowType() == "ContainerGridRow")
						{
							row._oldRowIslands = row._rowIslands;
							row._rowIslands = [];
							row.set_expanded(false);
							row.__expandingInProgress = true;
							var groupedCols = this._grid._get_band().get_groupingSettings().get_groupedColumns();
							for (var c = 0; c < groupedCols.get_length(); ++c)
							{
								var groupedColkey = groupedCols.getItem(c).get_columnKey();
								var cell = row.get_cellByColumnKey(groupedColkey);
								if (cell.get_element().className.indexOf(this._grid._mergeClassBase) > -1)
									this._grid._gridUtil._splitMergingForCell(cell, this._grid._mergeClassBase);
							}
						}
						else if (row.get_index() == 0)
						{
							
							if (this._rowIsHidden(row))
								this._grid._createSizingRow();
						}
						grid._gridUtil._fireEvent(grid, "RowDeletedBatch", { "row": row });
					}
					var deleting = this.get_behaviors().get_rowDeleting();
					if (deleting && deleting._prevActiveCell)
					{
						if (deleting._prevActiveCell.get_row().get_index() > -1 && !this._rowIsHidden(deleting._prevActiveCell.get_row()))
							this._showUndoBtn(deleting._prevActiveCell.get_row(), true);
						deleting._prevActiveCell = null;
					}

					var deletionExemptRows = new Array();
					var RowsDeletedEventArgs = new $IG.RowsDeletedEventArgs(this, deletionExemptRows);
					if (this._clientEvents["RowsDeleted"])
						this._owner._raiseSenderClientEventStart(this, this._clientEvents["RowsDeleted"], RowsDeletedEventArgs);
					this._rowsToDelete.clear();
				}
				return true;
			}
			else
				this._rowsToDelete.clear();
		}
		return false;
	},

	_reapplyRowStyling: function (startIndex)
	{
		var rows = this._get_owner().get_rows();
		var rowCount = rows.get_length();
		var prevNum = null;
		var gridUtil = this._grid._gridUtil;
		for (var i = startIndex; i < rowCount; ++i)
		{
			var row = rows.get_row(i);
			var rowEl = row.get_element();
			gridUtil._removeStyleFromRow(rowEl, this._altItemCssClass);
			if (i % 2 == 1)
				gridUtil._addStyleToRow(rowEl, this._altItemCssClass);
			rowEl.setAttribute('adr', i);
		}
	},

	_commitAdds: function (fireServerEvent)
	{
		if (typeof fireServerEvent == "undefined")
			fireServerEvent = true;
		if (this._addRowCellValues)
		{
			var row = null;
			if (this._addNew)
				row = this._addNew.get_row();
			var eventArgs = new $IG.CancelAddRowEventArgs(this, row, this._addRowCellValues);

			if (this._clientEvents["RowAdding"])
				this._owner._raiseSenderClientEventStart(this, this._clientEvents["RowAdding"], eventArgs);

			if (!eventArgs.get_cancel())
			{
				var newRow;
				if (this._batchUpdating)
				{
					var grid = this._get_owner();
					
					newRow = document.createElement('tr');
					var index = grid.get_rows().get_length();
					var args = null;
					if (index == 0)
					{
						//remove the empty template
						var tBodyRows = grid._elements.dataTbl.firstChild;
						if (tBodyRows.nodeName == "#text")
							tBodyRows = tBodyRows.nextSibling;
						this._emptyTemplate = tBodyRows.innerHTML;
						tBodyRows.parentNode.removeChild(tBodyRows);
						tBodyRows = document.createElement("tbody");
						tBodyRows.className = this._itemCssClass;
						tBodyRows.setAttribute('mkr', 'rows');
						tBodyRows.setAttribute('nw', '1');
						grid._elements.dataTbl.appendChild(tBodyRows);
						grid._elements["rows"] = tBodyRows;
						grid._rows = new $IG.GridRowCollection(grid._elements["rows"], [grid._get_value($IG.WebDataGridProps.RowCount)], grid);
						args = { "tbodyRows": tBodyRows };
						grid._gridUtil._fireEvent(grid, "RemovedEmptyTemplate", args);
					}
					args = { "row": newRow, "index": index, "groupIndentCellClass": this._groupIndentCellClass, "expansionColClass": this._expansionColClass };
					grid._gridUtil._fireEvent(grid, "StartNewBatchRow", args);
					grid._gridUtil._fireEvent(grid, "NewBatchRowBeforeCells", args);

					if (!newRow.getAttribute('id'))
						newRow.setAttribute('id', 'x:a' + index);
					newRow.setAttribute('type', 'row');
					newRow.setAttribute('adr', index);
					newRow.setAttribute('tag', '');
					args = { "row": newRow, "cancel": false, "itemCssClass": this._itemCssClass };
					grid._gridUtil._fireEvent(grid, "NewBatchRowAddingCells", args);
					var colCount = grid.get_columns().get_length();
					if (!args.cancel)
					{
						for (var c = 0; c < colCount; ++c)
						{
							var td = document.createElement('td');
							if ($util.IsIE)
								td.appendChild(document.createComment(''));
							newRow.appendChild(td);
						}
					}
					grid._gridUtil._addStyleToRow(newRow, this._addingRowCssClass);
					if (index % 2 == 1)
						grid._gridUtil._addStyleToRow(newRow, this._altItemCssClass);
					var newRowObj = new $IG.GridRow(index, newRow, [], grid, null);
					var dataKey = '';
					var dataKeyArray = [];
					var fromAddRow = false, emptyDataKey = true;
					var templatedCols = [];
					for (var x = 0; x < colCount; ++x)
					{
						var newValObj = this._addRowCellValues[x];
						var col = grid.get_columns().get_column(x);
						if (col.get_isTemplated() && grid.get_enableClientRendering())
							templatedCols[templatedCols.length] = col;
						var key = newValObj && newValObj.DataKeyField ? newValObj.DataKeyField : col.get_key();
						if (newValObj && newValObj.DataKeyField)
							fromAddRow = true;
						var value = fromAddRow ? newValObj.Value : newValObj;
						var cell = key ? newRowObj.get_cellByColumnKey(key) : newRowObj.get_cell(x);
						var cellElement = cell.get_element();
						var textOrCheckstate = undefined;
						if (col.get_isCheckbox())
						{
							var imgCheckbox = document.createElement('img');
							imgCheckbox.setAttribute('chkState', '2');
							imgCheckbox.setAttribute('src', col._partialUrl);
							imgCheckbox.setAttribute('alt', col._partialAlt);
							imgCheckbox.setAttribute('title', col._partialAlt);
							cellElement.innerHTML = "";
							cellElement.appendChild(imgCheckbox);
							cellElement.setAttribute("val", "null");
							if (col._checkboxCellText)
								cellElement.appendChild(document.createTextNode(col._checkboxCellText));
							
							if (newValObj && newValObj.DataKeyField && this._addNew && row)
								textOrCheckstate = row.get_cell(x)._getCheckState();
							if (col._headerCheckbox)
							{
								col._set_totalRowCount(col._get_totalRowCount() + 1);
								cell._force = true;
								if (value === null)
									col._set_partialCount(col.get_partialCount() + 1);
								else if (value === true)
									col._set_checkedCount(col.get_checkedCount() + 1);
							}
						}
						
						if (newValObj && newValObj.Text !== undefined)
						{
							textOrCheckstate = newValObj.Text;
							delete newValObj.Text;
						}

						$util.addCompoundClass(cellElement, col._css);
						if (col._get_hiddenCss())
							$util.addCompoundClass(cellElement, col._get_hiddenCss());
						args = { "cellElement": cellElement, "key": key };
						if (index == 0)
						{
							if (col.get_width())
								cellElement.style.width = col.get_width();
							else if (grid.get_defaultColumnWidth())
								cellElement.style.width = grid.get_defaultColumnWidth();
						}
						grid._gridUtil._fireEvent(grid, "BatchCellAddCss", args);
						cell._set_value_internal(value, textOrCheckstate);
						cell._force = null;
						if (this._dataKeyFields[key] != null)
						{
							
							if (value !== null && (!newValObj || newValObj.IsNull === undefined || !newValObj.IsNull))
							{
								emptyDataKey = false;
								if (grid._get_dateDataKeyIndeces() && grid._get_dateDataKeyIndeces().indexOf(this._dataKeyFields[key] + ',') > -1)
									dataKeyArray[this._dataKeyFields[key]] = Sys.Serialization.JavaScriptSerializer.serialize(grid._gridUtil._convertClientDateToServerString(value));
								else
									dataKeyArray[this._dataKeyFields[key]] = Sys.Serialization.JavaScriptSerializer.serialize(value);
							}
							if (newValObj)
								delete newValObj.IsNull;
						}
					}
					if (grid.get_enableClientRendering())
					{
						var newDataItem = this._addRowToClientDataSource(newRowObj);
						if (templatedCols.length > 0)
						{
							var tableTemplate = $("<div></div>").html(grid._tableTemplate);
							var rowTemplate = tableTemplate[0].firstChild;
							for (var x = 0; x < templatedCols.length; ++x)
							{
								var column = templatedCols[x];
								var offset = grid._cell_index_offset + column.get_visibleIndex();
								
								var cellTemplate = newRowObj._get_cellElementByIndex(rowTemplate, offset);
								var newCellEl = newRowObj.get_cellByColumnKey(column.get_key()).get_element();
								$.tmpl(cellTemplate.innerHTML, newDataItem, { grid: grid, rowIndex: index }).appendTo(newCellEl);
							}
						}
					}
					dataKey = '[' + dataKeyArray + ']';
					if (dataKey == '[]' || emptyDataKey)
						dataKey = '["' + this._emptyDataKeyString + (this._addRowCounter++) + '"]';
					var dataKeyComment = document.createComment(dataKey);
					grid._elements["rows"].appendChild(newRow);
					grid._gridUtil._addStyleToRow(newRow, this._addedRowCssClass);
					grid._elements["rows"].appendChild(dataKeyComment);
					grid.get_rows()._set_length(index + 1);
					newRow = grid.get_rows().get_row(index);
					newRow._updated = $IG.RowUpdateStatus.Added;

					grid._gridUtil._fireEvent(grid, "RowAddedBatch", { "row": newRow });
					var firstVisCol = grid._gridUtil._findFirstVisibleColumn();
					if (firstVisCol)
					{
						setTimeout(function ()
						{
							
							
							if ($util.IsIE8 && !grid.get_behaviors().get_virtualScrolling())
								grid._onResize({ clientHeight: grid._element.clientHeight });
							newRow.get_cell(firstVisCol.get_index()).scrollToView();
						}, 100);
					}
					
					
					if (this._addNew && fromAddRow)
						this._addNew.clearAddNewRow(true);
					

				}
				




				
				var isDate = {};
				for (var i = 0; i < this._addRowCellValues.length; i++)
				{
					var column = (this._addRowCellValues[i] && this._addRowCellValues[i].DataKeyField ? this._get_owner().get_columns().get_columnFromKey(this._addRowCellValues[i].DataKeyField) : this._get_owner().get_columns().get_column(i));
					if (column && column.get_type() == "date")
					{
						if (this._addRowCellValues[i] && this._addRowCellValues[i].DataKeyField)
						{
							this._addRowCellValues[i].Value = this._get_owner()._gridUtil._convertClientDateToServerString(this._addRowCellValues[i].Value);
							this._addRowCellValues[i].IsDate = true;
						}
						else if (this._addRowCellValues[i])
						{
							isDate[i.toString()] = true;
							this._addRowCellValues[i] = this._get_owner()._gridUtil._convertClientDateToServerString(this._addRowCellValues[i]);
						}
					}
				}
				var addAction = new $IG.AddedRowAction("AddRow", "EditingCore", this._get_owner().get_behaviors().get_editingCore(), this._addRowCellValues, isDate);
				this._batchUpdatingActionList.add_transaction(addAction, true);
				if (this._batchUpdating)
				{
					this._addAddAction(addAction, newRow);
					
					if (this._clientEvents["RowAdded"])
					{
						var evtArgs = new $IG.RowAddedEventArgs(newRow, newRow.get_idPair());
						this._owner._raiseSenderClientEvent(this, this._clientEvents["RowAdded"], evtArgs);
					}
				}
				if (fireServerEvent)
					this._get_owner()._raiseClientEventEnd(eventArgs);
				this._addRowCellValues = null;
				return true;
			}
		}
		return false;
	},

	get_editedRows: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.EditingCore.updatedRows">
		/// Returns an array of rows that have been edited and not yet commited to the server.
		/// </summary>
		/// <value type="Array" arrayType="Infragistics.Web.UI.GridRow"></value>
		var rows = [];
		if (this._batchUpdating)
		{
			for (var updateKey in this._actions)
			{
				if (this._actions.hasOwnProperty(updateKey))
				{
					var editAction = this._actions[updateKey];
					var row = this._get_rowFromActionKey(updateKey);
					if (row)
						rows[rows.length] = row;
				}
			}
		}
		return rows;
	},
	get_deletedRows: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.EditingCore.deletedRows">
		/// Returns an array of rows that have been deleted and not yet commited to the server.
		/// </summary>
		/// <value type="Array" arrayType="Infragistics.Web.UI.GridRow"></value>
		var rows = [];
		if (this._batchUpdating)
		{
			for (var deleteKey in this._deletingActions)
			{
				if (this._deletingActions.hasOwnProperty(deleteKey))
				{
					var deleteAction = this._deletingActions[deleteKey];
					var row = this._get_rowFromActionKey(deleteKey);
					if (row)
						rows[rows.length] = row;
				}
			}
		}
		return rows;
	},
	get_addedRows: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.EditingCore.addedRows">
		/// Returns an array of rows that have been added and not yet commited to the server.
		/// </summary>
		/// <value type="Array" arrayType="Infragistics.Web.UI.GridRow"></value>
		var rows = [];
		if (this._batchUpdating)
		{
			for (var addKey in this._addingActions)
			{
				if (this._addingActions.hasOwnProperty(addKey))
				{
					var addAction = this._addingActions[addKey];
					var row = this._get_rowFromActionKey(addKey);
					if (row)
						rows[rows.length] = row;
				}
			}
		}
		return rows;
	},

	_sortRowIdPairs: function (a, b)
	{
		return (b.index - a.index)
	},

	_cellValueChanging: function (args)
	{
		if (args.cell.get_row()._updated == $IG.RowUpdateStatus.AddedButDeleted || args.cell.get_row()._updated == $IG.RowUpdateStatus.Deleted)
		{
			args.cancel = true;
			return;
		}
		var eventArgs = this.__raiseClientEvent("CellValueChanging", $IG.CancelCellValueChangingEventArgs, [this, args.cell, args.oldValue, args.newValue]);
		if (eventArgs != null)
		{
			args.cancel = eventArgs.get_cancel();
			args.newValue = eventArgs.get_newValue();
		}
		
		this._oldCellText = args.cell.get_column()._isCheck ? args.cell._getCheckState() : args.cell.get_text();

	},
	_cellValueChanged: function (args)
	{
		var row = args.cell.get_row();
		var action = this._getUpdateAction(row);

		if (row._updated == $IG.RowUpdateStatus.Added)
		{
			action = this._getAddAction(row);
			action.set_cellValue(args.cell, args.cell.get_value());
		}
		else if (!action || !action._object)
		{
			
			if (this._activation && !this._batchUpdating && args.cell._clickedCheckbox && this._grid._enableAjax)
			{
				if (this.get_behaviors().get_cellEditing() && this.get_behaviors().get_cellEditing().get_cellInEditMode())
					this.get_behaviors().get_cellEditing().exitEditMode(true);
				this._activeCellChanged(args);
			}
			action = this._createUpdateAction(row);
			this._addUpdateAction(action, row);
			
			// do not create transaction for same row
			var list = this._batchUpdatingActionList.get_actionListForType("UpdateRow"), i = list ? list.length : 0;
			while (i-- > 0)
				if (list[i]._object == row)
					break;
			if (i < 0)
				this._batchUpdatingActionList.add_transaction(action, true);
			action.addUpdateCell(args.cell, args.oldValue);

			var cellColumn = args.cell.get_column();
			
			if (args.cell.get_element().getAttribute("tmpl") != "1" && !cellColumn.get_isCheckbox() && !cellColumn.get_isTemplated())
			{
				
				action.addUpdateCellText(args.cell, args.oldText);
			}

			if (this._batchUpdating)
			{
				row._updated = $IG.RowUpdateStatus.Edited;
				this._grid._gridUtil._addStyleToRow(row.get_element(), this._updatedRowCssClass);
				if (this._oldCellText)
					action.addUpdateCellText(args.cell, this._oldCellText);
			}
			
			else if (this._activation && args.cell._clickedCheckbox && !this._grid._enableAjax)
				this._activeCellChanged(args);
		}
		else
		{
			action.addUpdateCell(args.cell, args.oldValue);
			// if the cell is updated with the original value it will be removed from the action.
			var prevAction = action._object["_action" + action.type];
			if (!action.hasUpdatedCells() && !action._only_fromHeaderChecked() && prevAction && prevAction._transactionList == this._batchUpdatingActionList)
			{
				// if there are no updated cells in this action and there is a previous action associated with this object then remove it from the transaction list.
				this._batchUpdatingActionList.remove_transaction(action, true);
				this._removeUpdateAction(row);
				row._updated = null;
				this._grid._gridUtil._removeStyleFromRow(row.get_element(), this._updatedRowCssClass);
			}
		}
		if (this._hierarchical && this._batchUpdating)
		{
			var groupedCols = this._grid._get_band().get_groupingSettings().get_groupedColumns();
			var cell = args.cell, colKey = cell.get_column().get_key();
			for (var c = 0; c < groupedCols.get_length(); ++c)
			{
				var groupedColkey = groupedCols.getItem(c).get_columnKey();
				if (groupedColkey == colKey && cell.get_element().className.indexOf(this._grid._mergeClassBase) > -1)
					this._grid._gridUtil._adjustMergingCellValueChanged(cell, this._grid._mergeClassBase);
			}
		}
		if (this._grid.get_enableClientRendering())
			this._modifyClientDataSourceRow(row, args.cell);

		this._hasCellValueChanged = true;
		delete this._oldCellText;
		this.__raiseClientEvent("CellValueChanged", $IG.CellValueChangedEventArgs, [this, args.cell, args.oldValue]);
	},
	
	_forceUpdateCommit: function ()
	{
		if (this._hasCellValueChanged)
		{
			this._hasCellValueChanged = false;
			this._commitUpdates();
		}
	},
	
	_rowIsHidden: function (row)
	{
		if (row)
		{
			
			if ($util.IsIE)
			{
				var firstVisCol = this._grid._gridUtil._findFirstVisibleColumn();
				if (!firstVisCol)
					return true;
				var cellEl = row.get_cellByColumn(firstVisCol).get_element();
				if (cellEl.clientHeight == 0)
					return true;
			}
			else
			{
				var rowEl = row.get_element();
				if (rowEl.clientHeight == 0)
					return true;
			}
		}
		return false;
	},
	_preActiveCellChanging: function (args)
	{
		var cell = args.cell;
		if (cell != null)
		{
			var undoRow = cell.get_row();
			if (undoRow._updated == $IG.RowUpdateStatus.Deleted || undoRow._updated == $IG.RowUpdateStatus.AddedButDeleted)
			{
				if (this._rowIsHidden(undoRow))
				{
					var evnt = new Object();
					evnt.keyCode = args.keyCode;
					evnt.target = cell.get_element();
					evnt.shiftKey = args.shiftKey;
					evnt.ctrlKey = args.ctrlKey || args.metaKey;
					this._activation._onKeydownHandler(evnt);
					args.cancel = true;
				}
				else
				{
					this._focusUndoRow = undoRow;
					args.cell = null;
				}
			}
		}
	},
	_activeCellChanging: function (args)
	{
		if (this._focusUndoRow)
		{
			this._showUndoBtn(this._focusUndoRow, true);
			delete this._focusUndoRow;
		}
	},
	_activeCellChanged: function (args)
	{
		


		

		if (args.cell)
		{
			var activeRow = args.cell.get_row();
			if (this._lastActiveRow && (activeRow != this._lastActiveRow && this._hasCellValueChanged == true))
			{
				this._hasCellValueChanged = false;
				this._commitUpdates();
			}
			if (this._batchUpdating)
			{
				if (activeRow._updated == $IG.RowUpdateStatus.Deleted || activeRow._updated == $IG.RowUpdateStatus.AddedButDeleted)
					this._showUndoBtn(activeRow, true);
				else
					this._hideUndoBtn();
			}
			this._lastActiveRow = activeRow;
		}
		else if (this._hierarchical && args.cell == null && this._hasCellValueChanged)
		{
			var mainGrid = this._grid._get_mainGrid();
			if (mainGrid && (mainGrid._lastActiveGridIdLock || this._activation.__inSetActiveElement) && mainGrid._get_lastActiveGridId() == this._grid._id)
			{
				this._hasCellValueChanged = false;
				this._lastActiveRow = null;
				this._commitUpdates();
			}
			if (this._batchUpdating)
				this._hideUndoBtn();
		}
		else
			this._lastActiveRow = null;
	},
	
	_onActiveGroupedRowChanged: function (args)
	{
		if (this._batchUpdating)
			this._hideUndoBtn();
	},

	_getRowActionKey: function (row)
	{
		
		var rowIdPair = row.get_idPair ? row.get_idPair() : row;
		var actionKey = rowIdPair.key;

		if (actionKey.length == 0)
			actionKey = rowIdPair.index;

		return Sys.Serialization.JavaScriptSerializer.serialize(actionKey);
	},

	_getUpdateAction: function (row)
	{
		return this._actions[this._getRowActionKey(row)];
	},

	_removeUpdateAction: function (row)
	{
		delete this._actions[this._getRowActionKey(row)];
	},

	_createUpdateAction: function (row)
	{
		return new $IG.UpdateRowAction("UpdateRow", this.get_name(), row, new $IG.GridAffectedItems());
	},

	_addUpdateAction: function (action, row)
	{
		if (action && row)
		{
			this._actions[this._getRowActionKey(row)] = action;
		}
	},

	_getAddAction: function (row)
	{
		return this._addingActions[this._getRowActionKey(row)];
	},

	_removeAddAction: function (row)
	{
		var key = this._getRowActionKey(row);
		var action = this._addingActions[key];
		this._batchUpdatingActionList.remove_transaction(action, true);
		this._addingActions[key] = null;
		delete this._addingActions[key];
		return action;
	},

	_addAddAction: function (action, row)
	{
		if (action && row)
		{
			this._addingActions[this._getRowActionKey(row)] = action;
		}
	},

	_getDeleteAction: function (row)
	{
		return this._deletingActions[this._getRowActionKey(row)];
	},

	_removeDeleteAction: function (row)
	{
		var key = this._getRowActionKey(row);
		var action = this._deletingActions[key];
		this._batchUpdatingActionList.remove_transaction(action, true);
		this._deletingActions[key] = null;
		delete this._deletingActions[key];
		if (this.get_deletedRows().length == 0 && this._containerMouseMoveHandler)
		{
			this._grid._removeElementEventHandler(this._grid._element, "mousemove", this._containerMouseMoveHandler);
			delete this._containerMouseMoveHandler;
		}
		return action;
	},

	_addDeleteAction: function (action, row)
	{
		if (action && row)
		{
			this._deletingActions[this._getRowActionKey(row)] = action;
			if (!this._containerMouseMoveHandler)
			{
				this._containerMouseMoveHandler = Function.createDelegate(this, this._containerMouseMove);
				this._grid._addElementEventHandler(this._grid._element, "mousemove", this._containerMouseMoveHandler);
			}
		}
	},

	_onRowsDeleting: function (args)
	{
		var row = args.row;
		
		if (row && row._updated != $IG.RowUpdateStatus.AddedButDeleted && row._updated != $IG.RowUpdateStatus.Deleted && this._rowsToDelete.indexOf(row) == -1)
			this._rowsToDelete.add(row);
		if (args.commit)
		{
			if (this._batchUpdating)
				this._commitDeletes(false);
			else
				this.commit();
		}
	},

	_onRowAdding: function (args)
	{
		this._addRowCellValues = args.cellValues;
		if (this._batchUpdating)
			this._commitAdds(false);
		else
			this.commit();
	},
	_activateCell: function (cellElement)
	{
		if (cellElement && cellElement.parentNode && cellElement.offsetWidth) try
		{
			cellElement.focus();
		} catch (ex) { }
	},

	
	_onMoreRowsReceived: function ()
	{		
		for (var actionKey in this._actions)
		{
			var action = this._actions[actionKey];
			this._owner._actionList.remove_transaction(action);
			delete action;
		}
		
		this._actions = {};
	},

	_containerMouseMove: function (evnt)
	{
		var target = evnt.target;
		var rowIndex = this._undoSpan.getAttribute('rowIdx');
		var row = rowIndex ? this._grid.get_rows().get_row(rowIndex) : null;
		var rowHovered = this._grid._gridUtil.getRowFromCellElem(target);
		if (row === rowHovered)
			return;
		if (!rowHovered || (rowHovered._updated != $IG.RowUpdateStatus.Deleted && rowHovered._updated != $IG.RowUpdateStatus.AddedButDeleted))
		{
			this._hideUndoBtn();
			return;
		}
		this._showUndoBtn(rowHovered, false);
	},
	_onScrollTopChange: function (args)
	{
		if (!this._scrolling)
			this._hideUndoBtn();
	},

	_showUndoBtn: function (row, shouldFocus)
	{
		if (row)
		{
			var firstVisCol = this._grid._gridUtil._findFirstVisibleColumn();
			if (shouldFocus && firstVisCol)
			{
				this._scrolling = true;
				var editing = this;
				this._grid._gridUtil.scrollCellIntoViewIE(row.get_cell(firstVisCol.get_index()));
				setTimeout(function () { delete editing._scrolling; }, 101);
			}
			var undoBtn = this._undoSpan;
			if (this._hierarchical && this._grid._get_mainGrid()._get_lastEditingGridBehavior())
			{
				this._grid._get_mainGrid()._get_lastEditingGridBehavior()._hideUndoBtn();
				this._grid._get_mainGrid()._set_lastEditingGridBehavior(null);
			}
			undoBtn.setAttribute('rowIdx', row.get_index());
			var rowElem = row.get_element();
			var childNodes = rowElem.childNodes;
			var i = 0;
			for (i = 0; i < childNodes.length; ++i)
			{
				if (childNodes[i].offsetWidth > 0)
					break;
			}
			if (i >= childNodes.length)
				return;
			var cellElem = childNodes[i];
			cellElem.appendChild(this._undoSpan);
			undoBtn.style.marginLeft = '0px';
			undoBtn.style.marginTop = '0px';
			undoBtn.style.display = "";
			undoBtn.style.visibility = "visible";
			undoBtn.style.zIndex = '10000';

			var container = this._grid._container;
			var xyTD = $util.getLocation(cellElem);
			var xyBut = $util.getLocation(undoBtn);
			var cellHeight = cellElem.offsetHeight;
			var buttonHeight = undoBtn.offsetHeight;
			var shift = xyTD.y - xyBut.y + (cellHeight - buttonHeight) / 2;
			var top = shift - 1;
			undoBtn.style.marginTop = top + 'px';

			var containerWidth = container.clientWidth;
			var scrollLeft = container.scrollLeft;
			var buttonWidth = undoBtn.offsetWidth;
			var style = $util.getRuntimeStyle(cellElem);
			var paddingLeft = parseInt($util.getStyleValue(style, "paddingLeft", cellElem));
			if (isNaN(paddingLeft))
				paddingLeft = 0;
			var borderLeftWidth = parseInt($util.getStyleValue(style, "borderLeftWidth", cellElem));
			if (isNaN(borderLeftWidth))
				borderLeftWidth = 0;
			var left = containerWidth + scrollLeft - buttonWidth - borderLeftWidth - paddingLeft - container.offsetWidth / 2;

			undoBtn.style.marginLeft = left + 'px';
			if ((shift = buttonWidth + $util.getLocation(undoBtn).x - xyTD.x - scrollLeft - containerWidth + container.offsetWidth / 2) > 0)
				undoBtn.style.marginLeft = (left - shift) + 'px';

			if (shouldFocus)
				this._undoBtn.focus();
			if (this._hierarchical)
				this._grid._get_mainGrid()._set_lastEditingGridBehavior(this);
		}
	},

	_hideUndoBtn: function ()
	{
		if (this._hierarchical && this._grid._get_mainGrid()._get_lastEditingGridBehavior())
		{
			var beh = this._grid._get_mainGrid()._get_lastEditingGridBehavior();
			this._grid._get_mainGrid()._set_lastEditingGridBehavior(null);
			beh._hideUndoBtn();
		}
		if (this._undoSpan.getAttribute('rowIdx'))
			this._undoSpan.removeAttribute('rowIdx');
		$util.removeCompoundClass(this._undoBtn, this._undoBtnHoverClass);
		$util.removeCompoundClass(this._undoBtn, this._undoBtnPressedClass);
		if (this._undoSpan.parentNode.tagName == "TD" || this._undoSpan.parentNode.tagName == "TH")
		{
			if (this._hierarchical)
			{
				this._undoSpan.parentNode.removeChild(this._undoSpan);
				this._grid._get_mainGrid()._element.appendChild(this._undoSpan);
			}
			else
			{
				this._undoSpan.parentNode.removeChild(this._undoSpan);
				this._grid._element.appendChild(this._undoSpan);
			}
		}
		this._undoSpan.style.display = "none";
		this._undoSpan.style.visibility = "hidden";
	},

	_onMouseDownUndoBtn: function (evnt)
	{
		$util.addCompoundClass(this._undoBtn, this._undoBtnPressedClass);
	},

	_onMouseClickUndoBtn: function (evnt)
	{
		if (evnt.button != 0 && evnt.keyCode != Sys.UI.Key.enter && evnt.keyCode != Sys.UI.Key.space)
			return;
		$util.cancelEvent(evnt);
		var rowIndex = this._undoSpan.getAttribute('rowIdx');
		if (rowIndex != null && rowIndex > -1)
		{
			var row = this._owner.get_rows().get_row(rowIndex);
			if (row)
				this._undoUpdate(row, true);
		}
	},

	_onMouseOverUndoBtn: function (evnt)
	{
		$util.addCompoundClass(this._undoBtn, this._undoBtnHoverClass);
	},
	_onMouseOutUndoBtn: function (evnt)
	{
		$util.removeCompoundClass(this._undoBtn, this._undoBtnHoverClass);
		$util.removeCompoundClass(this._undoBtn, this._undoBtnPressedClass);
	},

	_onKeyDownUndoBtn: function (evnt)
	{
		if (this._activation)
		{
			var key = evnt.keyCode;
			var rowIndex = this._undoSpan.getAttribute('rowIdx');
			var grid = this._grid;
			var rows = grid.get_rows();
			var row = rows.get_row(rowIndex);
			var util = grid._gridUtil;
			var lastCol = util._findLastVisibleColumn();
			var firstCol = util._findFirstVisibleColumn();
			var lastCell = lastCol ? row.get_cell(lastCol.get_index()) : null;
			var firstCell = firstCol ? row.get_cell(firstCol.get_index()) : null;
			var nextGrpCell = null;
			var nextCell = null;
			if (key == Sys.UI.Key.enter || key == Sys.UI.Key.space)
				this._onMouseClickUndoBtn(evnt);
			else if ((key == Sys.UI.Key.tab && evnt.shiftKey) || key == Sys.UI.Key.left)
			{
				if (this._hierarchical)
				{
					var prevGroupedRow = util._getGroupRowIfPrev(row);
					if (prevGroupedRow)
						nextGrpCell = prevGroupedRow._get_valueCell();
					else
					{
						var prevGridInfo = util._getPrevRowForPrevGrid(row);
						if (prevGridInfo != null && prevGridInfo.prevRow != null)
						{
							if (this.__processPrevGridInfo(prevGridInfo, evnt, null))
								return;
						}
					}
				}

				if (!nextGrpCell)
				{
					if (row._updated == $IG.RowUpdateStatus.Deleted || row._updated == $IG.RowUpdateStatus.AddedButDeleted)
					{
						nextCell = util.getPrevCell(firstCell);
						nextRow = nextCell.get_row();
						if (nextRow && (nextRow._updated == $IG.RowUpdateStatus.Deleted || nextRow._updated == $IG.RowUpdateStatus.AddedButDeleted))
						{
							this._showUndoBtn(nextRow, true);
							nextCell = null;
							$util.cancelEvent(evnt);
						}
					}
					else
						nextCell = lastCell;
				}
			}
			else if ((key == Sys.UI.Key.tab && !evnt.shiftKey) || key == Sys.UI.Key.right)
			{
				if (this._hierarchical)
				{
					var nextGroupedRow = util._getGroupRowIfNext(row);
					if (nextGroupedRow)
						nextGrpCell = nextGroupedRow._get_valueCell();
					else
					{
						var nextGridInfo = util._getNextRowForNextGrid(row);
						if (this.__processNextGridInfo(nextGridInfo, evnt))
							return;
					}

				}
				if (!nextGrpCell)
				{
					nextCell = util.getNextCell(lastCell);
					nextRow = nextCell.get_row();
					if (nextRow && (nextRow._updated == $IG.RowUpdateStatus.Deleted || nextRow._updated == $IG.RowUpdateStatus.AddedButDeleted))
					{
						this._showUndoBtn(nextRow, true);
						nextCell = null;
						$util.cancelEvent(evnt);
					}
				}
			}
			else if (key == Sys.UI.Key.down)
			{
				nextGrpCell = null;
				if (this._hierarchical)
				{
					var nextGroupedRow = util._getGroupRowIfNext(row);
					if (nextGroupedRow)
						nextGrpCell = nextGroupedRow._get_valueCell();
					else
					{
						var nextGridInfo = util._getNextRowForNextGrid(row);
						if (nextGridInfo != null)
						{
							var nextGrid = nextGridInfo.nextGrid;
							var nextRow = nextGridInfo.nextRow;
							if (nextRow != null)
							{
								var nextActivation = nextGrid.get_behaviors().get_activation();

								if (nextRow._get_rowType && nextRow._get_rowType() == "GroupedRow")
								{
									nextActivation._set_activeElement(nextRow._get_valueCell(), true, evnt.shiftKey, evnt.ctrlKey, evnt.keyCode, "keydown", null, evnt);
									$util.cancelEvent(evnt);
								}
								else
								{
									if (nextRow && (nextRow._updated == $IG.RowUpdateStatus.Deleted || nextRow._updated == $IG.RowUpdateStatus.AddedButDeleted))
									{
										var nextEditing = nextGrid.get_behaviors().get_editingCore();
										nextEditing._showUndoBtn(nextRow, true);
										$util.cancelEvent(evnt);
										return;
									}
									var cellCount = nextRow.get_cellCount() - 1;
									var lastCol = util._findLastVisibleColumn();
									var visibleIndex = lastCol ? lastCol.get_visibleIndex() : 0;
									visibleIndex = (visibleIndex > cellCount ? cellCount : visibleIndex);

									var nextGridCellIndex = nextActivation.__get_prevVisibleCellIndex(visibleIndex);
									if (nextGridCellIndex == -1)
										nextGridCellIndex = nextActivation.__get_nextVisibleCellIndex(visibleIndex);

									nextActivation._set_activeCell(nextRow.get_cell(nextGridCellIndex), true, evnt.shiftKey, evnt.ctrlKey, evnt.keyCode, "keydown", null, null, evnt);
									$util.cancelEvent(evnt);
								}
								return;
							}
						}

					}
				}
				if (!nextGrpCell)
				{
					nextCell = util.getNextCellVert(firstCell);
					nextRow = nextCell.get_row();
					if (nextRow && (nextRow._updated == $IG.RowUpdateStatus.Deleted || nextRow._updated == $IG.RowUpdateStatus.AddedButDeleted))
					{
						this._showUndoBtn(nextRow, true);
						nextCell = null;
						$util.cancelEvent(evnt);
					}
				}
			}
			else if (key == Sys.UI.Key.up)
			{
				if (this._hierarchical)
				{
					var prevGroupedRow = util._getGroupRowIfPrev(row);
					if (prevGroupedRow)
						nextGrpCell = prevGroupedRow._get_valueCell();
					else
					{
						var prevGridInfo = util._getPrevRowForPrevGrid(row);
						if (this.__processPrevGridInfo(prevGridInfo, evnt, lastCell.get_index()))
							return;
					}
				}
				if (!nextGrpCell)
				{
					nextCell = util.getPrevCellVert(firstCell);
					nextRow = nextCell.get_row();
					if (nextRow && (nextRow._updated == $IG.RowUpdateStatus.Deleted || nextRow._updated == $IG.RowUpdateStatus.AddedButDeleted))
					{
						this._showUndoBtn(nextRow, true);
						nextCell = null;
						$util.cancelEvent(evnt);
					}
				}
			}

			if (nextCell != null || nextGrpCell != null)
			{
				if (nextCell != null)
					this._activation._set_activeCell(nextCell, true, evnt.shiftKey, evnt.ctrlKey, evnt.keyCode, "keydown", null, null, evnt);
				else
					this._activation._set_activeElement(nextGrpCell, true, evnt.shiftKey, evnt.ctrlKey, evnt.keyCode, "keydown", null, evnt);
				$util.cancelEvent(evnt);
			}
		}
	},

	__processPrevGridInfo: function (prevGridInfo, evnt, neededIndex)
	{
		if (prevGridInfo != null)
		{
			var prevGrid = prevGridInfo.prevGrid;
			var prevRow = prevGridInfo.prevRow;
			if (prevRow != null)
			{
				var prevActivation = prevGrid.get_behaviors().get_activation();
				var prevRowElem = prevRow.get_element();
				if (prevRowElem.style.display == "") 
				{
					if (prevRow && (prevRow._updated == $IG.RowUpdateStatus.Deleted || prevRow._updated == $IG.RowUpdateStatus.AddedButDeleted))
					{
						var prevEditing = prevGrid.get_behaviors().get_editingCore();
						prevEditing._showUndoBtn(prevRow, true);
						$util.cancelEvent(evnt);
					}
					else
					{
						var cellCount = prevRow.get_cellCount() - 1;
						var visibleIndex = cellCount;
						if (neededIndex != null)
						{
							visibleIndex = this._grid.get_columns().get_column(neededIndex).get_visibleIndex();
							visibleIndex = (visibleIndex > cellCount ? cellCount : visibleIndex);
						}

						var previousGridCellIndex = prevActivation.__get_prevVisibleCellIndex(visibleIndex);
						if (previousGridCellIndex == -1)
							previousGridCellIndex = prevActivation.__get_nextVisibleCellIndex(visibleIndex);
						prevActivation._set_activeCell(prevRow.get_cell(previousGridCellIndex), true, evnt.shiftKey, evnt.ctrlKey, evnt.keyCode, "keydown", null, null, evnt);
					}
				}
				else 
				{
					var rows = $util.getRows(prevGrid._elements["rows"]);
					var index = prevRowElem.rowIndex;
					var grpRow = null;
					while (!grpRow && index > -1)
					{
						grpRow = prevGrid._gridUtil._getGroupRowIfPrevFromElem(rows[index]);
						index--;
					}
					if (grpRow)
					{
						var grpRowElem = grpRow.get_element();
						while (grpRowElem && grpRowElem.style.display == "none")
						{
							grpRow = grpRow._get_collectionOwner()._get_owner();
							grpRowElem = grpRow.get_element();
						}
						prevActivation._set_activeElement(grpRow._get_valueCell(), true, evnt.shiftKey, evnt.ctrlKey, evnt.keyCode, "keydown", null, evnt);
					}
				}
				$util.cancelEvent(evnt);
				return true;
			}
		}
		return false;
	},

	__processNextGridInfo: function (nextGridInfo, evnt)
	{
		if (nextGridInfo != null)
		{
			var nextGrid = nextGridInfo.nextGrid;
			var nextRow = nextGridInfo.nextRow;
			if (nextRow != null)
			{
				var nextActivation = nextGrid.get_behaviors().get_activation();

				if (nextRow._get_rowType && nextRow._get_rowType() == "GroupedRow")
				{
					nextActivation._set_activeElement(nextRow._get_valueCell(), true, evnt.shiftKey, evnt.ctrlKey, evnt.keyCode, "keydown", null, evnt);
					$util.cancelEvent(evnt);
				}
				else
				{
					var visCol = nextGrid._gridUtil._findFirstVisibleColumn();
					if (visCol)
					{
						if (nextRow && (nextRow._updated == $IG.RowUpdateStatus.Deleted || nextRow._updated == $IG.RowUpdateStatus.AddedButDeleted))
						{
							var nextEditing = nextGrid.get_behaviors().get_editingCore();
							nextEditing._showUndoBtn(nextRow, true);
							$util.cancelEvent(evnt);
						}
						else
						{
							var firstCellIndex = visCol.get_index();
							nextActivation._set_activeCell(nextRow.get_cell(firstCellIndex), true, evnt.shiftKey, evnt.ctrlKey, evnt.keyCode, "keydown", null, null, evnt);
							$util.cancelEvent(evnt);
						}
					}
				}
				return true;
			}
		}
		return false;
	},


	_onKeydownHandler: function (evnt)
	{
		if (this._activation != null)
		{
			var key = evnt.keyCode;
			if (evnt.ctrlKey && key == 90 && !evnt.shiftKey)
			{
				var cell = this._activation.get_activeCell();
				if (cell != null)
				{
					var row = cell.get_row();
					this._undoUpdate(row, true);
				}
			}
		}
	},

	clearBatchUpdates: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.EditingCore.clearBatchUpdates">
		/// Undoes the batch updates on all rows
		/// </summary>
		if (this._batchUpdating)
		{
			for (var editKey in this._actions)
			{
				if (this._actions.hasOwnProperty(editKey))
				{
					var row = this._get_rowFromActionKey(editKey);
					if (row)
						this._undoUpdate(row, false);
				}
			}
			for (var deleteKey in this._deletingActions)
			{
				if (this._deletingActions.hasOwnProperty(deleteKey))
				{
					var row = this._get_rowFromActionKey(deleteKey);
					if (row)
						this._undoUpdate(row, false);
				}
			}
			for (var addKey in this._addingActions)
			{
				if (this._addingActions.hasOwnProperty(addKey))
				{
					var row = this._get_rowFromActionKey(addKey);
					if (row)
						this._undoUpdate(row, false);
				}
			}
		}
	},

	undoBatchUpdate: function (row)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.EditingCore.undoBatchUpdateOnRow">
		/// Undoes the last batch update operation on a row.
		/// </summary>
		/// <param name="row" type="Infragistics.Web.UI.GridRow"></param>
		if (row)
			this._undoUpdate(row, false);
	},

	_undoUpdate: function (row, fireEvents)
	{
		var grid = this._owner;
		if (row._updated)
		{
			var eventArgs = fireEvents ? this.__raiseClientEvent("BatchUpdateUndoing", $IG.BatchUpdateUndoingEventArgs, [this, row, row._updated, true]) : null;
			if (eventArgs && eventArgs.get_cancel())
				return;
			var operation = row._updated - 1;
			var indeces = null;
			var rowID = row.get_idPair();
			grid._gridUtil._fireEvent(grid, "BatchUpdateUndoing", { "row": row, "type": operation });
			switch (row._updated)
			{
				case $IG.RowUpdateStatus.AddedButDeleted: // added, but deleted
					grid._gridUtil._removeStyleFromRow(row.get_element(), this._deletedRowCssClass);
					grid._gridUtil._addStyleToRow(row.get_element(), this._addingRowCssClass);
					grid._gridUtil._addStyleToRow(row.get_element(), this._addedRowCssClass);
					var action = this._getDeleteAction(row);
					delete this._deletingActions[this._getRowActionKey(row)];
					this._addAddAction(action, row);
					this._batchUpdatingActionList.add_transaction(action, true);
					row._updated = $IG.RowUpdateStatus.Added;
					operation = $IG.RowUpdateType.Delete;
					break;
				case $IG.RowUpdateStatus.Added: // added
					var rowCount = grid.get_rows().get_length();
					var index = row.get_index();
					this._removeAddAction(row);
					if (row.get_element().nextSibling.nodeName == "#comment")
						row.get_element().parentNode.removeChild(row.get_element().nextSibling);
					row.get_element().parentNode.removeChild(row.get_element());
					if (grid.get_enableClientRendering())
						this._removeRowFromClientDataSource(index);
					var rowCount = grid.get_rows().get_length();
					grid._set_value($IG.WebDataGridProps.RowCount, rowCount - 1);
					
					if (this._hierarchical)
						grid._rows = new $IG.ContainerGridRowCollection(grid._elements["rows"], [grid._get_value($IG.WebDataGridProps.RowCount)], grid);
					else
						grid._rows = new $IG.GridRowCollection(grid._elements["rows"], [grid._get_value($IG.WebDataGridProps.RowCount)], grid);
					if (index != rowCount - 1)
						this._reapplyRowStyling(index);
					this._reapplyUpdateStatus();
					if (rowCount - 1 == 0)
					{
						var tableRows = grid._elements.dataTbl;
						
						if (grid._elements["sizeRow"])
							grid._elements["sizeRow"] = null;
						for (var x = tableRows.childNodes.length - 1; x >= 0; --x)
							tableRows.removeChild(tableRows.childNodes[x]);
						var tbody = null;
						if (this._emptyTemplate)
						{
							var div = document.createElement('div');
							div.innerHTML = "<table><tbody>" + this._emptyTemplate + "</tbody></table>";
							tbody = div.firstChild.firstChild;
						}
						else
							tbody = document.createElement('tbody');
						tableRows.appendChild(tbody);
						grid._elements["rows"] = null;
						grid._rows = new $IG.GridRowCollection(grid._elements["rows"], [grid._get_value($IG.WebDataGridProps.RowCount)], grid);
					}
					row._updated = null;
					break;
				case $IG.RowUpdateStatus.Deleted: // deleted
					grid._gridUtil._removeStyleFromRow(row.get_element(), this._deletedRowCssClass);
					this._removeDeleteAction(row);
					row._updated = null;
					if (row._get_rowType && row._get_rowType() == "ContainerGridRow")
					{
						row._rowIslands = row._oldRowIslands;
						delete row._oldRowIslands;
						row.__expandingInProgress = false;
						var groupedCols = this._grid._get_band().get_groupingSettings().get_groupedColumns();
						var mergedSpot;
						for (var c = 0; c < groupedCols.get_length(); ++c)
						{
							var groupedColkey = groupedCols.getItem(c).get_columnKey();
							var cell = row.get_cellByColumnKey(groupedColkey);
							if (mergedSpot = cell._mergedSpot)
							{
								var index = row.get_index(), thisVal = cell.get_value(), nextRow, nextCell, nextVal, merge = -1;
								if (mergedSpot != "top")
								{
									nextRow = this._grid.get_rows().get_row(index - 1);
									nextCell = nextRow.get_cell(cell.get_index());
									nextVal = nextCell.get_value();
									if (this._grid._gridUtil._valuesAreEqual(thisVal, nextVal) && nextRow._updated != $IG.RowUpdateStatus.Deleted)
										merge++;
								}
								nextRow = this._grid.get_rows().get_row(index + 1);
								if (nextRow)
								{
									nextCell = nextRow.get_cell(cell.get_index());
									nextVal = nextCell.get_value();
									if (this._grid._gridUtil._valuesAreEqual(thisVal, nextVal) && nextRow._updated != $IG.RowUpdateStatus.Deleted)
										merge += 2;
								}

								if (merge > -1)
									this._grid._gridUtil._reMergeForCell(cell, this._grid._mergeClassBase, merge);
							}
						}
					}
					if (this._getUpdateAction(row))
					{
						grid._gridUtil._addStyleToRow(row.get_element(), this._updatedRowCssClass);
						row._updated = $IG.RowUpdateStatus.Edited;
					}
					break;
				case $IG.RowUpdateStatus.Edited: // edited
					var action = this._getUpdateAction(row);
					if (action)
					{
						indeces = action.revertRow(row);
						if (!action.hasUpdatedCells())
						{
							this._batchUpdatingActionList.remove_transaction(action);
						}
						else
						{
							this._batchUpdatingActionList.remove_transaction(action);
							this._batchUpdatingActionList.add_transaction(action, true);
						}
						if (this._hierarchical)
						{
							var groupedCols = this._grid._get_band().get_groupingSettings().get_groupedColumns();
							for (var c = 0; c < groupedCols.get_length(); ++c)
							{
								var groupedColkey = groupedCols.getItem(c).get_columnKey();
								var cell = row.get_cellByColumnKey(groupedColkey);
								if (cell._mergedSpot)
									this._grid._gridUtil._adjustMergingCellValueChanged(cell, this._grid._mergeClassBase);
							}
						}
						this._removeUpdateAction(row);
						grid._gridUtil._removeStyleFromRow(row.get_element(), this._updatedRowCssClass);
						if (grid.get_enableClientRendering())
							for (var x = 0; x < indeces.length; ++x)
								this._modifyClientDataSourceRow(row, row.get_cell(indeces[x]));
						row._updated = null;
					}
					break;
			}
			var cellToActivate = null;
			if (this._undoSpan.getAttribute('rowIdx') == row.get_index())
			{
				this._hideUndoBtn();
				if (this._activation)
				{
					var firstCol = grid._gridUtil._findFirstVisibleColumn();
					cellToActivate = firstCol && operation == $IG.RowUpdateType.Delete ? row.get_cell(firstCol.get_index()) : null;
				}
			}
			if (cellToActivate)
				this._activation.set_activeCell(cellToActivate, true);
			grid._gridUtil._fireEvent(grid, "BatchUpdateUndone", { "row": row, "type": operation, "cellIndeces": indeces });
			if (fireEvents)
				this.__raiseClientEvent("BatchUpdateUndone", $IG.BatchUpdateUndoneEventArgs, [this, row, operation]);
		}
	},

	_reapplyUpdateStatus: function (args)
	{
		var grid = this._grid;
		var rows = grid.get_rows();
		for (var updateKey in this._actions)
		{
			if (this._actions.hasOwnProperty(updateKey))
			{
				var editAction = this._actions[updateKey];
				var row = this._get_rowFromActionKey(updateKey);
				if (row)
				{
					row._updated = $IG.RowUpdateStatus.Edited;
					grid._gridUtil._addStyleToRow(row.get_element(), this._updatedRowCssClass);
				}
			}
		}
		for (var addKey in this._addingActions)
		{
			if (this._addingActions.hasOwnProperty(addKey))
			{
				var addAction = this._addingActions[addKey];
				var row = this._get_rowFromActionKey(addKey);
				if (row)
				{
					row._updated = $IG.RowUpdateStatus.Added;
					grid._gridUtil._addStyleToRow(row.get_element(), this._addingRowCssClass);
					grid._gridUtil._addStyleToRow(row.get_element(), this._addedRowCssClass);
				}
			}
		}
		for (var deleteKey in this._deletingActions)
		{
			if (this._deletingActions.hasOwnProperty(deleteKey))
			{
				var deleteAction = this._deletingActions[deleteKey];
				var row = this._get_rowFromActionKey(deleteKey);
				if (row)
				{
					row._updated = deleteAction.type == "DeleteRow" ? $IG.RowUpdateStatus.Deleted : $IG.RowUpdateStatus.AddedButDeleted;
					grid._gridUtil._addStyleToRow(row.get_element(), this._deletedRowCssClass);
				}
			}
		}
	},

	_get_rowFromActionKey: function (actionKey)
	{
		if (actionKey)
		{
			var dataKey = Sys.Serialization.JavaScriptSerializer.deserialize(actionKey);
			
			var dateIndeces = this._grid._get_dateDataKeyIndeces();
			if (dateIndeces && dataKey != null)
			{
				for (var x = 0; x < dataKey.length; ++x)
				{
					if (dateIndeces.indexOf(x + ',') > -1)
						dataKey[x] = this._grid._gridUtil._convertServerDateStringToClientObject(dataKey[x]);
				}
			}
			return this._grid.get_rows().get_rowFromKey(dataKey);
		}
		return null;
	},

	_addRowToClientDataSource: function (row)
	{
		if (row)
		{
			var newDataItem = new Object();
			var cellCount = row.get_cellCount();
			for (var x = 0; x < cellCount; ++x)
			{
				var cell = row.get_cell(x);
				var column = cell.get_column();
				if (!column.get_isTemplated())
				{
					newDataItem[column._dataFieldName ? column._dataFieldName : column._key] = cell.get_value();
				}
			}
			var ds = this._grid.get_dataSource();
			ds[ds.length] = newDataItem;
			return newDataItem;
		}
		return null;
	},
	_modifyClientDataSourceRow: function (row, cell)
	{
		if (row && cell)
		{
			var index = row.get_index();
			var dataItem = this._grid.get_dataSource()[index];
			dataItem[cell.get_column()._dataFieldName] = cell.get_value();
		}
	},
	_removeRowFromClientDataSource: function (index)
	{
		var ds = this._grid.get_dataSource();
		ds = ds.slice(0, index).concat(ds.slice(index + 1, ds.length));
	},

	
	_onHeaderCheckBoxClicked: function (args)
	{
		if (args.col)
		{
			this._headerCheckBoxClicked = true;
			var col = args.col;
			var index = col.get_index();
			var rows = this._grid.get_rows();
			var rowCount = rows.get_length();
			var checked = col.get_headerChecked();
			var action = null, row = null;
			for (var x = 0; x < rowCount; ++x)
			{
				row = rows.get_row(x);
				action = this._getUpdateAction(row);
				var cell = row.get_cell(index);
				if ((!action || !action._object) && checked !== cell.get_value())
				{
					action = this._createUpdateAction(row);
					this._addUpdateAction(action, row);
					action._notAdded = true;
					action.addUpdateCellFromHeaderCheckbox(cell, checked);
					if (this._batchUpdating)
					{
						row._updated = $IG.RowUpdateStatus.Edited;
						this._grid._gridUtil._addStyleToRow(row.get_element(), this._updatedRowCssClass);
					}
				}
				else if (action && action._object)
				{
					action.addUpdateCellFromHeaderCheckbox(cell, checked);
					// if the cell is updated with the original value it will be removed from the action.
					var prevAction = action._object["_action" + action.type];
					if (!action.hasUpdatedCells() || action._only_fromHeaderChecked())// && prevAction && prevAction._transactionList == this._owner._actionList)
					{
						// if there are no updated cells in this action and there is a previous action associated with this object then remove it from the transaction list.
						if (prevAction && prevAction._transactionList == this._owner._actionList)
							this._owner._actionList.remove_transaction(action);
						this._removeUpdateAction(row);
						row._updated = null;
						this._grid._gridUtil._removeStyleFromRow(row.get_element(), this._updatedRowCssClass);
					}
				}
			}
		}
	},

	_onSavingActions: function (args)
	{
		
		
		if ((!this._grid._get_mainGrid()._populatingRow && (!this._grid._get_mainGrid()._postingGrid || this._grid._get_mainGrid()._postingGrid == this._grid || this._grid._get_mainGrid()._postingGrid._get_level() < this._grid._get_level())) && this._grid._enableAjax && this._batchUpdatingActionList.get_list().length > 0)
		{
			var gridActions = this._grid._actionList;
			var batchActions = this._batchUpdatingActionList;
			var newGridActions = new $IG.GridActionTransactionList();
			
			for (var action in batchActions._orderedList)
			{
				if (!isNaN(parseInt(action)))
					newGridActions.add_transaction(batchActions._orderedList[action], true);
			}
			for (var action in gridActions._orderedList)
			{
				if (!isNaN(parseInt(action)))
					newGridActions.add_transaction(gridActions._orderedList[action], true);
			}
			this._batchUpdatingActionList = new $IG.GridActionTransactionList();
			this._grid._actionList = newGridActions;
		}
	},

	
	_initializeComplete: function ()
	{
		this._activation = this._owner.get_behaviors().getBehaviorFromInterface($IG.IActivationBehavior);
		if (this._activation)
		{
			this._activation._addActiveCellChangedEventHandler(Function.createDelegate(this, this._activeCellChanged));
			if (this._activation.get_activeCell() && this._get_clientOnlyValue("foc"))
			{
				window.setTimeout($util.createDelegate(this, this._activateCell, [this._activation.get_activeCell().get_element()]), 0);
				
				if (!this._lastActiveRow)
					this._lastActiveRow = this._activation.get_activeCell().get_row();
			}
			
			if (this._batchUpdating)
			{
				this._onActiveGroupedRowChangedHandler = Function.createDelegate(this, this._onActiveGroupedRowChanged);
				this._grid._gridUtil._registerEventListener(this._activation, "ActiveGroupedRowChanged", this._onActiveGroupedRowChangedHandler);
				this._preActiveCellChangingHandler = Function.createDelegate(this, this._preActiveCellChanging);
				this._grid._gridUtil._registerEventListener(this._activation, "PreActiveCellChanging", this._preActiveCellChangingHandler);
				this._activeCellChangingHandler = Function.createDelegate(this, this._activeCellChanging);
				this._grid._gridUtil._registerEventListener(this._activation, "ActiveCellChanging", this._activeCellChangingHandler);
			}
		}
		this._addNew = this._owner.get_behaviors().getBehaviorFromInterface($IG.IRowAddingBehavior);


		this._selection = this._owner.get_behaviors().getBehaviorFromInterface($IG.ISelectionBehavior);

		
		this._virtualScrolling = this._grid.get_behaviors().get_virtualScrolling();
		if (this._virtualScrolling)
		{
			this._onMoreRowsReceivedHandler = Function.createDelegate(this, this._onMoreRowsReceived);
			this._virtualScrolling._addReceivedMoreRowsEventHandler(this._onMoreRowsReceivedHandler);
		}

		var deletionExemptRowIDs = this._get_clientOnlyValue("der");
		var shouldFireClientDeletedEvent = this._get_clientOnlyValue("fcde");
		if (shouldFireClientDeletedEvent)
		{
			if (this._clientEvents["RowsDeleted"])
			{
				var deletionExemptRows;
				if (deletionExemptRowIDs)
					deletionExemptRows = Sys.Serialization.JavaScriptSerializer.deserialize(deletionExemptRowIDs);
				else
					deletionExemptRows = new Array();

				var RowsDeletedEventArgs = new $IG.RowsDeletedEventArgs(this, deletionExemptRows);
				this._owner._raiseSenderClientEventStart(this, this._clientEvents["RowsDeleted"], RowsDeletedEventArgs);
			}
		}
		
		
		if (this._hierarchical && !this._addNew && this._grid.get_rows().get_length() == 0)
		{
			var filtering = this._owner.get_behaviors().get_filtering();
			if (!filtering || (filtering && filtering._get_totalRowCount() == 0))
				this._grid.__deleteGrid = true;
		}

		var updatedRowIDs = this._get_clientOnlyValue("urp");
		if (updatedRowIDs && this._clientEvents["RowUpdated"])
		{
			var updRows = Sys.Serialization.JavaScriptSerializer.deserialize(updatedRowIDs);
			for (var i = 0; i < updRows.length; i++)
			{
				var row = this._grid.get_rows().get_rowFromIDPair(updRows[i]);
				var rowUpdatedEventArgs = new $IG.RowUpdatedEventArgs(this, row);
				this._owner._raiseSenderClientEvent(this, this._clientEvents["RowUpdated"], rowUpdatedEventArgs);
			}
		}

		var shouldFireClientAddedEvent = this._get_clientOnlyValue("wri");
		if (shouldFireClientAddedEvent)
		{
			
			if (this._hierarchical && !this._batchUpdating)
				this._grid._gridUtil._fireEvent(this._grid, "NonBatchRowAdded", null);

			
			if (this._clientEvents["RowAdded"])
			{
				var rowAddedIdString = this._get_clientOnlyValue("rai");
				var rowAddedId = (rowAddedIdString != null && rowAddedIdString.length > 0) ? Sys.Serialization.JavaScriptSerializer.deserialize(rowAddedIdString) : null;
				var row = (rowAddedId != null) ? this._grid.get_rows().get_rowFromIDPair(rowAddedId) : null;
				var evtArgs = new $IG.RowAddedEventArgs(row, rowAddedId);
				this._owner._raiseSenderClientEvent(this, this._clientEvents["RowAdded"], evtArgs);
			}
		}
		
		if (this._batchUpdating && this._grid.get_enableClientRendering() && this._owner.get_behaviors().getBehaviorFromInterface($IG.IColumnMovingBehavior))
		{
			this._columnMoving = this._owner.get_behaviors().getBehaviorFromInterface($IG.IColumnMovingBehavior);
			this._onDataBoundHandler = Function.createDelegate(this, this._reapplyUpdateStatus);
			this._grid._gridUtil._registerEventListener(this._grid, "DataBound", this._onDataBoundHandler);
		}
	},

	_responseComplete: function (callbackObject, responseOptions)
	{
		if (responseOptions.updatedRowIdPair && responseOptions.updatedRowValues)
		{
			var row = this._grid.get_rows().get_rowFromIDPair(responseOptions.updatedRowIdPair);
			for (var key in responseOptions.updatedRowValues)
			{
				var column = this._grid.get_columns().get_columnFromKey(key);
				if (!column.get_isTemplated())
				{
					var cell = row.get_cellByColumn(column);
					//cell._set_value_internal(responseOptions.updatedRowValues[key]);
					var updatePair = responseOptions.updatedRowValues[key];

					


					var cellValue = updatePair[0];
					
					var textOrCheck = updatePair[1];
					if (!column.get_isCheckbox() && column._htmlEncode)
						cell._skipEncoding = true;
					if (column.get_type() == "date")
						cellValue = cell.get_grid()._gridUtil._convertServerDateStringToClientObject(cellValue);

					cell._set_value_internal(cellValue, textOrCheck);
					delete cell._skipEncoding;
				}
			}
			this._owner._actionList.remove_transaction(row._actionUpdateRow);
			if (this._clientEvents["RowUpdated"])
			{
				var rowUpdatedEventArgs = new $IG.RowUpdatedEventArgs(this, row);
				this._owner._raiseSenderClientEvent(this, this._clientEvents["RowUpdated"], rowUpdatedEventArgs);
			}
		}
		
		if (this._headerCheckBoxClicked)
		{
			var acts = this._grid._actionList;
			if (this._hierarchical && this._owner._enableAjax)
				acts = this._batchUpdatingActionList;
			var transList = acts.get_actionListForType("Check");
			for (var i = transList.length - 1; i >= 0; i--)
			{
				var checkTransaction = transList[i];
				acts.remove_transaction(checkTransaction);
			}
			delete this._headerCheckBoxClicked;
		}
	},

	_createBehaviorCollection: function ()
	{
		return new $IG.EditingCoreBehaviorCollection(this._owner);
	},
	

	dispose: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.EditingCore.dispose">
		/// For internal use.
		/// </summary>
		if (this._grid)
		{
			var util = this._grid._gridUtil;
			if (util)
			{
				util._unregisterEventListener(this._grid, "CellValueChanging", this._cellValueChangingListener);
				this._cellValueChangingListener = null;
				util._unregisterEventListener(this._grid, "TriggerCommit", this._onTriggerCommit);
				this._onTriggerCommit = null;
				util._unregisterEventListener(this._grid, "CellValueChanged", this._cellValueChangedListener);
				this._cellValueChangedListener = null;
				util._unregisterEventListener(this._grid, "RowsDeleted", this._onRowsDeletingListener);
				this._onRowsDeletingListener = null;
				util._unregisterEventListener(this._grid, "RowAdded", this._onRowAddingListener);
				this._onRowAddingListener = null;
				
				if (this._virtualScrolling)
				{
					this._grid._gridUtil._unregisterEventListener(this._virtualScrolling, "ReceivedMoreRows", this._onMoreRowsReceivedHandler);
					delete this._onMoreRowsReceivedHandler
					delete this._virtualScrolling;
				}
				util._unregisterEventListener(this._grid, "HeaderCheckBoxClicked", this._onHeaderCheckBoxClicked);
				this._onHeaderCheckBoxClicked = null;
			}
			if (this._batchUpdating)
			{
				delete this._itemCssClass;
				delete this._altItemCssClass;
				delete this._updatedRowCssClass;
				delete this._deletedRowCssClass;
				delete this._addedRowCssClass;
				delete this._expansionColClass;
				delete this._groupIndentCellClass;
				delete this._dataKeyFields;
				delete this._batchUpdating;
				delete this._addRowCounter;
				delete this._emptyDataKeyString;
				delete this._undoBtnHoverClass;
				delete this._undoBtnPressedClass;
				if (this._undoSpan)
				{
					if (this._hierarchical && this._grid._get_mainGrid() && this._grid._get_mainGrid()._get_lastEditingGridBehavior())
					{
						var beh = this._grid._get_mainGrid()._get_lastEditingGridBehavior();
						this._grid._get_mainGrid()._set_lastEditingGridBehavior(null);
						beh._hideUndoBtn();
					}
					if (this._grid._element && this._undoSpan.parentNode && (this._undoSpan.parentNode.tagName == "TD" || this._undoSpan.parentNode.tagName == "TH"))
					{
						if (this._hierarchical && this._grid._get_mainGrid() && this._grid._get_mainGrid()._element)
						{

							this._undoSpan.parentNode.removeChild(this._undoSpan);
							this._grid._get_mainGrid()._element.appendChild(this._undoSpan);
						}
						else
						{
							this._undoSpan.parentNode.removeChild(this._undoSpan);
							this._grid._element.appendChild(this._undoSpan);
						}
					}
					$clearHandlers(this._undoBtn);
					delete this._onMouseDownUndoBtnHandler;
					delete this._onKeyDownUndoBtnHandler;
					delete this._undoBtn;
					delete this._undoSpan;
					if (this._onScrollTopChangeHandler)
					{
						this._grid._gridUtil._unregisterEventListener(this._grid, "ScrollTopChange", this._onScrollTopChangeHandler);
						delete this._onScrollTopChangeHandler;
					}
					if (this._containerMouseMoveHandler)
					{
						this._grid._removeElementEventHandler(this._grid._element, "mousemove", this._containerMouseMoveHandler);
						delete this._containerMouseMoveHandler;
					}
				}
				if (this._grid.get_enableClientRendering() && this._columnMoving)
				{
					this._grid._gridUtil._unregisterEventListener(this._grid, "DataBound", this._onDataBoundHandler);
					delete this._onDataBoundHandler;
				}
				
				if (this._activation)
				{
					this._grid._gridUtil._unregisterEventListener(this._activation, "ActvieGroupedRowChanged", this._onActiveGroupedRowChangedHandler);
					delete this._onActiveGroupedRowChangedHandler;
					this._grid._gridUtil._unregisterEventListener(this._activation, "PreActiveCellChanging", this._preActiveCellChangingHandler);
					delete this._preActiveCellChangingHandler;
					this._grid._gridUtil._unregisterEventListener(this._activation, "ActiveCellChanging", this._activeCellChangingHandler);
					delete this._activeCellChangingHandler;
				}
				if (this._batchUpdatingActionList)
					this._batchUpdatingActionList.dispose();
				if (this._onSavingActionsHandler)
				{
					this._grid._gridUtil._unregisterEventListener(this._grid, "SavingActions", this._onSavingActionsHandler);
					delete this._onSavingActionsHandler;
				}
			}
			delete this._activation;
			delete this._addNew;
			delete this._selection;
			delete this._columnMoving;
		}
		$IG.EditingCore.callBaseMethod(this, "dispose");
	}
}

$IG.EditingCore.registerClass('Infragistics.Web.UI.EditingCore', $IG.GridBehaviorContainer, $IG.IEditingBehavior);



$IG.EditingCoreBehaviorCollection = function(control)
{
	$IG.EditingCoreBehaviorCollection.initializeBase(this, [control]);
}

$IG.EditingCoreBehaviorCollection.prototype =
{
	_rowDeleting: null,
	get_rowDeleting: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.EditingCore.rowDeleting">
		/// Returns reference to the row deleting behavior if one exists in the collection. 
		/// Null if the behavior is not added or not enabled on the server.
		/// </summary>
		/// <value type="Infragistics.Web.UI.RowDeleting" mayBeNull="true"></value>
		return this._rowDeleting;
	},

	_rowAdding: null,
	get_rowAdding: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.EditingCore.rowAdding">
		/// Returns reference to the row adding behavior if one exists in the collection. 
		/// Null if the behavior is not added or not enabled on the server.
		/// </summary>
		/// <value type="Infragistics.Web.UI.RowAdding" mayBeNull="true"></value>
		return this._rowAdding;
	},

	_cellEditing: null,
	get_cellEditing: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.EditingCore.cellEditing">
		/// Returns reference to the cell editing behavior if one exists in the collection. 
		/// Null if the behavior is not added or not enabled on the server.
		/// </summary>
		/// <value type="Infragistics.Web.UI.CellEditing" mayBeNull="true"></value>
		return this._cellEditing;
	},

	_rowEditingTemplate: null,
	get_rowEditingTemplate: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.EditingCore.rowEditingTemplate">
		/// Returns reference to the row editing template behavior if one exists in the collection. 
		/// Null if the behavior is not added or not enabled on the server.
		/// </summary>
		/// <value type="Infragistics.Web.UI.RowEditingTemplate" mayBeNull="true"></value>
		return this._rowEditingTemplate;
	},

	dispose: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.EditingCore.dispose">
		/// For internal use.
		/// </summary>
		this._rowDeleting = null;
		this._rowAdding = null;
		this._cellEditing = null;
		this._rowEditingTemplate = null;
		$IG.EditingCoreBehaviorCollection.callBaseMethod(this, "dispose");
	}

}

$IG.EditingCoreBehaviorCollection.registerClass('Infragistics.Web.UI.EditingCoreBehaviorCollection', $IG.BehaviorCollectionBase);



$IG.UpdateRowAction = function(type, ownerName, object, value, tag)
{
	$IG.UpdateRowAction.initializeBase(this, [type, ownerName, object, value, tag]);
}

$IG.UpdateRowAction.prototype =
{
	get_value: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.EditingCore.value">
		/// Returns the value of the UpdateAction.
		/// </summary>
		/// <value type="String"></value>
		return this._value._items;
	},

	get_updatedCells: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.EditingCore.updatedCells">
		/// Returns an array of the updated cells.
		/// </summary>
		/// <value type="Array" elementType=""></value>
		return this._value;
	},

	hasUpdatedCells: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.EditingCore.hasUpdatedCells">
		/// Returns true if the row action has at least one updated cell.
		/// </summary>
		/// <value type="Boolean"></value>
		return this._value.get_length() > 0;
	},

	findUpdatedCellRowAction: function (cell)
	{
		var updatedCellAction = null;
		if (cell)
		{
			var colIdPair = cell.get_idPair().columnIDPair;
			var updatedCells = this.get_updatedCells();

			for (var i = 0, len = updatedCells.get_length(); i < len; i++)
			{
				var updCell = updatedCells.getItem(i);
				if (cell.get_grid()._gridUtil.areIdPairsEqual(colIdPair, updCell.colIdPair))
				{
					updatedCellAction = updCell;
					break;
				}
			}
		}
		return updatedCellAction;
	},

	addUpdateCell: function (cell, oldValue)
	{
		var isAdded = true;
		var updatedCellAction = this.findUpdatedCellRowAction(cell);

		if (!updatedCellAction)
		{
			updatedCellAction = { "colIdPair": cell.get_idPair().columnIDPair, "oldValue": oldValue };
			
			if (cell.get_column().get_type() == "number" && isNaN(oldValue))
				updatedCellAction.oldValue = "NaN";
			this.get_updatedCells().add(updatedCellAction);
			updatedCellAction.value = cell.get_value();
			
			if (cell.get_column().get_type() == "number" && isNaN(updatedCellAction.value))
				updatedCellAction.value = "NaN";
			else if (cell.get_column().get_type() == "date")
			{
				updatedCellAction.valueDateString = cell.get_grid()._gridUtil._convertClientDateToServerString(updatedCellAction.value);
				updatedCellAction.oldValueDateString = cell.get_grid()._gridUtil._convertClientDateToServerString(updatedCellAction.oldValue);
			}
			updatedCellAction._commited = false;
		}
		else
		{
			// this cell has beend updated before
			updatedCellAction.value = cell.get_value();
			
			if (cell.get_column().get_type() == "number" && isNaN(updatedCellAction.value))
				updatedCellAction.value = "NaN";
			else if (cell.get_column().get_type() == "date")
			{
				updatedCellAction.valueDateString = cell.get_grid()._gridUtil._convertClientDateToServerString(updatedCellAction.value);
				updatedCellAction.oldValueDateString = cell.get_grid()._gridUtil._convertClientDateToServerString(updatedCellAction.oldValue);
			}
			updatedCellAction._commited = false;

			
			if (updatedCellAction.oldValue == cell.get_value() && (!updatedCellAction.fromHeaderCheck || updatedCellAction.oldValue === updatedCellAction.headerCheckVal))
			{
				// we are trying to set a value that was the original value
				var updatedCellActionsList = this.get_updatedCells();
				updatedCellActionsList.remove(updatedCellActionsList.indexOf(updatedCellAction));
				isAdded = false;
			}
		}
		if (this._notAdded)
		{
			var grid = cell.get_grid();
			if (!grid._get_mainGrid || !grid._enableAjax)
				grid._actionList.add_transaction(this);
			else
				grid.get_behaviors().get_editingCore()._batchUpdatingActionList.add_transaction(this, true);
			delete this._notAdded;
		}
		
		




		return isAdded;
	},
	
	addUpdateCellText: function (cell, oldText)
	{
		var updatedCellAction = this.findUpdatedCellRowAction(cell);
		if (updatedCellAction)
			updatedCellAction.oldText = oldText;
	},

	
	
	addUpdateCellFromHeaderCheckbox: function (cell, newValue)
	{
		var isAdded = true;
		var updatedCellAction = this.findUpdatedCellRowAction(cell);

		if (!updatedCellAction)
		{
			updatedCellAction = { "colIdPair": cell.get_idPair().columnIDPair, "oldValue": cell.get_value(), "fromHeaderCheck": true };

			this.get_updatedCells().add(updatedCellAction);
			updatedCellAction.value = newValue;
			updatedCellAction._commited = false;
		}
		else
		{
			// this cell has been updated before
			updatedCellAction.value = newValue;
			updatedCellAction._commited = false;
			updatedCellAction.fromHeaderCheck = true;

			if (updatedCellAction.oldValue == newValue)
			{
				// we are trying to set a value that was the original value
				var updatedCellActionsList = this.get_updatedCells();
				updatedCellActionsList.remove(updatedCellActionsList.indexOf(updatedCellAction));
				isAdded = false;
			}
		}
		updatedCellAction.headerCheckVal = newValue;
		return isAdded;
	},

	_only_fromHeaderChecked: function ()
	{
		var cells = this.get_value();
		var returnVal = true;
        for (var x = 0; x < cells.length; ++x)
        {
            var cellVals = cells[x];
            returnVal = returnVal && cellVals && (cellVals.fromHeaderCheck == true && cellVals.value == cellVals.headerCheckVal);
        }
		return returnVal;
	},

	revertRow: function (row)
    {
        var cells = this.get_value();
        var indeces = [];
		var updatedCellActionsList = this.get_updatedCells();
		for (var x = cells.length - 1; x >= 0; --x)
        {
            var cellVals = cells[x];
			
			if (cellVals)
			{
				var colIdPair = cellVals.colIdPair;
				var cell = row.get_cellByColumnKey(colIdPair.key[0]);
				indeces[x] = cell.get_column().get_index();
				if (cell)
				{
					if (cellVals.useHeaderVal)
					{
						cell._set_value_internal(cellVals.headerCheckVal);
						updatedCellActionsList.remove(updatedCellActionsList.indexOf(cellVals));
					}
					else
					{
						if (cellVals.oldText)
							cell._set_value_internal(cellVals.oldValue, cellVals.oldText);
						else
							cell._set_value_internal(cellVals.oldValue);
						if (!cellVals.fromHeaderCheck)
							updatedCellActionsList.remove(updatedCellActionsList.indexOf(cellVals));
						else
							cellVals.value = cellVals.oldValue;
					}
				}
			}
        }
        return indeces;
    }
}

$IG.UpdateRowAction.registerClass('Infragistics.Web.UI.UpdateRowAction', $IG.GridAction);



$IG.GridAffectedItems = function()
{
	/// <summary locid="T:J#Infragistics.Web.UI.GridAffectedItems">
	/// Collection of row and row ID pairs to be deleted.
	/// </summary>
	$IG.GridAffectedItems.initializeBase(this);
	this._lsize = 0;
	this._items = new Array();
} 
 
$IG.GridAffectedItems.prototype=
{
	 add:function(itemID)
	 {
		/// <summary locid="M:J#Infragistics.Web.UI.GridAffectedItems.add">
		/// Adds an item to the collection.
		/// </summary>
	 	/// <param name="itemID">
		/// Reference to an item ID.
		///</param>
	 	if (itemID == null) return;

		this._lsize++;
		this._items[(this._lsize - 1)] = itemID;
	 },

	 remove:function (index)
	 {
		/// <summary locid="M:J#Infragistics.Web.UI.GridAffectedItems.remove">
		/// Removes an item from the collection by its index.
		/// </summary>
		/// <param name="index" type="Number" integer="true">
		/// Index of the item to be removed from the collection.
		///</param>
		if (index < 0 || index > this._items.length - 1) return;
		this._items[index] = null;


		for (var i = index; i <= this._lsize; i++)
			this._items[i] = this._items[i + 1];

		this._lsize--;
	 },
	 
	 indexOf:function (item)
	 {
		/// <summary locid="M:J#Infragistics.Web.UI.GridAffectedItems.indexOf">
		/// Returns the index of the provided item.
		/// </summary>
		/// <param name="item">
		/// Reference to the item to get the index in the collection.
		///</param>
		///<returns type="Number" integer="true"></returns>
		for (var i = 0; i<this._lsize; i++)
		{
			if(item == this._items[i])
				return i;
		}
		return -1;
	 },

	isEmpty:function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.GridAffectedItems.isEmpty">
		/// Indicates whether the collection is empty.
		/// </summary>
		/// <value type="Boolean"></value>
		return this._lsize == 0;
	},     

	get_length:function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.GridAffectedItems.length">
		/// Gets the length of the collection.
		/// </summary>
		/// <value type="Number" integer="true"></value>
		return this._lsize
	},     
			 
	 getItem:function(index)
	 {
		/// <summary locid="M:J#Infragistics.Web.UI.GridAffectedItems.getItem">
	 	/// Returns an item from the collection by its index.  Can be either a row object
		/// or just a row ID pair if the row is on another page.
		/// </summary>
		/// <param name="index" type="Number" integer="true">
		/// Index of the item in the collection.
		///</param>
		///<returns></returns>
		return this._items[index];
	 },     

	 clear:function ()
	 {
		/// <summary locid="M:J#Infragistics.Web.UI.GridAffectedItems.clear">
		/// Clears the collection.
		/// </summary>
		  for (var i = 0; i < this._lsize; i++)
			   this._items[i] = null;

		  this._lsize = 0;
	 },

	 clone:function ()
	 {
		/// <summary locid="M:J#Infragistics.Web.UI.GridAffectedItems.clone">
		/// Creates and returns a copy of the collection.
		/// </summary>
		  var c = new GridAffectedItems();

		  for (var i = 0; i < this._lsize; i++)
			   c.add(this._items[i]);

		  return c;
	 }
}
$IG.GridAffectedItems.registerClass('Infragistics.Web.UI.GridAffectedItems');




$IG.CancelRowsDeletingEventArgs = function(deleting, rows)
{
	/// <summary locid="T:J#Infragistics.Web.UI.CancelRowsDeletingEventArgs">
	/// Event arguments object that is passed into the RowsDeleting event handler. Provides an option to cancel the event.
	/// </summary>
	$IG.CancelRowsDeletingEventArgs.initializeBase(this, [deleting]);
	this._rows = rows;
}
$IG.CancelRowsDeletingEventArgs.prototype =
{
	get_rows: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.CancelRowsDeletingEventArgs.rows">
		/// Returns the collection of row ID pairs that are about to be deleted.
		/// </summary>
		/// <value type="Infragistics.Web.UI.GridAffectedItems"></value>
		return this._rows;
	}
	
}
$IG.CancelRowsDeletingEventArgs.registerClass('Infragistics.Web.UI.CancelRowsDeletingEventArgs', $IG.CancelBehaviorEventArgs);


$IG.RowsDeletedEventArgs = function(deleting, deletionExemptRowIDs)
{
	///<summary locid="T:J#Infragistics.Web.UI.RowsDeletedEventArgs">
	///Event arguments object that is passed into the RowsDeleted event handler.
	///</summary>
	$IG.RowsDeletedEventArgs.initializeBase(this, [deleting]);
	this._deletionExemptRowIDs = deletionExemptRowIDs;
}
$IG.RowsDeletedEventArgs.prototype =
{
	get_canceled_rowIDPairs: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.RowsDeletedEventArgs.canceled_rowIDPairs">
		///Returns the Id's of any row who's delete event was canceled on the server.
		/// </summary>
		/// <value type="Array" elementType="Infragistics.Web.UI.IDPair"></value>
		return this._deletionExemptRowIDs;
	}
}
$IG.RowsDeletedEventArgs.registerClass('Infragistics.Web.UI.RowsDeletedEventArgs', $IG.EventArgs);




$IG.CancelAddRowEventArgs = function(addNewRow, row, cellValues)
{
	///<summary locid="T:J#Infragistics.Web.UI.CancelAddRowEventArgs">
	///Event arguments object passed into the row adding event handler. Provides an option to cancel the event.
	///</summary>
	$IG.CancelAddRowEventArgs.initializeBase(this, [addNewRow]);
	this._row = row;
	this._cellValues = cellValues;
}
$IG.CancelAddRowEventArgs.prototype =
{
	get_row: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.CancelAddRowEventArgs.row">
		/// Returns reference to the add new row behavior's row. The property can be null if the behavior is not present.
		/// </summary>
		/// <value type="Infragistics.Web.UI.AddNewGridRow"></value>
		return this._row;
	},
	get_cellValues: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.CancelAddRowEventArgs.cellValues">
		/// Returns the new row's cell values.
		/// </summary>
		/// <value type="Array" elementType=""></value>
		return this._cellValues;
	}
}
$IG.CancelAddRowEventArgs.registerClass('Infragistics.Web.UI.CancelAddRowEventArgs', $IG.CancelBehaviorEventArgs);





















$IG.CancelUpdateRowEventArgs = function(updating, row, updatedCells)
{
	///<summary locid="T:J#Infragistics.Web.UI.CancelUpdateRowEventArgs">
	///Event arguments object passed into the row updating event handler. Provides an option to cancel the event.
	///</summary>
	$IG.CancelUpdateRowEventArgs.initializeBase(this, [updating]);
	this._row = row;
	this._updatedCells = updatedCells;
}
$IG.CancelUpdateRowEventArgs.prototype =
{
	get_row: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.CancelUpdateRowEventArgs.row">
		/// Returns reference to the row that is being updated.
		/// </summary>
		/// <value type="Infragistics.Web.UI.GridRow"></value>
		return this._row;
	},
	get_updatedCells: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.CancelUpdateRowEventArgs.updatedCells">
		/// Returns an array of updated cell helper objects that contain cell's new and old values.
		/// </summary>
		/// <value type="Infragistics.Web.UI.GridAffectedItems"></value>
		return this._updatedCells;
	}
}
$IG.CancelUpdateRowEventArgs.registerClass('Infragistics.Web.UI.CancelUpdateRowEventArgs', $IG.CancelBehaviorEventArgs);



$IG.ClientCancelUpdateRowEventArgs = function (updating, row, updatedCells)
{
	///<summary locid="T:J#Infragistics.Web.UI.ClientCancelUpdateRowEventArgs">
	///Event arguments object passed into the row updating event handler. Provides an option to cancel the event.
	///Has a default setting of 
	///</summary>
	$IG.ClientCancelUpdateRowEventArgs.initializeBase(this, [updating, row, updatedCells]);
	this._selfUpdate = true;
}
$IG.ClientCancelUpdateRowEventArgs.prototype =
{
	get_selfUpdate: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ClientCancelUpdateRowEventArgs.selfUpdate">
		/// Indicates if the datasource will process the cells update outside of the grid.
		/// The default value of this setting is true.
		/// </summary>		
		return this._selfUpdate;
	},
	set_selfUpdate: function (value)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ClientCancelUpdateRowEventArgs.selfUpdate">
		/// Sets the value of selfUpdate.
		/// </summary>
		/// <param name="value" type="Boolean">The new value that the selfUpdate property will change to</param>
		this._selfUpdate = value;
	}
}
$IG.ClientCancelUpdateRowEventArgs.registerClass('Infragistics.Web.UI.ClientCancelUpdateRowEventArgs', $IG.CancelUpdateRowEventArgs);




$IG.RowUpdatedEventArgs = function(editingCore, row)
{
	///<summary locid="T:J#Infragistics.Web.UI.RowUpdatedEventArgs">
	///Event arguments object that is passed into the RowUpdatedEventArgs event handler.
	///</summary>
	$IG.RowUpdatedEventArgs.initializeBase(this);
	this._editingCore = editingCore;
	this._row = row;
}
$IG.RowUpdatedEventArgs.prototype =
{
	get_row: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.RowUpdatedEventArgs.row">
		///Returns the row that has been updated.
		/// </summary>
		/// <value type="Infragistics.Web.UI.GridRow"></value>
		return this._row;
	}
}
$IG.RowUpdatedEventArgs.registerClass('Infragistics.Web.UI.RowUpdatedEventArgs', $IG.EventArgs);




$IG.RowAddedEventArgs = function(row, rowIDPair)
{
	///<summary locid="T:J#Infragistics.Web.UI.RowAddedEventArgs">
	///Event arguments object that is passed into the RowAdded event handler.
	///</summary>
	$IG.RowAddedEventArgs.initializeBase(this);
	this._row = row;
	this._rowIDPair = rowIDPair;
}
$IG.RowAddedEventArgs.prototype =
{
	get_row: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.RowAddedEventArgs.row">
		/// Returns the row that has been added, if the row is currently present on the client.
		/// Otherwise null is returned
		/// </summary>
		/// <value type="Infragistics.Web.UI.GridRow" mayBeNull="true"></value>
		return this._row;
	},
	get_rowIDPair: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.RowAddedEventArgs.rowIDPair">
		/// Returns the IdPair of the row that has been added.
		/// </summary>
		/// <value type="Infragistics.Web.UI.IDPair"></value>
		return this._rowIDPair;
	}
}
$IG.RowAddedEventArgs.registerClass('Infragistics.Web.UI.RowAddedEventArgs', $IG.EventArgs);



$IG.CancelCellValueChangingEventArgs = function(params)//updating, cell, currentValue, newValue)
{
	///<summary locid="T:J#Infragistics.Web.UI.CancelCellValueChangingEventArgs">
	///Event arguments object passed into the cell value changing event handler. Provides an option to cancel the event.
	///</summary>
	$IG.CancelCellValueChangingEventArgs.initializeBase(this, [params[0]]);
	this._cell = params[1];
	this._currentValue = params[2];
	this._newValue = params[3];
}
$IG.CancelCellValueChangingEventArgs.prototype =
{
	get_cell: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.CancelCellValueChangingEventArgs.cell">
		/// Returns reference to the cell that is being updated.
		/// </summary>
		/// <value type="Infragistics.Web.UI.GridRow"></value>
		return this._cell;
	},
	get_currentValue: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.CancelCellValueChangingEventArgs.oldValue">
		/// Returns the current value of the cell.
		/// </summary>
		/// <value type="String"></value>
		return this._currentValue;
	},
	get_newValue: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.CancelCellValueChangingEventArgs.newValue">
		/// Returns the value that the cell is changing to.
		/// </summary>
		/// <value type="String"></value>
		return this._newValue;
	},
	set_newValue: function(newValue)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.CancelCellValueChangingEventArgs.newValue">
		/// Sets the value that the cell is changing to.
		/// </summary>
		/// <param name="newValue" type="String">The new value that the cell will change to</param>
		this._newValue = newValue;
	}
}
$IG.CancelCellValueChangingEventArgs.registerClass('Infragistics.Web.UI.CancelCellValueChangingEventArgs', $IG.CancelBehaviorEventArgs);



$IG.CellValueChangedEventArgs = function(params)//editingCore, cell, oldValue)
{
	///<summary locid="T:J#Infragistics.Web.UI.CellValueChangedEventArgs">
	///Event arguments object that is passed into the CellValueChangedEventArgs event handler.
	///</summary>
	$IG.CellValueChangedEventArgs.initializeBase(this);
	this._editingCore = params[0];
	this._cell = params[1];
	this._oldValue = params[2];
}
$IG.CellValueChangedEventArgs.prototype =
{
	get_cell: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.CellValueChangedEventArgs.cell">
		///Returns the cell that has had its value changed.
		/// </summary>
		/// <value type="Infragistics.Web.UI.GridCell"></value>
		return this._cell;
	},
	get_oldValue: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.CellValueChangedEventArgs.oldValue">
		///Returns the cell's previous value.
		/// </summary>
		/// <value type="String"></value>
		return this._oldValue;
	}
}
$IG.CellValueChangedEventArgs.registerClass('Infragistics.Web.UI.CellValueChangedEventArgs', $IG.EventArgs);



$IG.AddedRowAction = function(type, ownerName, object, value, tag)
{
	$IG.AddedRowAction.initializeBase(this, [type, ownerName, object, value, tag]);
	
    this._isArray = value.length == 0 || !(value[0] != null && value[0].DataKeyField != null);
}

$IG.AddedRowAction.prototype =
{
	get_value: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.EditingCore.value">
		/// Returns the value of the AddedRowAction.
		/// </summary>
		/// <value type="String"></value>
		return this._value;
	},

	set_cellValue: function (cell, value)
	{
		if (cell)
		{
			var column = cell.get_column();
			if (column && column.get_type() == "date")
				value = cell.get_grid()._gridUtil._convertClientDateToServerString(value);

			var colIndex = cell.get_column().get_index();
			if (this._isArray)
				this._value[colIndex] = value;
			else
			{
				var colKey = cell.get_column().get_key();
				for (var x = 0; x < this._value.length; ++x)
				{
					if (this._value[x].DataKeyField == colKey)
					{												
						this._value[x].Value = value;
						break;
					}
				}
			}
		}
	}
}

$IG.AddedRowAction.registerClass('Infragistics.Web.UI.AddedRowAction', $IG.GridAction);



$IG.BatchUpdateUndoingEventArgs = function(params)//updating, row, type, wasKeyboard)
{
    ///<summary locid="T:J#Infragistics.Web.UI.BatchUpdateUndoingEventArgs">
	///Event arguments object passed into the batch undoing event handler. Provides an option to cancel the event.
	///</summary>
	$IG.BatchUpdateUndoingEventArgs.initializeBase(this, [params[0]]);
	this._row = params[1];
	this._type = params[2];
	this._wasKeyboard = params[3];
}
$IG.BatchUpdateUndoingEventArgs.prototype =
{
	get_row: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.BatchUpdateUndoingEventArgs.row">
		/// Returns reference to the row that will have its update action undone.
		/// </summary>
		/// <value type="Infragistics.Web.UI.GridRow"></value>
		return this._row;
	},
	get_editActionType: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.BatchUpdateUndoingEventArgs.editActionType">
		/// Returns the update action type (edit (0), delete (1), add (2)) that is being undone
		/// </summary>
		/// <value type="Infragistics.Web.UI.RowUpdateType"></value>
		return this._type;
	},
	get_wasKeyboard: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.BatchUpdateUndoingEventArgs.wasKeyboard">
		/// Returns whether the undo action was initiated by the keyboard
		/// </summary>
		/// <value type="Boolean"></value>
		return this._newValue;
	}
}
$IG.BatchUpdateUndoingEventArgs.registerClass('Infragistics.Web.UI.BatchUpdateUndoingEventArgs', $IG.CancelBehaviorEventArgs);



$IG.BatchUpdateUndoneEventArgs = function (params)//editingCore, row, type)
{
    ///<summary locid="T:J#Infragistics.Web.UI.BatchUpdateUndoneEventArgs">
    ///Event arguments object that is passed into the CellValueChangedEventArgs event handler.
    ///</summary>
    $IG.BatchUpdateUndoneEventArgs.initializeBase(this);
    this._editingCore = params[0];
    this._row = params[1]
    this.type = params[2];
}
$IG.BatchUpdateUndoneEventArgs.prototype =
{
    get_row: function ()
    {
        /// <summary locid="P:J#Infragistics.Web.UI.BatchUpdateUndoneEventArgs.cell">
        ///Returns the cell that has had its value changed.
        /// </summary>
        /// <value type="Infragistics.Web.UI.GridRow"></value>
        return this._row;
    },
	get_editActionType: function()
	{
	    /// <summary locid="P:J#Infragistics.Web.UI.BatchUpdateUndoneEventArgs.editActionType">
	    /// Returns the update action type (edit (0), delete (1), add (2)) that was undone
		/// </summary>
		/// <value type="Infragistics.Web.UI.RowUpdateType"></value>
		return this._type;
	}
}
$IG.BatchUpdateUndoneEventArgs.registerClass('Infragistics.Web.UI.BatchUpdateUndoneEventArgs', $IG.EventArgs);

