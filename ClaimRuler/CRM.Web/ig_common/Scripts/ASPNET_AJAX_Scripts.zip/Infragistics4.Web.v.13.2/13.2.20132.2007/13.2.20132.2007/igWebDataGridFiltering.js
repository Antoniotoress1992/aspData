/*
* igWebDataGridFiltering.js
* Version 13.2.20132.2007
* Copyright(c) 2001-2013 Infragistics, Inc. All Rights Reserved.
*/


$IG.Filtering = function (obj, objProps, control, parentCollection, hierarchical)
{
	/// <summary locid="T:J#Infragistics.Web.UI.Filtering">
	/// Filtering behavior object of the grid.
	/// </summary>
	/// <param name="obj" type="String">The name of the behavior.</param>
	/// <param name="objProps" type="Array">An array of objects which are the values for the internal members of the class.</param>
	/// <param name="control" type="Infragistics.Web.UI.WebDataGrid">The grid to which the behavior belongs to.</param>
	/// <param name="parentCollection" type="Infragistics.Web.UI.BehaviorCollectionBase">The collection to which the behavior belongs to.</param>

	$IG.Filtering.initializeBase(this, [obj, objProps, control, parentCollection]);

	this._grid = this._owner;
	this._gridElement = this._grid._element;
	this._gridContainer = control._elements["container"];
	this._clientColumnFilters = [];
	this.__tmpCheckBoxFilters = [];
	this.__tmpCheckBoxFiltersToRemove = [];
	this._hierarchical = hierarchical;

	this._ruleDDSelectedItemCss = this._get_clientOnlyValue("frddsic"); // selected rule item css class
	this._ruleDDHoverItemCss = this._get_clientOnlyValue("frddhic");    // rule item hover css class
	this._ruleDDItemCss = this._get_clientOnlyValue("frddic");          // rule item css class

	

	this.__defaultDate = this._grid._gridUtil._convertServerDateStringToClientObject(Sys.Serialization.JavaScriptSerializer.deserialize(this._get_clientOnlyValue("fdefdate")));

	

	this._onMouseDownHandler = Function.createDelegate(this, this._onMouseDown);
	$addHandler(($util.IsIE8 ? document.documentElement : document), 'mousedown', this._onMouseDownHandler);
    
	this._onMouseUpHandler = Function.createDelegate(this, this._onMouseUp);
	$addHandler(($util.IsIE8 ? document.documentElement : document), 'mouseup', this._onMouseUpHandler);

	this._onMousewheelHandler = Function.createDelegate(this, this._onMousewheel);
	$addHandler(($util.IsIE8 ? document.documentElement : document), 'mousewheel', this._onMousewheelHandler);
	// for FF
	if ($util.IsFireFox)
		$addHandler(window, "DOMMouseScroll", this._onMousewheelHandler);
	$addHandler(this._gridContainer, "scroll", this._onMousewheelHandler);

	this._onKeyDownHandler = Function.createDelegate(this, this._onKeyDown);
	$addHandler(($util.IsIE8 ? document.documentElement : document), 'keydown', this._onKeyDownHandler);

	this._filterType = this._get_clientOnlyValue("filType");

	if (this._filterType == $IG.FilteringType.RowFilter)
	{
		
		var gridId = this._grid._id;
		var numDropDownUL = $get(gridId + "_NumericRuleDropDown_UL");
		var textDropDownUL = $get(gridId + "_TextRuleDropDown_UL");
		var dateDropDownUL = $get(gridId + "_DateTimeRuleDropDown_UL");
		var boolDropDownUL = $get(gridId + "_BooleanRuleDropDown_UL");

		numDropDownUL.tabIndex = 0;
		textDropDownUL.tabIndex = 0;
		dateDropDownUL.tabIndex = 0;
		boolDropDownUL.tabIndex = 0;

		this._grid.__walkThrough(numDropDownUL, true);
		this._grid.__walkThrough(textDropDownUL, true);
		this._grid.__walkThrough(dateDropDownUL, true);
		this._grid.__walkThrough(boolDropDownUL, true);

		var childLi = numDropDownUL.childNodes;
		var childCount = childLi.length;
		for (var x = 0; x < childCount; ++x)
			childLi[x].tabIndex = 0;
		childLi = textDropDownUL.childNodes;
		childCount = childLi.length;
		for (var x = 0; x < childCount; ++x)
			childLi[x].tabIndex = 0;
		childLi = dateDropDownUL.childNodes;
		childCount = childLi.length;
		for (var x = 0; x < childCount; ++x)
			childLi[x].tabIndex = 0;
		childLi = boolDropDownUL.childNodes;
		childCount = childLi.length;
		for (var x = 0; x < childCount; ++x)
			childLi[x].tabIndex = 0;

		this._onSelectRuleHandler = Function.createDelegate(this, this._onSelectRule);
		$addHandler(numDropDownUL, 'mousedown', this._onSelectRuleHandler);
		$addHandler(textDropDownUL, 'mousedown', this._onSelectRuleHandler);
		$addHandler(dateDropDownUL, 'mousedown', this._onSelectRuleHandler);
		$addHandler(boolDropDownUL, 'mousedown', this._onSelectRuleHandler);


		
		this._onMouseOverRuleHandler = Function.createDelegate(this, this._onMouseOverRule);
		$addHandler(numDropDownUL, 'mouseover', this._onMouseOverRuleHandler);
		$addHandler(textDropDownUL, 'mouseover', this._onMouseOverRuleHandler);
		$addHandler(dateDropDownUL, 'mouseover', this._onMouseOverRuleHandler);
		$addHandler(boolDropDownUL, 'mouseover', this._onMouseOverRuleHandler);

		this._onMouseOutRuleHandler = Function.createDelegate(this, this._onMouseOutRule);
		$addHandler($get(this._grid._id + "_NumericRuleDropDown_UL"), 'mouseout', this._onMouseOutRuleHandler);
		$addHandler(textDropDownUL, 'mouseout', this._onMouseOutRuleHandler);
		$addHandler(dateDropDownUL, 'mouseout', this._onMouseOutRuleHandler);
		$addHandler(boolDropDownUL, 'mouseout', this._onMouseOutRuleHandler);

		this._onKeyDownRuleHandler = Function.createDelegate(this, this._onKeyDownRule);
		$addHandler($get(gridId + "_NumericRuleDropDown"), 'keydown', this._onKeyDownRuleHandler);
		$addHandler($get(gridId + "_TextRuleDropDown"), 'keydown', this._onKeyDownRuleHandler);
		$addHandler($get(gridId + "_DateTimeRuleDropDown"), 'keydown', this._onKeyDownRuleHandler);
		$addHandler($get(gridId + "_BooleanRuleDropDown"), 'keydown', this._onKeyDownRuleHandler);

		this._onTouchStartRuleHandler = Function.createDelegate(this, this._onTouchStartRule);
		this._onTouchMoveRuleHandler = Function.createDelegate(this, this._onTouchMoveRule);
		this._onTouchEndRuleHandler = Function.createDelegate(this, this._onTouchEndRule);
		if (window.navigator.msPointerEnabled)
		{
			$addHandler(dateDropDownUL, "MSPointerDown", this._onTouchStartRuleHandler);
			$addHandler(dateDropDownUL, "MSPointerMove", this._onTouchMoveRuleHandler);
			$addHandler(dateDropDownUL, "MSPointerUp", this._onTouchEndRuleHandler);
			dateDropDownUL.style.msTouchAction = "none";
		}
		else
		{
			$addHandler(dateDropDownUL, 'touchstart', this._onTouchStartRuleHandler);
			$addHandler(dateDropDownUL, 'touchmove', this._onTouchMoveRuleHandler);
			$addHandler(dateDropDownUL, 'touchend', this._onTouchEndRuleHandler);
		}


		this._row = new $IG.FilterRow(-1, control._elements["filterRow"], [], this._grid, null, this);
		this._row._element.setAttribute("adr", -1);
		this._row._container = this._row._element.parentNode.parentNode.parentNode;

		this._onFilterKeyDownHandler = Function.createDelegate(this, this._onFilterKeyDown);
		$addHandler(this._row._element, 'keydown', this._onFilterKeyDownHandler);
		if (control._elements["filterRowLeft"])
			$addHandler(control._elements["filterRowLeft"], 'keydown', this._onFilterKeyDownHandler);
		if (control._elements["filterRowRight"])
			$addHandler(control._elements["filterRowRight"], 'keydown', this._onFilterKeyDownHandler);
	}
	else
		this._initializeAdvanceFilterView();
	if ($util.IsOpera)
	{
		
		this._onKeyPressRuleHandler = Function.createDelegate(this, this._onKeyPressRule);
		$addHandler(document, 'keypress', this._onKeyPressRuleHandler);
	}
	if ($util.IsSafari || $util.IsChrome)
	{
		this._resolvingCellElemHandler = Function.createDelegate(this, this._resolvingCellElem);
		this._grid._gridUtil._registerEventListener(this._grid, "ResolvingCellElem", this._resolvingCellElemHandler);
	}
	this._onGridResizeHandler = Function.createDelegate(this, this._onGridResize);
	this._grid._gridUtil._registerEventListener(this._grid, "Resize", this._onGridResizeHandler);

	this._gridElementSelectStartHandler = Function.createDelegate(this, this._onSelectstartHandler);
	this._grid._gridUtil._registerEventListener(this._grid, "SelectStartContainer", this._gridElementSelectStartHandler);


	
	this._dropDownBehaviors = [];
	this._dropDownBehaviorsCount = 0;
}

$IG.Filtering.prototype =
{
	
	create_columnFilter: function (columnKey)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.Filtering.create_columnFilter">
		/// Creates a column filter object. Viewstate will not be preserved for this object
		/// until it is added to the column filters' collection
		/// </summary>
		/// <param name="columnKey" type="String"  optional="false" mayBeNull="false">
		/// The column key of the column that the column filter will be tied to.
		/// </param>
		/// <returns type="Infragistics.Web.UI.ClientColumnFilter">Newly created column filter </returns>

		var column = this._grid.get_columns().get_columnFromKey(columnKey);
		
		if (!column)
			return null;

		return new $IG.ClientColumnFilter(columnKey, column.get_type(), this._grid.get_id());
	},

	add_columnFilter: function (columnFilter)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.Filtering.add_columnFilter">
		/// Adds the column filter object to the column filters' collection
		/// </summary>
		///<param name="columnFilter" type="Infragistics.Web.UI.ClientColumnFilter"  optional="false" mayBeNull="false">
		/// The column filter which to add to the collection this should be created via create_columnFilter
		/// method.
		///</param>

		if (!this.get_columnFilterFromKey(columnFilter.get_columnKey()))
		{
			var eventArgs = new $IG.ColumnFilterAddingRemovingEventArgs(this);

			this._grid._actionList.add_transaction(new $IG.FilteringAction("AddColumnFilter", this.get_name(), this._grid, columnFilter, null));
			this._owner._raiseClientEventEnd(eventArgs);
		}

	},

	add_columnFilterRange: function (columnFilters)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.Filtering.add_columnFilterRange">
		/// Adds the column filter objects to the column filters' collection
		/// </summary>
		///<param name="columnFilters" type="Array" elementType="Infragistics.Web.UI.ClientColumnFilter"  optional="false" mayBeNull="false">
		/// The column filters which to add to the collection.
		///</param>
		if (columnFilters)
		{
			var eventArgs = new $IG.ColumnFilterAddingRemovingEventArgs(this);
			this._grid._actionList.add_transaction(new $IG.FilteringAction("AddColumnFilter", this.get_name(), this._grid, columnFilters, null));
			this._owner._raiseClientEventEnd(eventArgs);
		}
	},


	get_columnFilters: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.Filtering.columnFilters">
		/// Gets the column filters array
		/// </summary>
		/// <value type="Array" elementType="Infragistics.Web.UI.ColumnFilter">Column filters </value>
		return this._columnFilters;
	},

	get_columnFiltersCount: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.Filtering.columnFiltersCount">
		/// Gets the number of column filters that are currently in the
		/// column filters array.
		/// </summary>
		/// <value type="Number" integer="true">the number of column filters that are currently in the
		/// column filters array.</value>
		return this._columnFilters.length;
	},

	get_columnFilter: function (index)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.Filtering.columnFilter">
		/// Gets the column filter object at the specified index.
		/// </summary>
		///<param name="index" type="Number"  optional="false" mayBeNull="false">
		/// Zero based index
		///</param>
		/// <value type="Infragistics.Web.UI.ColumnFilter">The column filter at the specified index</value>
		if (index < 0 || index >= this._columnFilters.length)
			return null;
		else
			return this._columnFilters[index];
	},

	get_uniqueValuesColumnFiltersFromKey: function (columnKey)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.Filtering.columnFilterFromKey">
		/// Gets the column filter object that is tied to the column with the specified column key.
		/// </summary>
		///<param name="columnKey" type="String"  optional="false" mayBeNull="false">
		/// The column key of the column that the column filter is tied to.
		///</param>
		/// <value type="Infragistics.Web.UI.ColumnFilter">The column filter tied to the specified column key</value>
		var filters = [];
		for (var i = 0; i < this._uniqueValuesColumnFilters.length; i++)
		{
			if (this._uniqueValuesColumnFilters[i].get_columnKey() === columnKey)
			{
				filters[filters.length] = this._uniqueValuesColumnFilters[i];
			}
		}

		return filters;

	},
	get_columnFilterFromKey: function (columnKey)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.Filtering.columnFilterFromKey">
		/// Gets the column filter object that is tied to the column with the specified column key.
		/// </summary>
		///<param name="columnKey" type="String"  optional="false" mayBeNull="false">
		/// The column key of the column that the column filter is tied to.
		///</param>
		/// <value type="Infragistics.Web.UI.ColumnFilter">The column filter tied to the specified column key</value>
		for (var i = 0; i < this._columnFilters.length; i++)
		{
			if (this._columnFilters[i].get_columnKey() === columnKey)
				return this._columnFilters[i];
		}

		return null;

	},

	get_columnFilterIndexOf: function (columnFilter)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.Filtering.columnFilterIndexOf">
		/// Gets the index of the specified column filter in the column filters array
		/// </summary>
		///<param name="columnFilter" type="Infragistics.Web.UI.ColumnFilter"  optional="false" mayBeNull="false">
		/// The column filter whose index to look for.
		///</param>
		///<value type="Number" > Zero based index </value>

		for (var i = 0; i < this._columnFilters.length; i++)
		{
			if (this._columnFilters[i] === columnFilter)
				return i;
		}

		return -1;
	},

	containsColumnFilter: function (columnKey)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.Filtering.containsColumnFilter">
		/// Determines whether a column filter object that is tied to the column with the specified column key
		/// is in the column filters array.
		/// </summary>
		///<param name="columnKey" type="String"  optional="false" mayBeNull="false">
		/// The column key of the column that the column filter is tied to.
		///</param>
		/// <returns type="Boolean">Boolean value indicating whether the column filter currently 
		/// exists in the column filters array </returns>

		for (var i = 0; i < this._columnFilters.length; i++)
		{
			if (this._columnFilters[i].get_columnKey() === columnKey)
				return true;
		}
		return false;
	},

	removeColumnFilter: function (columnFilter)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.Filtering.removeColumnFilter">
		/// Deletes the column filter from the column filters array
		/// </summary>
		///<param name="columnFilter" type="Infragistics.Web.UI.ColumnFilter"  optional="false" mayBeNull="false">
		/// The column filter to delete
		///</param>
		this.removedColumnFilterByKey(columnFilter.get_columnKey());
	},

	removedColumnFilterByKey: function (columnKey)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.Filtering.removedColumnFilterByKey">
		/// Deletes the column filter that is tied to the specified column key
		/// from the column filters array
		/// </summary>
		///<param name="columnKey" type="String"  optional="false" mayBeNull="false">
		/// The column key of the column that the column filter is tied to.
		///</param>

		
		if (!this.containsColumnFilter(columnKey))
			return;

		var eventArgs = new $IG.ColumnFilterAddingRemovingEventArgs(this);

		this._grid._actionList.add_transaction(new $IG.FilteringAction("RemoveColumnFilter", this.get_name(), this._grid, columnKey, null));
		this._grid._raiseClientEventEnd(eventArgs);


	},

	clearColumnFilters: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.Filtering.clearColumnFilters">
		/// Deletes all column filter from the column filters array
		/// </summary>

		if (this._columnFilters.length > 0)
		{
			var eventArgs = new $IG.ColumnFilterAddingRemovingEventArgs(this);

			this._grid._actionList.add_transaction(new $IG.FilteringAction("ClearColumnFilters", this.get_name(), this._grid, null, null));
			this._grid._raiseClientEventEnd(eventArgs);
		}
	},


	get_columnFiltersInfo: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.Filtering.columnFiltersInfo">
		/// Returns a json array, with the column names, column types, filtering
		/// rules and the filtering values the WebDataGrid is being filtered by. 
		/// Could be used only for client-side filtering when 
		/// EnableClientRendering property is set to true.
		/// </summary>
		/// <value type="Array"></value>

		if (!this._grid.get_enableClientRendering())
			return;

		var filters = [];
		var filter;

		
		this._clientColumnFilters = $.grep(this._clientColumnFilters, function (item)
		{
			return (item.get_condition().get_rule() != 0);
		});

		filters = this._createFilterInfo(filters, this._clientColumnFilters);
		filters = this._createFilterInfo(filters, this._columnFilters);

		return filters;
	},


	addClientColumnFilter: function (columnFilter)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.Filtering.addClientColumnFilter">
		/// This method should only be used when EnableClientRendering is set to true.
		/// Adds the column filter object to the column filters' collection		
		/// </summary>
		///<param name="columnFilter" type="Infragistics.Web.UI.ClientColumnFilter"  optional="false" mayBeNull="false">
		/// The column filter which to add to the collection this should be created via create_columnFilter
		/// method.
		///</param>

		if (this._grid.get_enableClientRendering() && !this.get_columnFilterFromKey(columnFilter.get_columnKey()))
			this._clientColumnFilters[this._clientColumnFilters.length] = columnFilter;
	},

	removeClientColumnFilterByKey: function (columnKey)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.Filtering.removeClientColumnFilterByKey">
		/// This method should only be used when EnableClientRendering is set to true.
		/// Removes the column filter object from the column filters' collection, if it was created on the client,
		/// if the column filter came down from the server, its Rule just gets set to "Clear"  and its value to empty.
		/// </summary>
		///<param name="columnKey" type="String"  optional="false" mayBeNull="false">
		/// The column key of the column that the column filter is to be removed for.
		///</param>

		if (this._grid.get_enableClientRendering())
		{
			var columnFilter = this.get_columnFilterFromKey(columnKey);
			var deleteFilter = false;
			if (!columnFilter)
			{
				columnFilter = this._get_clientColumnFilterFromKey(columnKey);
				deleteFilter = true;
			}

			if (columnFilter)
			{
				this._clearClientColumnFilter(columnFilter);
				if (deleteFilter)
				{
					this._clientColumnFilters = $.grep(this._clientColumnFilters, function (colFilter, i)
					{
						return colFilter.get_columnKey() != columnKey;
					});
				}

			}

		}
	},
	_clearClientColumnFilter: function (columnFilter)
	{
		columnFilter.get_condition().set_rule(0);
		var column = this._grid.get_columns().get_columnFromKey(columnFilter.get_columnKey());
		if (column && column.get_type() != "boolean")
			columnFilter.get_condition().set_value("");
	},
	clearClientColumnFilters: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.Filtering.clearClientColumnFilters">
		/// This method should only be used when EnableClientRendering is set to true.
		/// Removes all the column filter objects from the column filters' collection, if they were created on the client,
		/// if the column filter came down from the server, its Rule just gets set to "Clear" and its value to empty.
		/// </summary>		

		if (this._grid.get_enableClientRendering())
		{
			var filtering = this;
			$.each(this._columnFilters, function ()
			{
				filtering._clearClientColumnFilter(this);
			});

			$.each(this._clientColumnFilters, function ()
			{
				filtering._clearClientColumnFilter(this);
			});
			this._clientColumnFilters = [];
		}
	},

	_createFilterInfo: function (filterInfo, columnFilters)
	{
		$.each(columnFilters, function ()
		{
			var value = this.get_condition().get_value();
			var rule = this.get_condition().get_rule();

			if (rule != 0)
			{
				if (this.get_columnType() == "boolean")
					value = (rule == 2 ? "false" : "true");
				filterInfo[filterInfo.length] = { "ColumnType": this.get_columnType(), "KeyColumn": this.get_columnKey(), "Rule": rule, "Value": value };
			}
		});
		return filterInfo;
	},

	

	
	get_columnSettings: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.Filtering.columnSettings">
		/// Gets the column filters settings collection
		/// </summary>
		/// <value type="Infragistics.Web.UI.ObjectCollection">column filters settings collection </value>
		return this._columnSettings;
	},
	

	

	get_columnSetting: function (index)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.Filtering.columnSetting">
		/// Gets the column filter setting object at the specified index.
		/// </summary>
		///<param name="index" type="Number"  optional="false" mayBeNull="false">
		/// Zero based index
		///</param>
		/// <value type="Infragistics.Web.UI.ColumnFilterSettings">The column filter setting at the specified index</value>
		if (index >= 0 && index < this._columnSettings._items.length)
			return this._columnSettings._items[index];
		else
			return null;
	},

	get_columnSettingFromKey: function (columnKey)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.Filtering.columnSettingFromKey">
		/// Gets the column filter setting object that is tied to the column with the specified column key.
		/// </summary>
		///<param name="columnKey" type="String"  optional="false" mayBeNull="false">
		/// The column key of the column that the column filter setting is tied to.
		///</param>
		/// <value type="Infragistics.Web.UI.ColumnFilterSettings">The column filter setting tied to the specified column key</value>

		for (var i = 0; i < this._columnSettings._items.length; i++)
		{
			if (this._columnSettings._items[i].get_columnKey() === columnKey)
				return this._columnSettings._items[i];
		}

		return null;
	},
	

	
	applyFilters: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.Filtering.applyFilters">
		/// Filters the data by the current column filters.
		/// </summary>
		this._apply_filters(false);
	},

	get_caseSensitive: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.Filtering.caseSensitive">
		/// Indicated whether filtering will be case sensitive or not.
		/// </summary>
		/// <value type="Boolean"></value>
		return this._get_clientOnlyValue("fcs");
	},
	get_uniqueValueCasing: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.Filtering.uniqueValueCasing">
		/// Indicates how the text of the unique value is displayed if filter type is RowFilter and filtering is not case sensitive.
		/// </summary>
		/// <value type="Infragistics.Web.UI.UniqueValueCasing">Location of the filter row</value>    
		return this._get_clientOnlyValue("fuvc");
	},
	get_alignment: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.Filtering.alignment">
		/// Determines the location of the filter row.
		/// </summary>
		/// <value type="Infragistics.Web.UI.FilteringAlignment">Location of the filter row</value>    
		return this._get_clientOnlyValue("fra");
	},

	get_filtered: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.Filtering.filtered">
		/// Indicated whether the grid data is currently filtered.
		/// </summary>
		/// <value type="Boolean"></value>
		return this._get_clientOnlyValue("fa");
	},

	get_visibility: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.Filtering.visibility">
		/// Indicated whether the user interface (filter row) is visible.
		/// </summary>
		/// <value type="Infragistics.Web.UI.FilteringVisibility">Visibility indicator</value>
		return this._get_value($IG.GridFilteringProps.Visibility);
	},

	set_visibility: function (value)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.Filtering.visibility">
		/// Hides or displays the user interface (filter row).
		/// </summary>
		///<param name="value" type="Infragistics.Web.UI.FilteringVisibility"  optional="false" mayBeNull="false">
		/// An indicator that the filter row needs to be hidden or shown.
		///</param>

		this._set_value($IG.GridFilteringProps.Visibility, value);
		var scrollIntersection = this._grid._elements["filterInter"];
		if (this._filterType == $IG.FilteringType.RowFilter)
		{
			if (value == $IG.FilteringVisibility.Visible)
			{
				this._row._element.style.display = "";
				if (scrollIntersection)
					scrollIntersection.style.display = "";

				




				if ($util.IsFireFox2 && this.get_alignment() == $IG.FilteringAlignment.Bottom)
				{
					var width = this._row._element.childNodes[0].style.width;
					elm = this._row._element.childNodes[0];
					elm.style.width = "0px";
					setTimeout($util.createDelegate(this, this._adjFootVisibility, [elm, width]), 1);
				}
				else
				{
					this._row._element.style.visibility = "visible";
					if (scrollIntersection)
					{
						scrollIntersection.style.visibility = "visible";
						this._grid._onResize({ "clientHeight": this._grid._element.clientHeight }, false);
					}

				}
			}
			else
			{
				this._row._element.style.display = "none";
				this._row._element.style.visibility = "hidden";
				if (scrollIntersection)
				{
					scrollIntersection.style.display = "none";
					scrollIntersection.style.visibility = "hidden";
					this._grid._onResize({ "clientHeight": this._grid._element.clientHeight }, false);
				}
			}
		}
	},

	get_filterRuleDropdownZIndex: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.Filtering.filterRuleDropdownZIndex">
		/// Retruns the Z-Index of the filter rule dropdown element.  The default Z-Index is 100100
		/// </summary>
		/// <value type="Number">Z-Index of the filter rule dropdown element.</value>
		return this._get_value($IG.GridFilteringProps.RuleDropdownZIndex);
	},

	set_filterRuleDropdownZIndex: function (value)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.Filtering.filterRuleDropdownZIndex">
		/// Sets the Z-Index of the filter rule dropdown element.
		/// </summary>
		///<param name="value" type="Number"  optional="false" mayBeNull="false">
		/// Z-Index of the filter rule dropdown element.
		///</param>

		if (value == null || value == undefined)
			return;

		this._set_value($IG.GridFilteringProps.RuleDropdownZIndex, value);

		for (var i = 0; i < this._dropDownBehaviorsCount; i++)
		{
			if (this._dropDownBehaviors[i])
				this._dropDownBehaviors[i].set_zIndex(value);
		}
	},

	get_animationEnabled: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.Filtering.animationEnabled">
		/// Indicates whether the filter rule dropdown will play an animation while it is displaying and hiding
		/// </summary>
		/// <value type="Boolean">True if an animation will play, false otherwise</value>
		return this._get_clientOnlyValue("fae");
	},

	get_animationType: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.Filtering.animationType">
		/// The type of animation that the filter rule dropdown will play when it is displaying and hiding.
		/// </summary>
		/// <value type="Infragistics.Web.UI.AnimationEquationType">The animation type</value>
		return this._get_clientOnlyValue("fat");
	},

	get_animationDurationMs: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.Filtering.animationDurationMs">
		/// The duration of the animation that the filter rule dropdown will play while its displaying or hiding 
		/// in milliseconds
		/// </summary>
		/// <value type="Number">Animation duration in milliseconds</value>
		return this._get_clientOnlyValue("fad");
	},

	updateFilterUI: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.Filtering.updateFilterUI">
		/// This method should only be used if the EnableClientRendering property
		/// is set to true.  The method will go through all the exising columnFilters
		/// and update the filter buttons for the matching columns as filtered. 
		/// </summary>

		if (this._grid.get_enableClientRendering() && this._row)
		{
			var defaultAfterUrl = this._get_clientOnlyValue("defAftImg");
			var defaultBeforeUrl = this._get_clientOnlyValue("defBefImg");
			var beforeAltTxt = this._get_clientOnlyValue("defBefAlt");
			var filtering = this;

			

			$(this._row.get_element()).find("img[mkr = 'aftapp']").each(function ()
			{
				var cellElement = $($(this).parent()).parent();
				var adr = parseInt(cellElement.attr("adr"));
				adr = (isNaN(adr) ? filtering._grid._gridUtil._getColumnAdrFromVisibleIndex(filtering._grid._gridUtil.getCellIndexFromElem(cellElement.get(0))) : adr);
				var cell = filtering._row.get_cell(adr);
				var key = cell.get_column().get_key();

				var columnFilter = filtering.get_columnFilterFromKey(key);
				columnFilter = columnFilter ? columnFilter : filtering._get_clientColumnFilterFromKey(key);
				if (!columnFilter || columnFilter.get_condition().get_rule() == 0)
				{
					var setting = filtering.get_columnSettingFromKey(key);
					var beforeUrl = (setting ? setting._get_clientOnlyValue("befImg") : defaultBeforeUrl);
					var altText = (setting ? setting._get_clientOnlyValue("befAlt") : beforeAltTxt);

					$(($(this).attr("src", beforeUrl).attr("mkr", "befapp").attr("alt", altText).attr("title", altText)).parent()).attr("title", altText);
				}
			});

			

			$.each(this._columnFilters, function ()
			{
				filtering._updateColumnFilterUI(this, defaultAfterUrl);
			});

			

			$.each(this._clientColumnFilters, function ()
			{
				filtering._updateColumnFilterUI(this, defaultAfterUrl);
			});

			this._grid._onDataTblResize({ "clientHeight": this._grid._elements.dataTbl.clientHeight }, null);
			this._grid._onResize({ "clientHeight": this._grid._element.clientHeight }, false);
		}
	},

	dispose: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.Filtering.dispose">
		/// This method is called by the framework, when the grid unloads.  This
		/// is where the Filtering behavior removes all the event handlers that it
		/// had attached.
		/// </summary>

		if (!this._grid)
			return;

		delete this._hierarchical;

		

		
		this._closeRuleDropdown(this._visibleDropdownCell, 1);

		var targetsToDelete = [];
		var animationContainerToDelete = [];
		
		for (var i = 0; i < this._dropDownBehaviorsCount; i++)
		{
			if (this._dropDownBehaviors[i])
			{
				targetsToDelete[targetsToDelete.length] = this._dropDownBehaviors[i].get_targetContainer();
				animationContainerToDelete[animationContainerToDelete.length] = this._dropDownBehaviors[i].get_animationsContainer();
				this._dropDownBehaviors[i].dispose();
			}
			this._dropDownBehaviors[i] = null;
		}
		this._dropDownBehaviors = null;
		this._dropDownBehaviorsCount = 0;

		if (this._onMouseDownHandler)
		{
			$removeHandler(($util.IsIE8 ? document.documentElement : document), 'mousedown', this._onMouseDownHandler);
			delete this._onMouseDownHandler;
		}

		if (this._onMouseUpHandler)
		{
			$removeHandler(($util.IsIE8 ? document.documentElement : document), 'mouseup', this._onMouseUpHandler);
			delete this._onMouseUpHandler;
		}

		if (this._onMousewheelHandler)
		{
			$removeHandler(($util.IsIE8 ? document.documentElement : document), 'mousewheel', this._onMousewheelHandler);
			if ($util.IsFireFox)
				$removeHandler(window, "DOMMouseScroll", this._onMousewheelHandler);
			try	
			{
				$removeHandler(this._gridContainer, "scroll", this._onMousewheelHandler);
			} catch (e) { }
			
			if (this._initializedParentGrids)
			{
				for (var x = 0; this._ancestorGridElements != null && x < this._ancestorGridElements.length; ++x)
				{
					try
					{
						$removeHandler(this._ancestorGridElements[x], "scroll", this._onMousewheelHandler);
					} catch (e) { }
					this._ancestorGridElements[x] = null;
				}
				delete this._ancestorGridElements;
				delete this._initializedParentGrids;
			}


			delete this._onMousewheelHandler;
		}

		if (this._onKeyDownHandler)
		{
			$removeHandler(($util.IsIE8 ? document.documentElement : document), 'keydown', this._onKeyDownHandler);
			delete this._onKeyDownHandler;
		}

		if (this._onFilterKeyDownHandler)
		{
			$removeHandler(this._row._element, 'keydown', this._onFilterKeyDownHandler);
			delete this._onFilterKeyDownHandler;
		}

		var gridId = this._grid._id;
		var dropDown = $get(gridId + "_NumericRuleDropDown_UL");
		if (this._onSelectRuleHandler)
		{
			if (dropDown)
			{
				try
				{
					$removeHandler($get(gridId + "_NumericRuleDropDown_UL"), 'mousedown', this._onSelectRuleHandler);
					$removeHandler($get(gridId + "_TextRuleDropDown_UL"), 'mousedown', this._onSelectRuleHandler);
					$removeHandler($get(gridId + "_DateTimeRuleDropDown_UL"), 'mousedown', this._onSelectRuleHandler);
					$removeHandler($get(gridId + "_BooleanRuleDropDown_UL"), 'mousedown', this._onSelectRuleHandler);
				} catch (e) { }
			}
			for (var i = 0; i < targetsToDelete.length; i++)
			{
				try
				{
					$removeHandler(targetsToDelete[i].firstChild, 'mousedown', this._onSelectRuleHandler);
				} catch (e) { }
			}


			delete this._onSelectRuleHandler;
		}

		if (this._onMouseOverRuleHandler)
		{
			if (dropDown)
			{
				try
				{
					$removeHandler($get(gridId + "_NumericRuleDropDown_UL"), 'mouseover', this._onMouseOverRuleHandler);
					$removeHandler($get(gridId + "_TextRuleDropDown_UL"), 'mouseover', this._onMouseOverRuleHandler);
					$removeHandler($get(gridId + "_DateTimeRuleDropDown_UL"), 'mouseover', this._onMouseOverRuleHandler);
					$removeHandler($get(gridId + "_BooleanRuleDropDown_UL"), 'mouseover', this._onMouseOverRuleHandler);
				} catch (e) { }
			}
			for (var i = 0; i < targetsToDelete.length; i++)
			{
				try
				{
					$removeHandler(targetsToDelete[i].firstChild, 'mouseover', this._onMouseOverRuleHandler);
				} catch (e) { }
			}
			delete this._onMouseOverRuleHandler;
		}

		if (this._onMouseOutRuleHandler)
		{
			if (dropDown)
			{
				try
				{
					$removeHandler($get(gridId + "_NumericRuleDropDown_UL"), 'mouseout', this._onMouseOutRuleHandler);
					$removeHandler($get(gridId + "_TextRuleDropDown_UL"), 'mouseout', this._onMouseOutRuleHandler);
					$removeHandler($get(gridId + "_DateTimeRuleDropDown_UL"), 'mouseout', this._onMouseOutRuleHandler);
					$removeHandler($get(gridId + "_BooleanRuleDropDown_UL"), 'mouseout', this._onMouseOutRuleHandler);
				} catch (e) { }
			}
			for (var i = 0; i < targetsToDelete.length; i++)
			{
				try
				{
					$removeHandler(targetsToDelete[i].firstChild, 'mouseout', this._onMouseOutRuleHandler);
				} catch (e) { }
			}
			delete this._onMouseOutRuleHandler;
		}

		if (this._onKeyDownRuleHandler)
		{
			if (dropDown)
			{
				try
				{
					$removeHandler($get(gridId + "_NumericRuleDropDown"), 'keydown', this._onKeyDownRuleHandler);
					$removeHandler($get(gridId + "_TextRuleDropDown"), 'keydown', this._onKeyDownRuleHandler);
					$removeHandler($get(gridId + "_DateTimeRuleDropDown"), 'keydown', this._onKeyDownRuleHandler);
					$removeHandler($get(gridId + "_BooleanRuleDropDown"), 'keydown', this._onKeyDownRuleHandler);
				} catch (e) { }
			}
			for (var i = 0; i < targetsToDelete.length; i++)
			{
				try
				{
					$removeHandler(targetsToDelete[i].firstChild, 'keydown', this._onKeyDownRuleHandler);
				} catch (e) { }
			}
			delete this._onKeyDownRuleHandler;
		}

		if (this._onTouchStartRuleHandler)
		{
			if (dropDown)
			{
				try
				{
					$removeHandler($get(gridId + "_DateTimeRuleDropDown"), window.navigator.msPointerEnabled ? 'msPointerDown' : 'touchstart', this._onTouchStartRuleHandler);
				} catch (e) { }
			}
			for (var i = 0; i < targetsToDelete.length; i++)
			{
				try
				{
					$removeHandler(targetsToDelete[i], window.navigator.msPointerEnabled ? 'msPointerDown' : 'touchstart', this._onTouchStartRuleHandler);
				} catch (e) { }
			}
			delete this._onTouchStartRuleHandler;
		}

		if (this._onTouchMoveRuleHandler)
		{
			if (dropDown)
			{
				try
				{
					$removeHandler($get(gridId + "_DateTimeRuleDropDown"), window.navigator.msPointerEnabled ? 'msPointerDown' : 'touchmove', this._onTouchMoveRuleHandler);
				} catch (e) { }
			}
			for (var i = 0; i < targetsToDelete.length; i++)
			{
				try
				{
					$removeHandler(targetsToDelete[i], window.navigator.msPointerEnabled ? 'msPointerDown' : 'touchmove', this._onTouchMoveRuleHandler);
				} catch (e) { }
			}
			delete this._onTouchMoveRuleHandler;
		}

		if (this._onTouchEndRuleHandler)
		{
			if (dropDown)
			{
				try
				{
					$removeHandler($get(gridId + "_DateTimeRuleDropDown"), window.navigator.msPointerEnabled ? 'msPointerDown' : 'touchend', this._onTouchEndRuleHandler);
				} catch (e) { }
			}
			for (var i = 0; i < targetsToDelete.length; i++)
			{
				try
				{
					$removeHandler(targetsToDelete[i], window.navigator.msPointerEnabled ? 'msPointerDown' : 'touchend', this._onTouchEndRuleHandler);
				} catch (e) { }
			}
			delete this._onTouchEndRuleHandler;
		}

		if (this._onKeyPressRuleHandler)
		{
			$removeHandler(document, 'keypress', this._onKeyPressRuleHandler);
			delete this._onKeyPressRuleHandler;
		}
		if (this._resolvingCellElemHandler)
		{
			this._grid._gridUtil._unregisterEventListener(this._grid, "ResolvingCellElem", this._resolvingCellElemHandler);
			delete this._resolvingCellElemHandler;
		}
		if (this._onGridResizeHandler)
		{
			this._grid._gridUtil._unregisterEventListener(this._grid, "Resize", this._onGridResizeHandler);
			delete this._onGridResizeHandler;
		}

		if (!Sys.Application._disposing)
		{
			if (this._columnFilters && this._columnFilters.length)
			{
				for (var i = 0; i < this._columnFilters.length; i++)
				{
					if (this._columnFilters[i])
						this._columnFilters[i].dispose();
					this._columnFilters[i] = null;
				}
			}

			if (this._uniqueValuesColumnFilters && this._uniqueValuesColumnFilters.length)
			{
				for (var i = 0; i < this._uniqueValuesColumnFilters.length; i++)
				{
					if (this._uniqueValuesColumnFilters[i])
						this._uniqueValuesColumnFilters[i].dispose();
					this._uniqueValuesColumnFilters[i] = null;
				}
			}
		}
		this._columnFilters = null;
		this._uniqueValuesColumnFilters = null;

		if (this._clientColumnFilters && this._clientColumnFilters.length)
		{
			for (var i = 0; i < this._clientColumnFilters.length; i++)
			{
				if (this._clientColumnFilters[i])
					this._clientColumnFilters[i].dispose();
				this._clientColumnFilters[i] = null;
			}
		}
		this._clientColumnFilters = null;

		if (this.__tmpCheckBoxFilters && this.__tmpCheckBoxFilters.length)
		{
			for (var i = 0; i < this.__tmpCheckBoxFilters.length; i++)
			{
				if (this.__tmpCheckBoxFilters[i])
					this.__tmpCheckBoxFilters[i].dispose();
				this.__tmpCheckBoxFilters[i] = null;
			}
		}
		this.__tmpCheckBoxFilters = null;
		this.__tmpCheckBoxFiltersToRemove = null;

		for (var i = 0; i < targetsToDelete.length; i++)
		{
			if (targetsToDelete[i] && targetsToDelete[i].parentNode)
			{
				if (this._filterType == $IG.FilteringType.ExcelStyleFilter)
				{
					if (this._cancelBtnClickHandler)
						$removeHandler(targetsToDelete[i].lastChild, 'click', this._cancelBtnClickHandler);

					if (this._okBtnClickHandler)
						$removeHandler(targetsToDelete[i].lastChild.previousSibling, 'click', this._okBtnClickHandler);

					if (this._checkBoxClickHandler)
					{
						var listItems = targetsToDelete[i].lastChild.previousSibling.previousSibling.firstChild.childNodes;
						for (var j = 0; j < listItems.length; j++)
							$removeHandler(listItems[j].firstChild, 'mousedown', this._checkBoxClickHandler);
					}
				}
				targetsToDelete[i].parentNode.removeChild(targetsToDelete[i]);
				targetsToDelete[i] = null;
			}
		}
		delete this._checkBoxClickHandler;
		delete this._cancelBtnClickHandler;
		delete this._okBtnClickHandler;
		targetsToDelete = null;

		for (var i = 0; i < animationContainerToDelete.length; i++)
		{
			if (animationContainerToDelete[i] && animationContainerToDelete[i].parentNode)
			{
				animationContainerToDelete[i].parentNode.removeChild(animationContainerToDelete[i]);
				animationContainerToDelete[i] = null;
			}
		}
		animationContainerToDelete = null;


		var btnCnt = this._filterHeaderButtons && this._filterHeaderButtons.length ? this._filterHeaderButtons.length : 0;
		for (var i = 0; i < btnCnt; i++)
		{
			var filterBtn = this._filterHeaderButtons[i];
			var filterImg = filterBtn.firstChild;
			if ($util.IsFireFox || $util.IsOpera)
			{
				$removeHandler(filterBtn, 'mouseover', this._onImgMouseOverHandler);
				$removeHandler(filterBtn, 'mouseout', this._onImgMouseOutHandler);
			}
			else
			{
				if (this._onImgMouseOverHandler)
				{
					try
					{
						$removeHandler(filterImg, 'mouseover', this._onImgMouseOverHandler);
					} catch (e) { }
				}
				if (this._onImgMouseOutHandler)
				{
					try
					{
						$removeHandler(filterImg, 'mouseout', this._onImgMouseOutHandler);
					} catch (e) { }
				}
			}
			if (this._onImgMouseDownHandler)
			{
				try
				{
					$removeHandler(filterBtn, 'mousedown', this._onImgMouseDownHandler);
				} catch (e) { }
			}
			if (this._onImgMouseClickHandler)
			{
				try
				{
					$removeHandler(filterBtn, 'click', this._onImgMouseClickHandler);
				} catch (e) { }
			}
			if (this._onBtnKeyDownHandler)
			{
				try
				{
					$removeHandler(filterBtn, 'keydown', this._onBtnKeyDownHandler);
				} catch (e) { }
			}
			if ($util.IsOpera && this._onBtnKeyPressHandler)
			{
				try
				{
					$removeHandler(filterBtn, 'keypress', this._onBtnKeyPressHandler);
				} catch (e) { }
			}
			if (this._onBtnFocusHandler)
			{
				try
				{
					$removeHandler(filterBtn, 'focus', this._onBtnFocusHandler);
				} catch (e) { }
			}
			this._filterHeaderButtons[i] = null;
		}

		delete this._filterHeaderButtons;
		delete this._filterHeaderButtonsObjs;
		this._objectManager = null;
		this._columnFixing = null;
		this._activation = null;
		this._columnResizing = null;
		this._rowSelectors = null;
		this.editSpan = null;
		this.editFilterButton = null;
		this._visibleDropdownCell = null;
		this.__defaultDate = null;

		$IG.Filtering.callBaseMethod(this, "dispose");
		this._grid = null;
		this._gridElement = null;
		this._gridContainer = null;
		this._container = null;
		if (this._filterType == $IG.FilteringType.RowFilter)
			this._row.dispose();
		this._row = null;
	},

	

	
	_initializeAdvanceFilterView: function ()
	{
		this._filterHeaderButtons = this._grid._elements["filBtn"];
		if (this._filterHeaderButtons && !this._filterHeaderButtons.length)
		{
			var filterBtn = this._filterHeaderButtons;
			this._filterHeaderButtons = [];
			this._filterHeaderButtons[0] = filterBtn;
		}
		this._filterHeaderButtonsObjs = [];

		var gridId = this._grid._id;

		this._onImgMouseOverHandler = Function.createDelegate(this, this._onImgMouseOver);
		this._onImgMouseOutHandler = Function.createDelegate(this, this._onImgMouseOut);
		this._onImgMouseDownHandler = Function.createDelegate(this, this._onImgMouseDown);
		this._onImgMouseClickHandler = Function.createDelegate(this, this._onImgMouseClick);
		this._onBtnKeyDownHandler = Function.createDelegate(this, this._onBtnKeyDown);
		this._onBtnFocusHandler = Function.createDelegate(this, this._onBtnFocus);
		if ($util.IsOpera)
			this._onBtnKeyPressHandler = Function.createDelegate(this, this._onBtnKeyPress);
		var btnCnt = this._filterHeaderButtons && this._filterHeaderButtons.length ? this._filterHeaderButtons.length : 0;
		for (var i = 0; i < btnCnt; i++)
		{
			var filterBtn = this._filterHeaderButtons[i];
			var filterImg = filterBtn.firstChild;
			if ($util.IsFireFox || $util.IsOpera)
			{
				$addHandler(filterBtn, 'mouseover', this._onImgMouseOverHandler);
				$addHandler(filterBtn, 'mouseout', this._onImgMouseOutHandler);
			}
			else
			{
				$addHandler(filterImg, 'mouseover', this._onImgMouseOverHandler);
				$addHandler(filterImg, 'mouseout', this._onImgMouseOutHandler);
			}
			$addHandler(filterBtn, 'mousedown', this._onImgMouseDownHandler);
			$addHandler(filterBtn, 'click', this._onImgMouseClickHandler);
			$addHandler(filterBtn, 'keydown', this._onBtnKeyDownHandler);
			if ($util.IsOpera)
				$addHandler(filterBtn, 'keypress', this._onBtnKeyPressHandler);
			$addHandler(filterBtn, 'focus', this._onBtnFocusHandler);
		}
	},
	_get_filterHeaderButtonObject: function (column, elem)
	{
		var key = column.get_key();
		if (this._filterHeaderButtonsObjs[key] == null)
		{
			var filters = this.get_uniqueValuesColumnFiltersFromKey(key);
			this._filterHeaderButtonsObjs[key] = new $IG.ImageObject("filBtn", elem, this._objectManager.get_objectProps((filters && filters.length > 0 ? this._objectManager.__createdObjectCount + 1 : this._objectManager.__createdObjectCount)), this);

			var altTxt = this._filterHeaderButtonsObjs[key]._get_clientOnlyValue("altTxt");
			var btnElement = this._filterHeaderButtonsObjs[key].get_element();
			if (altTxt && btnElement && column.get_headerElement())
			{
				var formatedAltTxt = String.format(altTxt, column.get_headerText());
				btnElement.alt = formatedAltTxt;
				btnElement.title = formatedAltTxt;
			}
		}
		return this._filterHeaderButtonsObjs[key];
	},
	_onBtnKeyPress: function (evnt)
	{
		if (this._OperaCancelEvent)
		{
			$util.cancelEvent(evnt);
			this._OperaCancelEvent = false;
		}
	},

	_onBtnFocus: function (evnt)
	{
		if (this._grid.get_rows().get_length() > 0)
		{
			var btnCount = this._filterHeaderButtonsObjs.length;
			for (var x = 0; x < btnCount; x++)
			{
				if (this._filterHeaderButtonsObjs[x] == evnt.target)
					break;
			}
			var row = this._grid.get_rows().get_row(0);
			row.get_cell(x).scrollToView(1);
		}
	},
	_onBtnKeyDown: function (evnt)
	{
		if (this._activation && evnt.keyCode == Sys.UI.Key.tab && !evnt.shiftKey)
		{
			if (this._activation.get_activeCell())
				return;
			var btnCount = this._filterHeaderButtonsObjs.length;
			for (var x = 0; x < btnCount; x++)
			{
				if (this._filterHeaderButtonsObjs[x] == evnt.target)
					break;
			}

			if (x == btnCount - 1 && this._grid.get_rows().get_length() > 0)
			{
				var visCol = this._grid._gridUtil._findFirstVisibleColumn();
				var topAuxRows = this._grid._get_auxRows($IG.GridAuxRows.Top);
				if (topAuxRows && topAuxRows.length > 0)
					this._activation.set_activeCell(topAuxRows[0].get_cell(visCol.get_index()));
				else
					this._activation.set_activeCell(this._grid.get_rows().get_row(0).get_cell(visCol.get_index()));
				if ($util.IsOpera)
					this._OperaCancelEvent = true;
				$util.cancelEvent(evnt);
			}
		}
		else if (this._activation && evnt.keyCode == Sys.UI.Key.space)
		{
			$util.cancelEvent(evnt);
			if ($util.IsOpera)
				this._OperaCancelEvent = true;
			this._onImgMouseClick(evnt);
		}
	},
	_onImgMouseOver: function (evnt)
	{
		$util.cancelEvent(evnt);
		var target = evnt.target;
		var element;
		var td;
		if (target.getAttribute("mkr") == "filBtn")
		{
			element = target.firstChild;
			td = target.parentNode;
		}
		else
		{
			element = target;
			td = target.parentNode.parentNode;
		}

		var column = null;
		if (td)
		{
			if (this._grid._hasHeaderLayout)
				column = this._grid.get_columns().get_columnFromKey(td.getAttribute("key"));
			else
				column = this._grid._gridUtil._getColumnFromHeader(td);
		}
		if (column)
		{
			var btn = this._get_filterHeaderButtonObject(column, element);
			if (btn)
				btn.setState($IG.ImageState.Hover);
		}
	},

	_onImgMouseOut: function (evnt)
	{
		$util.cancelEvent(evnt);
		var target = evnt.target;
		var element;
		var td;
		if (target.getAttribute("mkr") == "filBtn")
		{
			element = target.firstChild;
			td = target.parentNode;
		}
		else
		{
			element = target;
			td = target.parentNode.parentNode;
		}
		var column = null;
		if (td)
		{
			if (this._grid._hasHeaderLayout)
				column = this._grid.get_columns().get_columnFromKey(td.getAttribute("key"));
			else
				column = this._grid._gridUtil._getColumnFromHeader(td);
		}
		if (column)
		{
			var btn = this._get_filterHeaderButtonObject(column, element);
			if (btn)
				btn.setState($IG.ImageState.Normal);
		}
	},

	_onImgMouseDown: function (evnt)
	{
		
		
		this._ie10FixrememberLastMD(evnt);
		$util.cancelEvent(evnt);
		var target = evnt.target;
		var element;
		var td;
		if (target.getAttribute("mkr") == "filBtn")
		{
			element = target.firstChild;
			td = target.parentNode;
		}
		else
		{
			element = target;
			td = target.parentNode.parentNode;
		}
		var column = null;
		if (td)
		{
			if (this._grid._hasHeaderLayout)
				column = this._grid.get_columns().get_columnFromKey(td.getAttribute("key"));
			else
				column = this._grid._gridUtil._getColumnFromHeader(td);
		}
		if (column)
		{
			var btn = this._get_filterHeaderButtonObject(column, element);
			if (btn)
				btn.setState($IG.ImageState.Pressed);
		}
	},

	_onImgMouseClick: function (evnt)
	{
		$util.cancelEvent(evnt);
		var target = evnt.target;
		var element;
		var td;

		if (target.getAttribute("mkr") == "filBtn")
		{
			element = target.firstChild;
			td = target.parentNode;
		}
		else if (target.tagName != "DIV" && (target.parentNode && target.parentNode.parentNode && target.parentNode.parentNode.tagName != "UL"))
		{
			element = target;
			td = target.parentNode.parentNode;
		}
		else
			return;
		var column = null;
		if (td)
		{
			if (this._grid._hasHeaderLayout)
				column = this._grid.get_columns().get_columnFromKey(td.getAttribute("key"));
			else
				column = this._grid._gridUtil._getColumnFromHeader(td);
		}

		if (column)
		{
			this._droppedBtn = this._get_filterHeaderButtonObject(column, element);
			if (this._droppedBtn)
				this._droppedBtn.setState($IG.ImageState.Normal);
			// now open up drop down
			if (this._columnDroppedDown && !this._columnDroppedDown._filterDropDownBehaviour.get_visible())
				this._columnDroppedDown = null;
			if (this._columnDroppedDown)
			{
				if (this._columnDroppedDown.get_key() == column.get_key())
				{
					this._onCancelBtnClick();
				}
				else
				{
					this._onCancelBtnClick();
					if (!this._columnDroppedDown)
					{
						column._filterDropDownBehaviour.set_visible(true);
						var cancelledOrHidden = column._filterDropDownBehaviour.get_enableAnimations() ? !column._filterDropDownBehaviour.get_isAnimating() : !column._filterDropDownBehaviour.get_visible();
						if (!cancelledOrHidden)
						{
							this._columnDroppedDown = column;
							var dropDown = this._columnDroppedDown._filterDropDownBehaviour.get_targetContainer();
							if (dropDown.firstChild.firstChild)
								dropDown.firstChild.firstChild.focus();
							else
								dropDown.firstChild.nextSibling.focus();
						}
					}
				}
			}
			else
			{
				column._filterDropDownBehaviour.set_visible(true);
				var cancelledOrHidden = column._filterDropDownBehaviour.get_enableAnimations() ? !column._filterDropDownBehaviour.get_isAnimating() : !column._filterDropDownBehaviour.get_visible();
				if (!cancelledOrHidden)
				{
					this._columnDroppedDown = column;
					var dropDown = this._columnDroppedDown._filterDropDownBehaviour.get_targetContainer();
					if (dropDown.firstChild.firstChild)
						dropDown.firstChild.firstChild.focus();
					else
						dropDown.firstChild.nextSibling.focus();
				}
			}
		}
	},
	_onOkBtnClick: function (evnt)
	{
		if (!this._columnDroppedDown)
			return;
		var col = this._columnDroppedDown;
		var cancelled = this._closeFilterDropdown(this._columnDroppedDown);

		if (!cancelled && (this.__tmpCheckBoxFiltersToRemove.length > 0 || this.__tmpCheckBoxFilters.length > 0))
		{

			var DataFilteringEventArgs = new $IG.CancelApplyFiltersEventArgs(this, this._uniqueValuesColumnFilters, this.__tmpCheckBoxFilters, this.__tmpCheckBoxFiltersToRemove);
			DataFilteringEventArgs = this._grid._raiseSenderClientEventStart(this, this._clientEvents["DataFiltering"], DataFilteringEventArgs);
			if (!DataFilteringEventArgs.get_cancel())
			{
				var eventArgs = new $IG.ColumnFilterAddingRemovingEventArgs(this);
				this._grid._actionList.add_transaction(new $IG.FilteringAction("CheckBoxColFilter", this.get_name(), this._grid, { "add": DataFilteringEventArgs.get_uniqueValueFiltersToAdd(), "delete": DataFilteringEventArgs.get_uniqueValueFiltersToDelete() }, null));
				//this._grid._actionList.add_transaction(new $IG.FilteringAction("CheckBoxColFilter", this.get_name(), this._grid, { "add": this.__tmpCheckBoxFilters, "delete": this.__tmpCheckBoxFiltersToRemove }, null));

				
				if (!this._grid._enableAjax)
					this._owner._postAction(1);
				else
					this._owner._raiseClientEventEnd(eventArgs);
			}
		}
	},
	_onCancelBtnClick: function (evnt)
	{
		if (!this._columnDroppedDown)
			return;

		var dropDown = this._columnDroppedDown._filterDropDownBehaviour.get_targetContainer();
		var col = this._columnDroppedDown;
		var cancelled = this._closeFilterDropdown(this._columnDroppedDown);
		if (!cancelled && dropDown && (this.__tmpCheckBoxFiltersToRemove.length > 0 || this.__tmpCheckBoxFilters.length > 0))
		{
			var columnType = col.get_type();
			var listItems = null;
			var childElems = dropDown.childNodes;
			for (var i = 0; childElems && i < childElems.length; i++)
			{
				var child = childElems[i];
				if (child.id == "listDiv" && child.firstChild)
				{
					listItems = child.firstChild.childNodes;
					break;
				}
			}
			if (listItems && listItems.length)
			{
				for (var itr = 0; itr < this.__tmpCheckBoxFilters.length; itr++)
				{
					var value = this.__tmpCheckBoxFilters[itr].get_condition().get_value();

					for (var i = 0; i < listItems.length; i++)
					{
						var val = listItems[i].getAttribute("val");
						var isNull = listItems[i].getAttribute("isNull");
						if ((value == val && (columnType != "string" || val != "null" || (columnType == "string" && val == "null" && (isNull == "1" && this.__tmpCheckBoxFilters[itr].get_condition().get_rule() == $IG.TextFilterRules.IsNotNull || isNull == "0" && this.__tmpCheckBoxFilters[itr].get_condition().get_rule() == $IG.TextFilterRules.DoesNotEqual))))
							|| (columnType == "boolean" && ((val == "false" && this.__tmpCheckBoxFilters[itr].get_condition().get_rule() == $IG.BooleanFilterRules.IsNotFalse) || (val == "true" && this.__tmpCheckBoxFilters[itr].get_condition().get_rule() == $IG.BooleanFilterRules.IsNotTrue)))
							|| (columnType == "date" && val != null && value != null && value.toLocaleString() == val.toLocaleString()))
						{
							this.__setChecked(listItems[i].firstChild);
							break;
						}
					}

				}
				this.__tmpCheckBoxFilters = [];

				for (var itr = 0; itr < this.__tmpCheckBoxFiltersToRemove.length; itr++)
				{
					var value = this.__tmpCheckBoxFiltersToRemove[itr]["val"];

					for (var i = 0; i < listItems.length; i++)
					{
						var val = listItems[i].getAttribute("val");
						if (value == val || (columnType == "date" && val != null && value != null && value.toLocaleString() == val.toLocaleString()))
						{
							this.__setUnchecked(listItems[i].firstChild);
							break;
						}
					}

				}
				this.__tmpCheckBoxFiltersToRemove = [];
			}
		}
	},
	_closeFilterDropdown: function (column)
	{
		column._filterDropDownBehaviour.set_visible(false);

		

		var cancelledOrHidden = column._filterDropDownBehaviour.get_enableAnimations() ? !column._filterDropDownBehaviour.get_isAnimating() : column._filterDropDownBehaviour.get_visible();
		if (!cancelledOrHidden)
		{
			this._columnDroppedDown = null;
			this._droppedBtn.get_element().parentNode.focus();
		}
		return cancelledOrHidden;
	},
	_findFilterHeaderBtnHeaderLayout: function (column)
	{
		var colElem = column.get_headerElement();
		for (var i = 0; i < this._filterHeaderButtons.length; i++)
		{
			if (colElem == this._filterHeaderButtons[i].parentNode)
				return this._filterHeaderButtons[i];
		}
		return null;
	},

	_updateColumnFilterUI: function (columnFilter, defaultAfterUrl, afterUrl)
	{
		var condition = columnFilter.get_condition();
		var cell = condition._get_filterCell();
		if (cell)
		{
			var rule = condition.get_rule();
			var type = condition._type;

			if (rule != 0)
			{
				var setting = this.get_columnSettingFromKey(columnFilter.get_columnKey());
				var afterUrl = (setting ? setting._get_clientOnlyValue("aftImg") : defaultAfterUrl);
				var filterButton = cell.get_element().firstChild;

				$(filterButton.firstChild).attr("src", afterUrl).attr("mkr", "aftapp");

				var ruleElm = this._getRuleElement(rule, cell._dropDownBehaviour._targetContainer);
				if (ruleElm != null)
				{
					var title = ruleElm.innerHTML;
					$(filterButton).attr("title", title);
					$(filterButton.firstChild).attr("alt", title).attr("title", title);
				}
			}
		}
	},
	_adjFootVisibility: function (elm, width)
	{
		elm.style.width = width;
		this._row._element.style.visibility = "visible";
		var scrollIntersection = this._grid._elements["filterInter"];

		if (scrollIntersection)
		{
			scrollIntersection.style.visibility = "visible";
			this._grid._onResize({ "clientHeight": this._grid._element.clientHeight }, false);
		}
	},

	_createObjects: function (objectManager)
	{
		objectManager.__createdObjectCount = 0;

		$IG.Filtering.callBaseMethod(this, "_createObjects", [objectManager]);
		var cos = objectManager.__createdObjectCount;
		this._objectManager = objectManager;
		this._columnFilters = [];
		var columnFiltersCount = parseInt(this._get_clientOnlyValue("cfc"));
		for (var i = 0; i < columnFiltersCount; i++)
		{
			var obj = new $IG.ColumnFilter("ColumnFilter", null, objectManager.get_objectProps(cos + i), this);
			objectManager.register_object(cos + i, obj);
			objectManager.__createdObjectCount++;

			
			
			if (obj.get_columnType() == "number" && obj.get_condition() && isNaN(obj.get_condition().get_value()))
				obj.get_condition()._override_value($IG.FilteringNodeObjectProps.Value, "");
			//obj.get_condition()._set_value($IG.FilteringNodeObjectProps.Value, "");
			this._columnFilters[i] = obj;
			obj = null;
		}

		if (this._filterType == $IG.FilteringType.ExcelStyleFilter)
		{
			this._uniqueValuesColumnFilters = [];
			var count = parseInt(this._get_clientOnlyValue("uncfc"));
			cos = objectManager.__createdObjectCount;
			for (var i = 0; i < count; i++)
			{
				var obj = new $IG.ColumnFilter("ColumnFilter", null, objectManager.get_objectProps(cos + i), this);
				objectManager.register_object(cos + i, obj);
				objectManager.__createdObjectCount++;
				
				if (obj.get_columnType() == "number" && obj.get_condition() && isNaN(obj.get_condition().get_value()))
					obj.get_condition()._set_value($IG.FilteringNodeObjectProps.Value, "");
				this._uniqueValuesColumnFilters[i] = obj;
				obj = null;
			}
		}
	},

	_createCollections: function (collectionsManager)
	{
		this._columnSettings = collectionsManager.register_collection(0, $IG.ObjectCollection);
		var collectionItems = collectionsManager._collections[0];
		for (var columnKey in collectionItems)
			this._columnSettings._addObject($IG.ColumnFilterSettings, null, columnKey);

		
		if (this._filterType != $IG.FilteringType.RowFilter && this._filterHeaderButtons)
		{
			var numRulesSelect, strRulesSelect, dateRulesSelect, boolRulesSelect;

			numRulesSelect = this._createRulesSelect(this._get_clientOnlyValue("numRulesTxt").split(";"), this._get_clientOnlyValue("numRulesVals").split(";"));
			strRulesSelect = this._createRulesSelect(this._get_clientOnlyValue("strRulesTxt").split(";"), this._get_clientOnlyValue("strRulesVals").split(";"));
			dateRulesSelect = this._createRulesSelect(this._get_clientOnlyValue("dateRulesTxt").split(";"), this._get_clientOnlyValue("dateRulesVals").split(";"));
			boolRulesSelect = this._createRulesSelect(this._get_clientOnlyValue("boolRulesTxt").split(";"), this._get_clientOnlyValue("boolRulesVals").split(";"));

			var defaultDropDiv = document.createElement("div");
			//defaultDropDiv.setAttribute("className", this._get_clientOnlyValue("frdd"));
			defaultDropDiv.className = this._get_clientOnlyValue("frdd");
			defaultDropDiv.setAttribute("id", this._grid._id + "filterDropDiv");
			defaultDropDiv.setAttribute("mkr", "filterDropDiv");
			defaultDropDiv.setAttribute("tabIndex", "0");

			var span = document.createElement("div");
			span.setAttribute("id", "title");

			var img = document.createElement("img");
			img.setAttribute("src", this._get_clientOnlyValue("hicon"));
			span.appendChild(img);
			defaultDropDiv.appendChild(span);

			var okButton = document.createElement("input");
			okButton.setAttribute("type", "button");
			okButton.setAttribute("value", this._get_clientOnlyValue("okTxt"));
			okButton.setAttribute("id", "filterDDOkBtn");
			defaultDropDiv.appendChild(okButton);

			var cancelButton = document.createElement("input");
			cancelButton.setAttribute("type", "button");
			cancelButton.setAttribute("value", this._get_clientOnlyValue("cnTxt"));
			cancelButton.setAttribute("id", "filterDDCancelBtn");


			defaultDropDiv.appendChild(cancelButton);
			this._cancelBtnClickHandler = Function.createDelegate(this, this._onCancelBtnClick);
			this._okBtnClickHandler = Function.createDelegate(this, this._onOkBtnClick);

			this._checkBoxClickHandler = Function.createDelegate(this, this._onCheckBoxClick);

			this._checkedImg = this._get_clientOnlyValue("chbxck");
			this._uncheckedImg = this._get_clientOnlyValue("chbxuk");
			this._partialImg = this._get_clientOnlyValue("chbxpl");

			this._checkedAlt = this._get_clientOnlyValue("chbxckAlt");
			this._uncheckedAlt = this._get_clientOnlyValue("chbxukAlt");
			this._partialAlt = this._get_clientOnlyValue("chbxplAlt");

			var colCount = this._grid.get_columns().get_length();
			var count = 0;
			for (var x = 0; x < colCount; ++x)
			{
				var column = this._grid._gridUtil._getColumnFromVisibleIndex(x);
				var columnKey = column._key;
				var isTemplated = column.get_isTemplated();
				var colSetting = this.get_columnSettingFromKey(columnKey);
				
				if ((colSetting == null || (colSetting && colSetting.get_enabled())) && !isTemplated && column.get_dataType() != 15)
				{
					column._filterDropDownBehaviour = new $IG.DropDownBehavior((this._grid._hasHeaderLayout ? this._findFilterHeaderBtnHeaderLayout(column) : this._filterHeaderButtons[count++]), $util.IsIE);
					var curDropDownBehavior = column._filterDropDownBehaviour;
					
					this._dropDownBehaviors[this._dropDownBehaviorsCount++] = curDropDownBehavior;

					var columnType = column.get_type();
					var elmClone;
					elmClone = defaultDropDiv.cloneNode(true);
					//elmClone.id = "filterDD_" + columnKey;

					var okBtnElem = null;
					for (var i = 0; i < elmClone.childNodes.length; i++)
					{
						var elemId = elmClone.childNodes[i].id;
						if (elemId == "filterDDCancelBtn")
							$addHandler(elmClone.childNodes[i], 'click', this._cancelBtnClickHandler);
						else if (elemId == "filterDDOkBtn")
						{
							okBtnElem = elmClone.childNodes[i];
							$addHandler(elmClone.childNodes[i], 'click', this._okBtnClickHandler);
						}
						else if (elemId == "title")
						{
							elmClone.childNodes[i].innerHTML += column.get_headerText();

							//							if (columnType == "number")
							//							{
							//								var table = document.createElement("table");
							//								table.style.width = "100%";
							//								table.id = "condTbl";
							//								var tr = document.createElement("tr");
							//								var td = document.createElement("td");
							//								td.appendChild(numRulesSelect);
							//								td.style.width = "50%";
							//								tr.appendChild(td);
							//								td = document.createElement("td");
							//								td.appendChild();
							//								td.style.width = "50%";
							//								tr.appendChild(td);
							//								//								var editor = this.__resolveEditorForColumn(column);
							//								//								editor.showEditor(top, left, width, height, this._editCellCssClass, container, cell);
							//							}
						}
					}

					curDropDownBehavior.set_targetContainer(elmClone);
					curDropDownBehavior.set_zIndex(this.get_filterRuleDropdownZIndex());
					curDropDownBehavior.set_animationDurationMs(this.get_animationDurationMs());
					curDropDownBehavior.set_enableAnimations(this.get_animationEnabled());
					curDropDownBehavior.set_animationType(this.get_animationType());

					curDropDownBehavior.set_visibleOnBlur(false);

					curDropDownBehavior.set_position($IG.DropDownPopupPosition.Default);

					var uniqueVals = this._get_clientOnlyValue("vals_" + columnKey);
					var uniqueTxt = this._get_clientOnlyValue("vals_txt_" + columnKey);
					var listDiv = null;
					if (uniqueVals && uniqueVals.length)
					{
						listDiv = document.createElement("div");
						listDiv.setAttribute("id", "listDiv");
						listDiv.className = this._get_clientOnlyValue("lstCss");
						listDiv = elmClone.insertBefore(listDiv, okBtnElem);

						var list = document.createElement("ul");
						list.style.margin = "0pt";
						list.style.padding = "0pt";

						list.setAttribute("key", columnKey);
						list = listDiv.appendChild(list);


						
						var imgCheckbox = document.createElement('img');

						imgCheckbox.setAttribute('chkState', '1');
						imgCheckbox.setAttribute('src', this._checkedImg);
						var imgText = this._checkedAlt.replace("{0}", this._get_clientOnlyValue("allChck"));
						imgCheckbox.setAttribute('numChck', uniqueVals.length);
						imgCheckbox.setAttribute('alt', imgText);
						imgCheckbox.setAttribute('title', imgText);
						var li = document.createElement('li');
						li.className = this._get_clientOnlyValue("lstCssI");
						li.setAttribute("val", "All");
						li.setAttribute("totItems", uniqueVals.length);
						
						li.style.whiteSpace = "nowrap";
						var allLi;
						allLi = li = list.appendChild(li);
						imgCheckbox = li.appendChild(imgCheckbox);
						$addHandler(imgCheckbox, 'mousedown', this._checkBoxClickHandler);
						var txtNode = document.createTextNode(this._get_clientOnlyValue("allChck"));
						li.appendChild(txtNode);

						
						var filters = this.get_uniqueValuesColumnFiltersFromKey(columnKey);
						var checkedItems = uniqueVals.length;
						var nullText = (colSetting ? colSetting._get_clientOnlyValue("fnvs") : this._get_clientOnlyValue("fnvs"));
						for (var j = 0; j < uniqueVals.length; j++)
						{
							var itemValue = uniqueVals[j];

							if (columnType == "date")
								itemValue = this._grid._gridUtil._convertServerDateStringToClientObject(itemValue);

							var itemText = itemValue;
							if (itemText == null)
								itemText = nullText;

							
							if (columnType == "string" && !this.get_caseSensitive() && itemText != null && itemValue != null)
							{
								var casing = (colSetting ? colSetting.get_uniqueValueCasing() : this.get_uniqueValueCasing());
								if (casing == $IG.UniqueValueCasing.Upper)
									itemText = itemText.toUpperCase();
								else if (casing == $IG.UniqueValueCasing.Camel && itemText.length > 0)
								{
									var firstLetter = itemText[0].toUpperCase();
									itemText = firstLetter + itemText.slice(1, itemText.length);
								}

							}
							var li = document.createElement('li');
							
							if (itemValue != null)
							{
								if (uniqueTxt && uniqueTxt.length)
								{
									itemText = uniqueTxt[j];
									li.setAttribute("dTxt", itemText);
								}
								else
									itemText = column._formatValue(itemText);
							}

							li.className = this._get_clientOnlyValue("lstCssI");
							
							li.setAttribute("val", (columnType == "date" && itemValue != null ? itemValue.toLocaleString() : (itemValue == null ? "null" : itemValue)));
							li.setAttribute("isNull", (itemValue == null ? "1" : "0"));
							
							if (columnType == "date" && $util.IsSafari || $util.IsChrome && itemValue != null)
								li.setAttribute("dVal", uniqueVals[j]);

							
							li.style.whiteSpace = "nowrap";
							li = list.appendChild(li);

							var imgCheckbox = document.createElement('img');

							var filterFound = false;
							for (var itr = 0; itr < filters.length; itr++)
							{
								var rule = filters[itr].get_condition().get_rule();
								if ((filters[itr].get_condition().get_value() == itemValue && !(itemValue == null && columnType == "boolean") && !(columnType == "number" && itemValue == 0 && (rule == $IG.NumericFilterRules.IsNotNull || rule == $IG.NumericFilterRules.IsNull)))
									|| (itemValue == null && ((columnType == "boolean" && rule == $IG.BooleanFilterRules.IsNotNull) || (columnType == "date" && rule == $IG.DateTimeFilterRules.IsNotNull) || (columnType == "number" && rule == $IG.NumericFilterRules.IsNotNull) || (columnType == "string" && rule == $IG.TextFilterRules.IsNotNull)))
									|| (columnType == "boolean" && itemValue != null && ((!itemValue && rule == $IG.BooleanFilterRules.IsNotFalse) || (itemValue && rule == $IG.BooleanFilterRules.IsNotTrue)))
									|| (columnType == "date" && itemValue != null && filters[itr].get_condition().get_value() != null && filters[itr].get_condition().get_value().toLocaleString() == itemValue.toLocaleString()))
								{
									checkedItems--;
									filterFound = true;
									break;
								}
							}
							imgCheckbox.setAttribute('chkState', (filterFound ? '0' : '1'));
							imgCheckbox.setAttribute('src', (filterFound ? this._uncheckedImg : this._checkedImg));
							var imgText = (filterFound ? this._uncheckedAlt : this._checkedAlt).replace("{0}", itemText);

							imgCheckbox.setAttribute('alt', imgText);
							imgCheckbox.setAttribute('title', imgText);
							imgCheckbox = li.appendChild(imgCheckbox);
							$addHandler(imgCheckbox, 'mousedown', this._checkBoxClickHandler);

							if (columnType == "boolean" && column._isCheck)
							{
								if (itemValue)
									itemText = column._checkedAlt.replace("{0}", itemValue);
								else if (itemValue == null)
									itemText = column._partialAlt.replace("{0}", nullText);
								else
									itemText = column._uncheckedAlt.replace("{0}", itemValue);

							}
							var txtNode = document.createTextNode(itemText);
							li.appendChild(txtNode);

						}
						allLi.setAttribute("numChk", checkedItems);
						this.__calculateAllCheckbox(list);
					}

					
					if (this._clientEvents['FilterDropdownDisplaying'])
					{
						// this will be invoked before the dropdown is physically shown on the screen
						curDropDownBehavior.get_Events().addSettingVisibleHandler(this.get_events().getHandler("FilterDropdownDisplaying"));
					}
					if (this._clientEvents['FilterDropdownDisplayed'])
					{
						// this will be invoked after the dropdown container has been shown
						curDropDownBehavior.get_Events().addSetVisibleHandler(this.get_events().getHandler("FilterDropdownDisplayed"));
					}
					if (this._clientEvents['FilterDropdownHiding'])
					{
						// this will be invoked before the dropdown is physically hidden on the screen
						curDropDownBehavior.get_Events().addSettingHiddenHandler(this.get_events().getHandler("FilterDropdownHiding"));
					}
					if (this._clientEvents['FilterDropdownHidden'])
					{
						// this will be invoked after the dropdown container has been hidden
						curDropDownBehavior.get_Events().addSetHiddenHandler(this.get_events().getHandler("FilterDropdownHidden"));
					}

					elmClone = null;
					curDropDownBehavior.init();
				}
			}
		}

	},

	_onCheckBoxClick: function (event)
	{
		
		
		this._ie10FixrememberLastMD(event);
		var checkBox = event.target;
		var chkState = checkBox.getAttribute("chkState");

		if (chkState == '1')
		{
			var val = event.target.parentNode.getAttribute("val");
			this.__setUnchecked(event.target);
			if (event.target.parentNode == event.target.parentNode.parentNode.firstChild) // all checked
				this.__uncheckAll(event.target.parentNode.parentNode);
			else
			{
				var key = event.target.parentNode.parentNode.getAttribute("key");
				
				this.__setCheckedFilters(key, val, event.target.parentNode.getAttribute("isNull"), ($util.IsSafari || $util.IsChrome ? this._grid._gridUtil._convertServerDateStringToClientObject(event.target.parentNode.getAttribute("dVal")) : null));
			}
			$util.cancelEvent(event);
		}
		else if (chkState == '0' || chkState == '2')
		{
			var val = event.target.parentNode.getAttribute("val");
			this.__setChecked(event.target);

			if (event.target.parentNode == event.target.parentNode.parentNode.firstChild) // all unchecked
				this.__checkAll(event.target.parentNode.parentNode);
			else
			{
				var key = event.target.parentNode.parentNode.getAttribute("key");
				
				this.__setUncheckedFilters(key, val, event.target.parentNode.getAttribute("isNull"), ($util.IsSafari || $util.IsChrome ? this._grid._gridUtil._convertServerDateStringToClientObject(event.target.parentNode.getAttribute("dVal")) : null));
			}
			$util.cancelEvent(event);
		}

	},
	__uncheckAll: function (list)
	{
		var items = list.childNodes;
		var key = list.getAttribute("key");
		for (var i = 1; items && i < items.length; i++)
		{
			if (items[i].firstChild.getAttribute("chkState") != "0")
			{
				this.__setUnchecked(items[i].firstChild);
				var val = items[i].getAttribute("val");
				
				this.__setCheckedFilters(key, val, items[i].getAttribute("isNull"), ($util.IsSafari || $util.IsChrome ? this._grid._gridUtil._convertServerDateStringToClientObject(items[i].getAttribute("dVal")) : null));
			}
		}
	},
	__checkAll: function (list)
	{
		var items = list.childNodes;
		var key = list.getAttribute("key");
		for (var i = 1; items && i < items.length; i++)
		{
			if (items[i].firstChild.getAttribute("chkState") != "1")
			{
				this.__setChecked(items[i].firstChild);
				var val = items[i].getAttribute("val");
				
				this.__setUncheckedFilters(key, val, items[i].getAttribute("isNull"), ($util.IsSafari || $util.IsChrome ? this._grid._gridUtil._convertServerDateStringToClientObject(items[i].getAttribute("dVal")) : null));
			}
		}
	},
	__setCheckedFilters: function (key, val, isNull, dVal)
	{
		var column = this._grid.get_columns().get_columnFromKey(key);
		var columnType = column.get_type();
		var filters = this.get_uniqueValuesColumnFiltersFromKey(key);
		var filterFound = false;
		
		if (columnType == "date" && isNull != "1" && ($util.IsChrome || $util.IsSafari))
			val = dVal;
		for (var itr = 0; itr < filters.length; itr++)
		{
			var rule = filters[itr].get_condition().get_rule();
			if ((filters[itr].get_condition().get_value() == val && (columnType != "string" || val != "null" || (columnType == "string" && val == "null" && (isNull == "1" && rule == $IG.TextFilterRules.IsNotNull || isNull == "0" && rule == $IG.TextFilterRules.DoesNotEqual)))
				&& !(columnType == "number" && rule == $IG.NumericFilterRules.IsNotNull))
				|| (val == "null" && isNull == "1" && ((columnType == "boolean" && rule == $IG.BooleanFilterRules.IsNotNull) || (columnType == "date" && rule == $IG.DateTimeFilterRules.IsNotNull) || (columnType == "number" && rule == $IG.NumericFilterRules.IsNotNull) || (columnType == "string" && rule == $IG.TextFilterRules.IsNotNull)))
				|| (columnType == "boolean" && ((val == "false" && rule == $IG.BooleanFilterRules.IsNotFalse) || (val == "true" && rule == $IG.BooleanFilterRules.IsNotTrue)))
				|| (columnType == "date" && val != null && filters[itr].get_condition().get_value() != null && filters[itr].get_condition().get_value().toLocaleString() == val.toLocaleString()))
			{
				filterFound = true;
				break;
			}
		}
		if (!filterFound)
		{
			var columnFilter = columnFilter = this.create_columnFilter(key);
			columnFilter.get_condition().set_value(val);

			switch (columnType)
			{
				case "date":
					if (val == "null")
						columnFilter.get_condition().set_rule($IG.DateTimeFilterRules.IsNotNull);
					else
						columnFilter.get_condition().set_rule($IG.DateTimeFilterRules.DoesNotEqual);
					break;
				case "boolean":
					if (val == "true")
						columnFilter.get_condition().set_rule($IG.BooleanFilterRules.IsNotTrue);
					else if (val == "false")
						columnFilter.get_condition().set_rule($IG.BooleanFilterRules.IsNotFalse);
					else if (val == "null")
						columnFilter.get_condition().set_rule($IG.BooleanFilterRules.IsNotNull);

					break;
				case "number":
					if (val == "null")
						columnFilter.get_condition().set_rule($IG.NumericFilterRules.IsNotNull);
					else
						columnFilter.get_condition().set_rule($IG.NumericFilterRules.DoesNotEqual);
					break;
				case "string":
					if (val == "null" && isNull == "1")
						columnFilter.get_condition().set_rule($IG.TextFilterRules.IsNotNull);
					else
						columnFilter.get_condition().set_rule($IG.TextFilterRules.DoesNotEqual);
					break;
			}
			this.__tmpCheckBoxFilters[this.__tmpCheckBoxFilters.length] = columnFilter;
		}
		else
		{

			var itr = 0;
			while (itr < this.__tmpCheckBoxFiltersToRemove.length)
			{
				if (this.__tmpCheckBoxFiltersToRemove[itr]["columnKey"] == key &&
					(this.__tmpCheckBoxFiltersToRemove[itr]["val"] == val
					|| (columnType == "date" && val != null && this.__tmpCheckBoxFiltersToRemove[itr]["val"] != null && this.__tmpCheckBoxFiltersToRemove[itr]["val"].toLocaleString() == val.toLocaleString())))
				{
					this.__tmpCheckBoxFiltersToRemove.splice(itr, 1);
					break;
				}
				itr++;
			}
		}
	},
	__setUncheckedFilters: function (key, val, isNull, dVal)
	{
		var filters = this.get_uniqueValuesColumnFiltersFromKey(key);
		var column = this._grid.get_columns().get_columnFromKey(key);
		var columnType = column.get_type();
		var filterFound = null;
		
		if (columnType == "date" && isNull != "1" && ($util.IsChrome || $util.IsSafari))
			val = dVal;
		for (var itr = 0; itr < filters.length; itr++)
		{
			var rule = filters[itr].get_condition().get_rule();
			if ((filters[itr].get_condition().get_value() == val && (columnType != "string" || val != "null" || (columnType == "string" && val == "null" && (isNull == "1" && rule == $IG.TextFilterRules.IsNotNull || isNull == "0" && rule == $IG.TextFilterRules.DoesNotEqual)))
			&& !(columnType == "number" && rule == $IG.NumericFilterRules.IsNotNull))
			|| (val == "null" && isNull == "1" && ((columnType == "boolean" && rule == $IG.BooleanFilterRules.IsNotNull) || (columnType == "date" && rule == $IG.DateTimeFilterRules.IsNotNull) || (columnType == "number" && rule == $IG.NumericFilterRules.IsNotNull) || (columnType == "string" && rule == $IG.TextFilterRules.IsNotNull)))
			|| (columnType == "boolean" && ((val == "false" && rule == $IG.BooleanFilterRules.IsNotFalse) || (val == "true" && rule == $IG.BooleanFilterRules.IsNotTrue)))
			|| (columnType == "date" && val != null && filters[itr].get_condition().get_value() != null && filters[itr].get_condition().get_value().toLocaleString() == val.toLocaleString()))
			{
				filterFound = filters[itr];
				break;
			}
		}
		if (!filterFound)
		{
			var itr = 0;
			while (itr < this.__tmpCheckBoxFilters.length)
			{
				if (this.__tmpCheckBoxFilters[itr].get_columnKey() == key)
				{
					var rule = this.__tmpCheckBoxFilters[itr].get_condition().get_rule();
					if ((this.__tmpCheckBoxFilters[itr].get_condition().get_value() == val && (columnType != "string" || val != "null" || (columnType == "string" && val == "null" && (isNull == "1" && rule == $IG.TextFilterRules.IsNotNull || isNull == "0" && rule == $IG.TextFilterRules.DoesNotEqual))))
						|| (val == "null" && isNull == "1" && ((columnType == "boolean" && rule == $IG.BooleanFilterRules.IsNotNull) || (columnType == "date" && rule == $IG.DateTimeFilterRules.IsNotNull) || (columnType == "number" && rule == $IG.NumericFilterRules.IsNotNull) || (columnType == "string" && rule == $IG.TextFilterRules.IsNotNull)))
						|| (columnType == "boolean" && ((val == "false" && rule == $IG.BooleanFilterRules.IsNotFalse) || (val == "true" && rule == $IG.BooleanFilterRules.IsNotTrue)))
						|| (columnType == "date" && val != null && this.__tmpCheckBoxFilters[itr].get_condition().get_value() != null && this.__tmpCheckBoxFilters[itr].get_condition().get_value().toLocaleString() == val.toLocaleString()))
					{
						this.__tmpCheckBoxFilters.splice(itr, 1);
						break;
					}
				}
				itr++;
			}
		}
		if (filterFound)
		{
			// have to remove from server
			this.__tmpCheckBoxFiltersToRemove[this.__tmpCheckBoxFiltersToRemove.length] = { "columnKey": filterFound.get_columnKey(), "val": (val == "null" && isNull == "1" ? null : (columnType == "boolean" ? val : filterFound.get_condition().get_value())), "dVal": (val == "null" && isNull == "1" ? null : (columnType == "date" ? this._grid._gridUtil._convertClientDateToServerString(filterFound.get_condition().get_value()) : "")) };
		}
	},
	__calculateAllCheckbox: function (list)
	{
		var allLi = list.firstChild;
		var chkState = allLi.firstChild.getAttribute("chkState");
		var totalNumItems = parseInt(allLi.getAttribute("totItems"));
		var numCheckedItems = parseInt(allLi.getAttribute("numChk"));

		if (totalNumItems == numCheckedItems && chkState != '1')
		{
			//checked
			this.__setChecked(allLi.firstChild);
		}
		else if (numCheckedItems == 0 && chkState != '0')
		{
			//unchecked
			this.__setUnchecked(allLi.firstChild);
		}
		else if (totalNumItems != numCheckedItems && !(numCheckedItems == 0 && chkState == '0') && chkState != '2')
		{
			//partial
			this.__setPartial(allLi.firstChild);
		}
	},
	__setUnchecked: function (elem)
	{
		var key = elem.parentNode.parentNode.getAttribute("key");
		var column = this._grid.get_columns().get_columnFromKey(key);

		elem.setAttribute('src', this._uncheckedImg);
		var val = elem.parentNode.getAttribute("val");
		var rawTxt = val;
		if (column)
		{
			if (val == null)
			{
				rawTxt = (colSetting ? colSetting._get_clientOnlyValue("fnvs") : this._get_clientOnlyValue("fnvs"));
				var colSetting = this.get_columnSettingFromKey(columnKey);
			}
			var dTxt = elem.parentNode.getAttribute("dTxt");
			rawTxt = dTxt ? dTxt : column._formatValue(rawTxt);
		}
		var imgText = this._uncheckedAlt.replace("{0}", rawTxt);
		elem.setAttribute('alt', imgText);
		elem.setAttribute('title', imgText);
		elem.setAttribute('chkState', '0');

		var allLi = elem.parentNode.parentNode.firstChild;
		if (allLi != elem.parentNode)
		{
			var numCheckedItems = parseInt(allLi.getAttribute("numChk"));
			allLi.setAttribute("numChk", --numCheckedItems);
			this.__calculateAllCheckbox(elem.parentNode.parentNode);
		}
	},
	__setChecked: function (elem)
	{
		var key = elem.parentNode.parentNode.getAttribute("key");
		var column = this._grid.get_columns().get_columnFromKey(key);
		elem.setAttribute('src', this._checkedImg);
		var val = elem.parentNode.getAttribute("val");
		var rawTxt = val;
		if (column)
		{
			if (val == null)
			{
				rawTxt = (colSetting ? colSetting._get_clientOnlyValue("fnvs") : this._get_clientOnlyValue("fnvs"));
				var colSetting = this.get_columnSettingFromKey(columnKey);
			}
			var dTxt = elem.parentNode.getAttribute("dTxt");
			rawTxt = dTxt ? dTxt : column._formatValue(rawTxt);
		}
		var imgText = this._checkedAlt.replace("{0}", rawTxt);
		elem.setAttribute('alt', imgText);
		elem.setAttribute('title', imgText);
		elem.setAttribute('chkState', '1');

		var allLi = elem.parentNode.parentNode.firstChild;
		if (allLi != elem.parentNode)
		{
			var numCheckedItems = parseInt(allLi.getAttribute("numChk"));
			allLi.setAttribute("numChk", ++numCheckedItems);
			this.__calculateAllCheckbox(elem.parentNode.parentNode);
		}
	},

	__setPartial: function (elem)
	{
		elem.setAttribute('src', this._partialImg);
		var val = elem.parentNode.getAttribute("val");
		var imgText = this._partialAlt.replace("{0}", val);
		elem.setAttribute('alt', imgText);
		elem.setAttribute('title', imgText);
		elem.setAttribute('chkState', '2');
	},

	_createRulesSelect: function (labels, values)
	{
		var selectElem = document.createElement("select");
		for (var i = 0; i < labels.length; i++)
		{
			var optionElem = document.createElement("option");
			optionElem.innerHTML = labels[i];
			optionElem.setAttribute("val", values[i]);
			selectElem.appendChild(optionElem);
		}
		return selectElem;
	},
	_enteringEditMode: function (eventArgs)
	{
		if (eventArgs.cell.get_row() === this._row)
		{
			if (this._grid._get_isAjaxCallInProgress())
			{
				eventArgs.customDisplay.cancel = true;
				return;
			}

			var filterSettings = this.get_columnSettingFromKey(eventArgs.cell._column._key);
			if ((filterSettings != null && !filterSettings.get_enabled()) || !this._allowEdit(eventArgs.cell) || eventArgs.cell._column.get_isTemplated())
			{
				eventArgs.customDisplay.cancel = true;
				return;
			}

			
			if (!this._grid._rtl || this._columnFixing)
			{
				
				var left = eventArgs.cell._leftShift = eventArgs.cell._element.childNodes[0].offsetLeft + eventArgs.cell._element.childNodes[0].offsetWidth;
				eventArgs.customDisplay.width = eventArgs.cell._element.offsetWidth - left;
				eventArgs.customDisplay.width = (eventArgs.customDisplay.width < 0) ? 0 : eventArgs.customDisplay.width;
			}
			var extraLeft = 0;
			var extraTop = 0;
			if ((this._grid._hasHeaderLayout || this._grid._hasMultiColumnFooters) && eventArgs.cell._element.parentNode.getAttribute("mkr") == "filterRowRight")
			{
				var cellElem = eventArgs.cell._element.parentNode;
				while (cellElem && cellElem.getAttribute("mkr") != "fxdCapThRight" && cellElem.parentNode)
					cellElem = cellElem.parentNode;
				if (cellElem && cellElem.getAttribute("mkr") == "fxdCapThRight")
				{
					extraLeft = cellElem.offsetLeft;
					extraTop = cellElem.offsetTop;
				}
			}
			if ((this._grid._hasHeaderLayout || this._grid._hasMultiColumnFooters) && eventArgs.cell._element.parentNode.getAttribute("mkr") == "filterRowLeft")
			{
				var cellElem = eventArgs.cell._element.parentNode;
				while (cellElem && cellElem.getAttribute("mkr") != "fxdCapThLeft" && cellElem.parentNode)
					cellElem = cellElem.parentNode;
				if (cellElem && cellElem.getAttribute("mkr") == "fxdCapThLeft")
				{
					extraTop = cellElem.offsetTop;
					
					if (this._rowSelectors && ((this._grid._hasHeaderLayout && this.get_alignment() == $IG.FilteringAlignment.Top) || (this._grid._hasMultiColumnFooters && this.get_alignment() == $IG.FilteringAlignment.Bottom)))
						extraLeft += cellElem.offsetLeft;
				}
			}

			if (!this._grid._rtl || this._columnFixing)
				eventArgs.customDisplay.left = (eventArgs.cell._element.offsetLeft + left) + extraLeft;
			else
				eventArgs.customDisplay.width = eventArgs.cell._element.offsetWidth - eventArgs.cell._element.childNodes[0].offsetWidth;

			eventArgs.customDisplay.height = eventArgs.cell._element.offsetHeight;
			eventArgs.customDisplay.top = eventArgs.cell._element.offsetTop + extraTop;

			this.editFilterButton = eventArgs.cell._element.childNodes[0].cloneNode(true);
			this.editSpan = eventArgs.cell._element.childNodes[1].cloneNode(true);

			

			if (eventArgs.cell._element.getAttribute("val") != null && eventArgs.cell._element.getAttribute("val") != "null")
				eventArgs.customDisplay.text = eventArgs.cell.get_value();
			else
			{
				var txtElem = eventArgs.cell._element.childNodes[1];
				if ($util.IsIE && txtElem.childNodes && txtElem.childNodes.length == 1 && txtElem.childNodes[0].nodeName == "#comment")
					eventArgs.customDisplay.text = "";
				else
					eventArgs.customDisplay.text = $util.htmlUnescapeCharacters(txtElem.innerHTML);
			}

			this._grid._gridUtil._fireEvent(this._grid, "FilterCellEnteringEdit", eventArgs);
		}
	},

	_allowEdit: function (cell)
	{
		var column = cell._column;
		var type = column.get_type();
		var key = column._key;
		var columnFilter = this.get_columnFilterFromKey(key);
		columnFilter = columnFilter ? columnFilter : this._get_clientColumnFilterFromKey(key);

		var rule = (columnFilter ? columnFilter.get_condition().get_rule() : null);

		if (type === "boolean")
			return false;
		else if (type === "date" && columnFilter &&
            !(rule === $IG.DateTimeFilterRules.All ||
            rule === $IG.DateTimeFilterRules.Equals ||
            rule === $IG.DateTimeFilterRules.Before ||
            rule === $IG.DateTimeFilterRules.After))
			return false;
		else if (type === "number" && (rule === $IG.NumericFilterRules.IsNull || rule === $IG.NumericFilterRules.IsNotNull))
			return false;
		else if (type === "string" && (rule === $IG.TextFilterRules.IsNull || rule === $IG.TextFilterRules.IsNotNull))
			return false;

		return true;

	},

	_exitedEditMode: function (eventArgs)
	{
		if (eventArgs.cell.get_row() === this._row && eventArgs.update)
		{
			var value = eventArgs.inputValue;
			var text = eventArgs.cell._element.innerHTML;

			

			if (eventArgs.valueChanged && !(eventArgs.cell._element.childNodes.length == 2 &&
				eventArgs.cell._element.firstChild.tagName == "BUTTON" && eventArgs.cell._element.lastChild.tagName == "SPAN"))
			{
				

				if (text.toLowerCase().indexOf("<button") == 0)
				{
					eventArgs.cell._element.innerHTML = "";
					eventArgs.cell._set_value_internal(value);
				}
				if (eventArgs.cell._element.lastChild)
					eventArgs.cell._element.removeChild(eventArgs.cell._element.lastChild);
				eventArgs.cell._element.appendChild(this.editFilterButton);
				this.editSpan.innerHTML = text;
				eventArgs.cell._element.appendChild(this.editSpan);
				eventArgs.cell._dropDownBehaviour._sourceElement = this.editFilterButton;
			}

			
			var colKey = eventArgs.cell._column._key;
			var columnFilter = this.get_columnFilterFromKey(colKey);
			var saveFilterNeeded = columnFilter ? false : true;

			columnFilter = columnFilter ? columnFilter : this._get_clientColumnFilterFromKey(colKey);

			if (!columnFilter)
			{
				columnFilter = this.create_columnFilter(colKey);
				this._clientColumnFilters[this._clientColumnFilters.length] = columnFilter;
			}
			

			var oldVal = columnFilter.get_condition().get_value();
			if (eventArgs.valueChanged)
				columnFilter.get_condition().set_value(value);
			var newVal = columnFilter.get_condition().get_value();
			var type = eventArgs.cell._column.get_type();
			
			var valueChanged = ((oldVal != newVal) || (typeof (oldVal) != typeof (newVal)));
			
			valueChanged = (type != "date") ? valueChanged : valueChanged && !((oldVal == null || oldVal == this.__defaultDate) && (newVal == "" || newVal == null));
			this.editSpan = null;
			this.editFilterButton = null;
			
			if (type == "date" && !valueChanged && newVal === oldVal && oldVal === null)
				newVal = "";

			






			if ((saveFilterNeeded && valueChanged) ||
				(columnFilter.get_condition().get_rule() != 0 && (newVal !== "" || valueChanged)))
				this._apply_filters(true);

		}

	},


	_apply_filters: function (addClientFilters)
	{
		var columnFilterToAdd = null;
		if (addClientFilters && this._clientColumnFilters && this._clientColumnFilters.length > 0)
			columnFilterToAdd = this._clientColumnFilters;

		var eventArgs = new $IG.CancelApplyFiltersEventArgs(this, this._columnFilters, columnFilterToAdd);
		eventArgs = this._grid._raiseSenderClientEventStart(this, this._clientEvents["DataFiltering"], eventArgs);

		if (!eventArgs.get_cancel())
		{
			var noPost = (eventArgs._props[1] == 2);

			this._grid._actionList.add_transaction(new $IG.FilteringAction("ApplyFilter", this.get_name(), this._grid, columnFilterToAdd, null));
			if (!noPost)
				this._owner._postAction(1);
			else
				this._owner._raiseClientEventEnd(eventArgs);
		}

		if (!this._grid.get_enableClientRendering())
			eventArgs._dispose();
	},
	_onClickHandler: function (evnt)
	{
		if (this._grid._get_isAjaxCallInProgress())
			return;

		if (this.get_cellInEditMode() && this.get_cellInEditMode().get_row() === this._row)
		{
			this.exitEditMode(true);
			return;
		}
		var element;
		var td;

		if ($util.IsSafari && evnt.target.getAttribute("mkr") == "befapp"
			|| evnt.target.getAttribute("mkr") == "aftapp")
		{
			element = evnt.target;
			td = evnt.target.parentNode.parentNode;
		}
		else
		{
			element = evnt.target.firstChild;
			td = evnt.target.parentNode;
		}
		
		this._getParentGridElements();

		if (element && element.nodeName == "IMG" &&
            (element.getAttribute("mkr") == "befapp" || element.getAttribute("mkr") == "aftapp"))
		{
			var cell = this._grid._gridUtil.getCellFromElem(td);
			if (!cell)
			{
				var cellIndex = this._grid._gridUtil.getCellIndexFromElem(td);
				var filterRow = this._row;
				
				var cellAdr = this._grid._gridUtil._getColumnAdrFromVisibleIndex(cellIndex);
				cell = filterRow.get_cell(cellAdr);
			}

			if (cell != null)
			{

				if ($util.IsSafari && this._visibleDropdownCell)
				{
					if (cell != this._visibleDropdownCell)
						this._closeRuleDropdown(this._visibleDropdownCell);
				}

				if (cell._dropDownBehaviour.get_visible())
				{
					this._closeRuleDropdown(cell);
				}
				else
				{
					if (this._visibleDropdownCell && !this._visibleDropdownCell._dropDownBehaviour.get_visible())
						this._visibleDropdownCell = null;

					if (!this._visibleDropdownCell) // this will prevent another filter rule dropdown from being opened if the FilterDropdownHiding event was canceled
					{
						cell._dropDownBehaviour.set_visible(true);
						

						var cancelledOrHidden = cell._dropDownBehaviour.get_enableAnimations() ? !cell._dropDownBehaviour.get_isAnimating() : !cell._dropDownBehaviour.get_visible();
						if (!cancelledOrHidden)
						{
							var columnFilter = this.get_columnFilterFromKey(cell._column._key);
							columnFilter = columnFilter ? columnFilter : this._get_clientColumnFilterFromKey(cell._column._key);
							if (columnFilter)
							{
								var item = this._getRuleElement(columnFilter.get_condition().get_rule(), cell._dropDownBehaviour.get_targetContainer());
								if (item != null)
									item.className = this._ruleDDSelectedItemCss;
							}
							this._currentRuleItem = null;
							


							if ($util.IsFireFox)
								cell._dropDownBehaviour.get_targetContainer().firstChild.firstChild.focus();
							else
								cell._dropDownBehaviour.get_targetContainer().firstChild.focus();
							this._visibleDropdownCell = cell;
						}
					}
				}
			}


		}
		else
		{
			$IG.Filtering.callBaseMethod(this, "_onClickHandler", [evnt]);
		}

	},

	
	_resolvingCellElem: function (args)
	{
		var element = args.elem;
		if (element && element.nodeName == "IMG" &&
            (element.getAttribute("mkr") == "befapp" || element.getAttribute("mkr") == "aftapp"))
		{
			args.elem = element.parentNode;
		}
	},

	


	_onDblclickHandler: function (evnt)
	{
		if (evnt.target.firstChild && evnt.target.firstChild.nodeName == "IMG" &&
            (evnt.target.firstChild.getAttribute("mkr") == "befapp" || evnt.target.firstChild.getAttribute("mkr") == "aftapp"))
			this._onClickHandler(evnt);
		else
			$IG.Filtering.callBaseMethod(this, "_onDblclickHandler", [evnt]);
	},

	_closeRuleDropdown: function (cell, ifVisible)
	{
		
		var ddb = cell ? cell._dropDownBehaviour : null;
		if (!ddb || (ifVisible && !ddb.get_visible()))
			return true;
		ddb.set_visible(false);

		

		var cancelledOrHidden = ddb.get_enableAnimations() ? !ddb.get_isAnimating() : ddb.get_visible();
		if (!cancelledOrHidden)
		{
			
			var item = this._getSelectedRuleElement(ddb.get_targetContainer());
			if (item != null)
				item.className = this._ruleDDItemCss;

			this._visibleDropdownCell = null;

			
			if (this._currentRuleItem && this._currentRuleItem.className)
				this._currentRuleItem.className = this._currentRuleItem.className.replace(" " + this._ruleDDHoverItemCss, "");
		}
		return cancelledOrHidden;
	},

	_getRuleElement: function (rule, dropdownDiv)
	{
		var lu = dropdownDiv.firstChild;
		if (lu && lu.childNodes && lu.childNodes.length > 0)
		{
			for (var i = 0; i < lu.childNodes.length; i++)
			{
				if (lu.childNodes[i].getAttribute("val") == rule)
				{
					return lu.childNodes[i];
				}
			}
		}
		return null;
	},
	_getSelectedRuleElement: function (dropdownDiv)
	{
		var lu = dropdownDiv.firstChild;
		if (lu && lu.childNodes && lu.childNodes.length > 0)
		{
			for (var i = 0; i < lu.childNodes.length; i++)
			{
				if (lu.childNodes[i].className == this._ruleDDSelectedItemCss)
				{
					return lu.childNodes[i];
				}
			}
		}
		return null;
	},

	_onSelectRule: function (evnt, touch)
	{
		
		
		this._ie10FixrememberLastMD(evnt);
		
		if (!this._visibleDropdownCell || (!touch && evnt.button != 0 && evnt.keyCode != Sys.UI.Key.enter))
			return;

		var rule = parseInt(evnt.target.getAttribute("val"));
		var column = this._visibleDropdownCell._column;
		var key = column._key;
		var type = column.get_type();
		var columnFilter = this.get_columnFilterFromKey(key);
		columnFilter = columnFilter ? columnFilter : this._get_clientColumnFilterFromKey(key);

		if (!columnFilter)
		{
			columnFilter = this.create_columnFilter(key);
			this._clientColumnFilters[this._clientColumnFilters.length] = columnFilter;
		}
		var oldRule = columnFilter.get_condition().get_rule();
		columnFilter.get_condition().set_rule(rule);

		if (type != "boolean" && rule == 0) // ALL or Clear Filter rule is being applied so we have to clear the value
			columnFilter.get_condition().set_value("");
		
		if (type == "number" && columnFilter.get_condition().get_rule() >= $IG.NumericFilterRules.IsNull)
			columnFilter.get_condition().set_value("");

		var allowEdit = this._allowEdit(this._visibleDropdownCell);
		if ((type == "boolean" && oldRule != rule) || (!allowEdit && oldRule != rule) || (rule == 0 && oldRule != rule))
		{
			if (!this._closeRuleDropdown(this._visibleDropdownCell)) // if the dropdown hiding was not canceled then filter
			{
				this._apply_filters(true);
			}
		}
		else if (allowEdit)
		{
			var cell = this._visibleDropdownCell;
			if (!this._closeRuleDropdown(this._visibleDropdownCell) && rule != 0)
			{
				this.enterEditMode(cell);
			}
			else
			{
				if (this._grid.get_enableClientRendering())
					this._apply_filters(true);
			}
		}

		if (this._grid.get_enableClientRendering())
			if ((type == "boolean") && (rule == 0))
				this._apply_filters(true);
	},

	_get_clientColumnFilterFromKey: function (columnKey)
	{
		/// <returns type="ColumnFilter">The column filter tied to the specified column key</returns>
		for (var i = 0; i < this._clientColumnFilters.length; i++)
		{
			if (this._clientColumnFilters[i].get_columnKey() === columnKey)
				return this._clientColumnFilters[i];
		}

		return null;

	},

	_onMouseOverRule: function (evnt)
	{
		if (evnt.target.tagName === "LI")
		{
			
			if (this._currentRuleItem && this._currentRuleItem.className)
				this._currentRuleItem.className = this._currentRuleItem.className.replace(" " + this._ruleDDHoverItemCss, "");

			// add the hover class to the item
			evnt.target.className = evnt.target.className + " " + this._ruleDDHoverItemCss;
			this._currentRuleItem = evnt.target;
		}
	},

	_onMouseOutRule: function (evnt)
	{
		if (evnt.target.tagName === "LI")
		{
			
			evnt.target.className = evnt.target.className.replace(" " + this._ruleDDHoverItemCss, "");
			
			if (this._currentRuleItem && this._currentRuleItem != evnt.target)
				this._currentRuleItem.className = this._currentRuleItem.className.replace(" " + this._ruleDDHoverItemCss, "");
			this._currentRuleItem = null;
		}
	},

	_onTouchStartRule: function (evnt)
	{
		
		if (evnt.rawEvent && evnt.rawEvent.pointerType && evnt.rawEvent.pointerType == evnt.rawEvent.MSPOINTER_TYPE_MOUSE)
			return;
		if (evnt.rawEvent && evnt.rawEvent.pointerType == evnt.rawEvent.MSPOINTER_TYPE_TOUCH)
		{
			$util.cancelEvent(evnt);
			if (evnt.rawEvent.preventManipulation)
				evnt.rawEvent.preventManipulation();
		}
		this._touchedTarget = evnt.target;
		this._lastTouchCoords = $util._getTouchCoords(evnt.rawEvent ? evnt.rawEvent : evnt);
	},
	_onTouchMoveRule: function (evnt)
	{
		if (!this._lastTouchCoords)
			return;
		var touchCoords = $util._getTouchCoords(evnt.rawEvent ? evnt.rawEvent : evnt);
		var touchDeltaX = touchCoords.x - this._lastTouchCoords.x;
		var touchDeltaY = touchCoords.y - this._lastTouchCoords.y;
		this._lastTouchCoords = touchCoords;
		var div = evnt.target;
		while (div.tagName != "DIV" && div.parentNode)
			div = div.parentNode;
		if (div.tagName != "DIV")
			return;
		div.scrollTop = div.scrollTop - touchDeltaY < 0 ? 0 : div.scrollTop - touchDeltaY;
		if (div.scrollTop > div.scrollHeight)
			div.scrollTop = div.scrollHeight;
		$util.cancelEvent(evnt);
		if (evnt.rawEvent && evnt.rawEvent.pointerType == evnt.rawEvent.MSPOINTER_TYPE_TOUCH)
		{
			if (evnt.rawEvent.preventManipulation)
				evnt.rawEvent.preventManipulation();
		}
	},
	_onTouchEndRule: function (evnt)
	{
		if (this._lastTouchCoords && this._touchedTarget == evnt.target)
			this._onSelectRule(evnt, true);
	},
	
	
	_ie10FixrememberLastMD: function (evnt)
	{
		
		// for scrollbar IE10 raises mouseup event for wrong target: HTML instead of element under mouse
		// it also does not wait for user to release mouse, but fires fantom mouseup straight after mousedown (impressive feature)
		// memorize target element in order to use it for mouseup	    
		this._lastMD = { target: evnt ? evnt.target : null, time: new Date().getTime() };
	},
	_onMouseDown: function (evnt)
	{
		
		// for scrollbar IE10 raises mouseup event for wrong target: HTML instead of element under mouse
		// it also does not wait for user to release mouse, but fires fantom mouseup straight after mousedown (impressive feature)
		// memorize target element in order to use it for mouseup
		//this._lastMD = { target: evnt ? evnt.target : null, time: new Date().getTime() };  
		
		
		this._ie10FixrememberLastMD(evnt);
		this._closeDropdownOnscroll(evnt);
	},

	_onMouseUp: function (evnt)
	{
		
		var md = this._lastMD;
		delete this._lastMD;
		// use same target as for mousedown
		// assume that end user will not move mouse too far within 200ms between mouse down/up
		
		// for double/triple click on scrollbar, IE10 may raise mouseup with large delay (wait for animated scroll to finish?!) which can take 400..500ms or larger
		// so, increase delay from 200 to 600ms
		this._closeDropdownOnscroll(evnt, md && new Date().getTime() - md.time < 600 ? md.target : null);
	},

	_onGridResize: function (evnt)
	{
		
		this._closeRuleDropdown(this._visibleDropdownCell, 1);
	},

	_onKeyDown: function (evnt)
	{
		if ((this._visibleDropdownCell != null) && (evnt.keyCode == Sys.UI.Key.left || evnt.keyCode == Sys.UI.Key.right ||
            evnt.keyCode == Sys.UI.Key.up || evnt.keyCode == Sys.UI.Key.down || evnt.keyCode == Sys.UI.Key.pageUp
            || evnt.keyCode == Sys.UI.Key.pageDown))
		{
			this._closeRuleDropdown(this._visibleDropdownCell);
		}
	},

	_onFilterKeyDown: function (evnt)
	{
		if (this._activation)
		{
			var activeCell = this._activation.get_activeCell();
			if (activeCell && activeCell.get_row() == this._row)
			{
				if (evnt.target.nodeName != "BUTTON" && evnt.keyCode == Sys.UI.Key.tab)
				{
					if (!evnt.shiftKey)
					{
						

						try
						{
							activeCell._element.childNodes[0].focus();
							$util.cancelEvent(evnt);
							if ($util.IsOpera)
								this._OperaCancelEvent = true;
						}
						catch (e) { }
					}
					else
					{
						var prevCell = this._grid._gridUtil.getPrevCell(activeCell);

						if (prevCell && prevCell.get_row() === this._row)
						{
							this._activation.set_activeCell(prevCell, false);

							

							try
							{
								prevCell._element.childNodes[0].focus();
								$util.cancelEvent(evnt);
								if ($util.IsOpera)
									this._OperaCancelEvent = true;
							}
							catch (e) { }
						}

					}
				}
				else if (evnt.target.nodeName == "BUTTON")
				{
					if (evnt.keyCode == Sys.UI.Key.enter)
					{
						this._onClickHandler(evnt);
						$util.cancelEvent(evnt);
						if ($util.IsOpera)
							this._OperaCancelEvent = true;
					}
					else if (evnt.keyCode == Sys.UI.Key.tab && evnt.shiftKey)
					{
						if ($util.IsIE || $util.IsOpera)
							this._grid._gridUtil.scrollCellIntoViewIE(activeCell);
						else
							activeCell._element.focus();
						$util.cancelEvent(evnt);
						if ($util.IsOpera)
							this._OperaCancelEvent = true;
					}
				}
			}
		}

	},

	_onKeyDownRule: function (evnt)
	{
		var items = evnt.target.tagName == "LI" ? evnt.target.parentNode : evnt.target;
		if (evnt.keyCode == Sys.UI.Key.up)
		{
			var nextItem = (!this._currentRuleItem) ? items.firstChild : this._currentRuleItem.previousSibling;

			if (!nextItem)
				nextItem = items.lastChild;

			
			if (this._currentRuleItem && this._currentRuleItem.className)
				this._currentRuleItem.className = this._currentRuleItem.className.replace(" " + this._ruleDDHoverItemCss, "");

			nextItem.focus();
			nextItem.className = nextItem.className + " " + this._ruleDDHoverItemCss;

			this._currentRuleItem = nextItem;
			$util.cancelEvent(evnt);
			if ($util.IsOpera)
				this._OperaCancelEvent = true;
		}
		else if (evnt.keyCode == Sys.UI.Key.down)
		{
			var nextItem = (!this._currentRuleItem) ? items.firstChild : this._currentRuleItem.nextSibling;

			if (!nextItem)
				nextItem = items.firstChild;

			
			if (this._currentRuleItem && this._currentRuleItem.className)
				this._currentRuleItem.className = this._currentRuleItem.className.replace(" " + this._ruleDDHoverItemCss, "");

			nextItem.focus();
			nextItem.className = nextItem.className + " " + this._ruleDDHoverItemCss;

			this._currentRuleItem = nextItem;
			$util.cancelEvent(evnt);
			if ($util.IsOpera)
				this._OperaCancelEvent = true;
		}
		else if (evnt.keyCode == Sys.UI.Key.enter)
		{
			$util.cancelEvent(evnt);
			if ($util.IsOpera)
				this._OperaCancelEvent = true;

			if (this._currentRuleItem)
			{
				evnt.target = this._currentRuleItem;
				this._onSelectRule(evnt);
			}
			else
			{
				var button = this._visibleDropdownCell._element.firstChild;
				this._closeRuleDropdown(this._visibleDropdownCell);
				button.focus();
			}

		}
		else if (evnt.keyCode == Sys.UI.Key.esc)
		{
			$util.cancelEvent(evnt);
			if ($util.IsOpera)
				this._OperaCancelEvent = true;

			var button = this._visibleDropdownCell._element.firstChild;
			this._closeRuleDropdown(this._visibleDropdownCell);
			button.focus();
		}

	},

	_onKeyPressRule: function (evnt)
	{
		
		if (this._OperaCancelEvent)
		{
			$util.cancelEvent(evnt);
			this._OperaCancelEvent = false;
		}
	},

	_onMousewheel: function (evnt)
	{
		


		var needToClose = true;
		if (evnt.target)
		{
			var elem = evnt.target;
			if (elem.tagName == "LI")
				elem = elem.parentNode.parentNode;
			else if (elem.tagName == "UL")
				elem = elem.parentNode;

			if (this._visibleDropdownCell != null && this._visibleDropdownCell._dropDownBehaviour.get_targetContainer() == elem)
				needToClose = false;
		}
		if (needToClose)
			this._closeDropdownOnscroll(evnt);
	},

	_onColumnResize: function (evnt)
	{
		
		this._closeRuleDropdown(this._visibleDropdownCell);
	},

	
	// target: custom/faked target, same as it was in mousedown
	_closeDropdownOnscroll: function (evnt, target)
	{
		target = target || (evnt ? evnt.target : null);
		if (this._visibleDropdownCell != null)
		{
			
			
			var btn = target;
			if (btn && btn.nodeName == "IMG" && (btn.getAttribute("mkr") == "befapp" || btn.getAttribute("mkr") == "aftapp"))
				btn = btn.parentNode;
			if (target != this._visibleDropdownCell._dropDownBehaviour.get_targetContainer()
	            && btn != this._visibleDropdownCell._dropDownBehaviour.get_sourceElement())
				if (this._visibleDropdownCell._dropDownBehaviour.get_visible())
				{
					


					this._closeRuleDropdown(this._visibleDropdownCell);
					return false;
				}
		}
		else if (this._filterType != $IG.FilteringType.RowFilter && this._columnDroppedDown && this._columnDroppedDown._filterDropDownBehaviour.get_visible())
		{
			var isFilterImg = (target && target.tagName == "IMG" && target.parentNode && target.parentNode.parentNode && target.parentNode.parentNode.id.indexOf("filterDropDiv") > -1);
			var isFilterDiv = (target && target.tagName == "DIV" && target.parentNode && target.parentNode.id.indexOf("filterDropDiv") > -1);
			var isFilterBtns = (target && target.tagName == "INPUT" && target.parentNode && target.parentNode.id.indexOf("filterDropDiv") > -1);
			var filterUL = (target && target.tagName == "LI" ? target.parentNode : (target && target.parentNode ? target.parentNode.parentNode : null));
			if (target && target.tagName == "UL")
				filterUL = target;
			var isFilterUL = (filterUL && filterUL.tagName == "UL" && filterUL.parentNode && filterUL.parentNode.parentNode && filterUL.parentNode.parentNode.id.indexOf("filterDropDiv") > -1);
			
			var sourceElement = this._columnDroppedDown._filterDropDownBehaviour.get_sourceElement();
			var isFilterHeaderBtn = (sourceElement == target || (sourceElement && target && target.parentNode == sourceElement.parentNode) || (sourceElement && target && target.parentNode && target.parentNode.parentNode == sourceElement.parentNode)) ? true : false;

			if (target != this._columnDroppedDown._filterDropDownBehaviour.get_targetContainer() && !isFilterHeaderBtn && !isFilterUL && !isFilterBtns && !isFilterDiv && !isFilterImg)
				this._onCancelBtnClick();
		}
	},

	_onActiveCellChanging: function (evnt)
	{
		if (evnt.activeCell && evnt.cell)
		{
			var newRow = evnt.cell.get_row();
			if (newRow === this._row && evnt.keyCode == Sys.UI.Key.tab
			&& this._row !== evnt.activeCell.get_row() && evnt.cell === this._grid._gridUtil.getPrevCell(evnt.activeCell))
				this.focusOnBtn = true;
		}
	},

	_onActiveCellChanged: function (evnt)
	{
		if (this._visibleDropdownCell != null)
			this._closeDropdownOnscroll(evnt);
		else if (this.focusOnBtn)
		{
			this.focusOnBtn = false;
			

			try
			{
				evnt.cell._element.childNodes[0].focus();
			}
			catch (e) { }
		}
	},

	_onSelectstartHandler: function (evnt)
	{
		
		var currentElement = evnt.target;
		
		while (currentElement != null && (currentElement.mkr != "filterRow" && currentElement.mkr != "filterRowLeft" && currentElement.mkr != "filterRowRight"))
			currentElement = currentElement.parentNode;

		if (currentElement != null && (currentElement.mkr == "filterRow" || currentElement.mkr == "filterRowLeft" || currentElement.mkr == "filterRowRight"))
			$util.cancelEvent(evnt);
	},

	_initializeComplete: function ()
	{
		if (this._filterType == $IG.FilteringType.RowFilter)
			this._container = this._row._element;

		$IG.Filtering.callBaseMethod(this, "_initializeComplete");

		if (this._filterType == $IG.FilteringType.RowFilter)
		{
			
			var cellCount = this._row.get_cellCount();
			var offset = this._grid._get_cellIndexOffset();
			for (var x = 0; x < cellCount; ++x)
			{
				var cellEl = this._row._get_cellElementByIndex(this._row._element, x + offset);
				var btn = cellEl ? cellEl.firstChild : null;
				if (btn && btn.tagName == "BUTTON")
					btn.tabIndex = -1;
			}
		}

		this._addEnteringEditEventListener(Function.createDelegate(this, this._enteringEditMode));
		this._addExitedEditEventListener(Function.createDelegate(this, this._exitedEditMode));

		if (this._filterType == $IG.FilteringType.RowFilter)
			this._grid._registerAuxRow(this._row, (this.get_alignment() == $IG.FilteringAlignment.Top ? $IG.GridAuxRows.Top : $IG.GridAuxRows.Bottom))

		this._columnFixing = this._grid.get_behaviors().get_columnFixing();
		this._activation = this._grid.get_behaviors().get_activation();
		if (this._activation)
		{
			this._activation._addActiveCellChangingEventHandler(Function.createDelegate(this, this._onActiveCellChanging));
			this._activation._addActiveCellChangedEventHandler(Function.createDelegate(this, this._onActiveCellChanged));
		}

		this._columnResizing = this._grid.get_behaviors().get_columnResizing();
		if (this._columnResizing)
		{
			this._columnResizing._addStartColumnResizingEventListener(Function.createDelegate(this, this._onColumnResize));
		}
		this._rowSelectors = this._grid.get_behaviors().get_rowSelectors();
		if (this._rowSelectors && this._filterType == $IG.FilteringType.RowFilter)
			this._rowSelectors.addSelectorImage(this._row, this._get_clientOnlyValue("frsic"));

		
		
		var addedFilterKeys = this._get_clientOnlyValue("ack");
		if (addedFilterKeys && this._clientEvents["ColumnFilterAdded"])
		{
			var columnKeys = Sys.Serialization.JavaScriptSerializer.deserialize(addedFilterKeys);
			for (var i = 0; i < columnKeys.length; i++)
			{
				var columnFilter = this.get_columnFilterFromKey(columnKeys[i]);
				this._grid._raiseSenderClientEvent(this, this._clientEvents['ColumnFilterAdded'], new $IG.ColumnFilterAddedArgs(columnFilter));
			}
		}

		
		if (this.get_filtered())
		{

			if ($util.IsIE8 && this._hierarchical)
				this._grid._forceParentResize = true;
			if (this._clientEvents["DataFiltered"])
				this._grid._raiseSenderClientEvent(this, this._clientEvents['DataFiltered'], new $IG.DataFilteredArgs(this.get_columnFilters()));
		}

	},

	_get_editContainer: function ()
	{
		if (this._filterType != $IG.FilteringType.RowFilter)
			return null;
		return this._row._element;
	},

	_get_totalRowCount: function ()
	{
		



		return this._get_clientOnlyValue("ftrowcnt");
	},

	
	_getParentGridElements: function ()
	{
		if (this._initializedParentGrids || !this._hierarchical)
			return;
		this._initializedParentGrids = true;
		if (this._ancestorGridElements == null)
			this._ancestorGridElements = [];
		var parentRow = this._grid.get_parentRow();
		while (parentRow != null)
		{
			var grid = parentRow.get_grid();
			this._ancestorGridElements[this._ancestorGridElements.length] = grid._elements["container"];
			$addHandler(grid._elements["container"], "scroll", this._onMousewheelHandler);
			parentRow = grid.get_parentRow();
		}
	}

}
$IG.Filtering.registerClass('Infragistics.Web.UI.Filtering', $IG.GridEditBase);




$IG.FilterRow = function (adr, element, props, owner, csm, filteringBehavior)
{
	///<summary locid="T:J#Infragistics.Web.UI.FilterRow">
	///Override of the GridRow object. Adds functionality for the filter row off the grid.
	///</summary>
	/// <param name="adr" type="Number">The row index at which the HTML element of the row appears.</param>
	/// <param name="element" domElement="true">The html element of the row.</param>
	/// <param name="props" type="Array">An array of objects which are the values for the internal members of the class.</param>
	/// <param name="owner" type="Infragistics.Web.UI.GridRowCollection" mayBeNull="true">The rows collection to which the row belongs.</param>
	/// <param name="csm" type="Infragistics.Web.UI.ObjectClientStateManager">The clientStateManager for the object.</param>
	/// <param name="filteringBehavior" type="Infragistics.Web.UI.Filtering">The filtering behavior that the row belongs to.</param>

	$IG.FilterRow.initializeBase(this, [adr, element, props, owner, csm]);
	this._filteringBehavior = filteringBehavior;

}

$IG.FilterRow.prototype =
{
	

	_create_item: function (adr, index)
	{
		var cell = $IG.FilterRow.callBaseMethod(this, '_create_item', [adr, index]);
		var filterSettings = this._filteringBehavior.get_columnSettingFromKey(cell._column._key);
		
		if ((filterSettings == null || filterSettings.get_enabled()) && !cell._column.get_isTemplated() && cell._column.get_dataType() != 15)
		{
			cell.__set_overrideCellUpdate(true);
			cell.__set_alwaysSetText(true);
			var btn = cell.get_element().childNodes[0];
			cell._dropDownBehaviour = new $IG.DropDownBehavior(btn, false);

			
			this._filteringBehavior._dropDownBehaviors[this._filteringBehavior._dropDownBehaviorsCount++] = cell._dropDownBehaviour;

			var columnType = cell._column.get_type();
			var elmClone;
			if (columnType == "number")
				elmClone = $get(cell._owner._id + "_NumericRuleDropDown").cloneNode(true);
			else if (columnType == "date")
				elmClone = $get(cell._owner._id + "_DateTimeRuleDropDown").cloneNode(true);
			else if (columnType == "boolean")
			{
				elmClone = $get(cell._owner._id + "_BooleanRuleDropDown").cloneNode(true);
				if (cell._column._isCheck)
				{					
					var trueOption = elmClone.firstChild.firstChild.nextSibling;
					var falseOption = trueOption.nextSibling;
					var partialOption = falseOption.nextSibling;
					trueOption.innerHTML = cell._column._checkedAlt.replace("{0}", trueOption.innerHTML);
					falseOption.innerHTML = cell._column._uncheckedAlt.replace("{0}", falseOption.innerHTML);
					partialOption.innerHTML = cell._column._partialAlt.replace("{0}", "Null");
				}
			}
			else
				elmClone = $get(cell._owner._id + "_TextRuleDropDown").cloneNode(true);
			elmClone.id = elmClone.id + "_" + cell._column._key;

			
			
			if (!$util.IsIE || $util.IsIE9Plus || !elmClone.firstChild._events)
			{
				
				$addHandler(elmClone.firstChild, 'mousedown', this._filteringBehavior._onSelectRuleHandler);
				$addHandler(elmClone.firstChild, 'mouseover', this._filteringBehavior._onMouseOverRuleHandler);
				$addHandler(elmClone.firstChild, 'mouseout', this._filteringBehavior._onMouseOutRuleHandler);
				$addHandler(elmClone, 'keydown', this._filteringBehavior._onKeyDownRuleHandler);
				if (window.navigator.msPointerEnabled)
				{
					$addHandler(elmClone, "MSPointerDown", this._filteringBehavior._onTouchStartRuleHandler);
					$addHandler(elmClone, "MSPointerMove", this._filteringBehavior._onTouchMoveRuleHandler);
					$addHandler(elmClone, "MSPointerUp", this._filteringBehavior._onTouchEndRuleHandler);
					elmClone.style.msTouchAction = "none";
				}
				else
				{
					$addHandler(elmClone, 'touchstart', this._filteringBehavior._onTouchStartRuleHandler);
					$addHandler(elmClone, 'touchmove', this._filteringBehavior._onTouchMoveRuleHandler);
					$addHandler(elmClone, 'touchend', this._filteringBehavior._onTouchEndRuleHandler);
				}
			}
			cell._dropDownBehaviour.set_targetContainer(elmClone);
			cell._dropDownBehaviour.set_zIndex(this._filteringBehavior.get_filterRuleDropdownZIndex());
			cell._dropDownBehaviour.set_animationDurationMs(this._filteringBehavior.get_animationDurationMs());
			cell._dropDownBehaviour.set_enableAnimations(this._filteringBehavior.get_animationEnabled());
			cell._dropDownBehaviour.set_animationType(this._filteringBehavior.get_animationType());

			cell._dropDownBehaviour.set_visibleOnBlur(false);

			if (this._filteringBehavior.get_alignment() == $IG.FilteringAlignment.Top)
				cell._dropDownBehaviour.set_position($IG.DropDownPopupPosition.Default);
			else
				cell._dropDownBehaviour.set_position($IG.DropDownPopupPosition.TopLeft);

			
			if (this._filteringBehavior._clientEvents['FilterDropdownDisplaying'])
			{
				// this will be invoked before the dropdown is physically shown on the screen
				cell._dropDownBehaviour.get_Events().addSettingVisibleHandler(this._filteringBehavior.get_events().getHandler("FilterDropdownDisplaying"));
			}
			if (this._filteringBehavior._clientEvents['FilterDropdownDisplayed'])
			{
				// this will be invoked after the dropdown container has been shown
				cell._dropDownBehaviour.get_Events().addSetVisibleHandler(this._filteringBehavior.get_events().getHandler("FilterDropdownDisplayed"));
			}
			if (this._filteringBehavior._clientEvents['FilterDropdownHiding'])
			{
				// this will be invoked before the dropdown is physically hidden on the screen
				cell._dropDownBehaviour.get_Events().addSettingHiddenHandler(this._filteringBehavior.get_events().getHandler("FilterDropdownHiding"));
			}
			if (this._filteringBehavior._clientEvents['FilterDropdownHidden'])
			{
				// this will be invoked after the dropdown container has been hidden
				cell._dropDownBehaviour.get_Events().addSetHiddenHandler(this._filteringBehavior.get_events().getHandler("FilterDropdownHidden"));
			}

			elmClone = null;
			cell._dropDownBehaviour.init();
		}

		return cell;
	},

	dispose: function ()
	{
		///<summary locid="M:J#Infragistics.Web.UI.FilterRow.dispose">
		/// Disposes of the object.
		///</summary>
		for (var i = 0; i < this._cells.length; i++)
		{
			if (this._cells[i] && this._cells[i]._dropDownBehaviour)
			{
				this._cells[i]._dropDownBehaviour = null;
				this._cells[i].dispose();
			}
		}
		this._filteringBehavior = null;
		$IG.FilterRow.callBaseMethod(this, "dispose");
	}

}

$IG.FilterRow.registerClass('Infragistics.Web.UI.FilterRow', $IG.GridRow);


$IG.ColumnFilterSettings = function (adr, element, props, owner, csm)
{
	/// <summary locid="T:J#Infragistics.Web.UI.ColumnFilterSettings">
	/// Object that defines a column filter setting for the grid column.
	/// </summary>
	/// <param name="adr" type="Number">The index of the object in the collection.</param>
	/// <param name="element" domElement="true">The html element of the object.</param>
	/// <param name="props" type="Array">An array of objects which are the values for the internal members of the class.</param>
	/// <param name="owner" type="Infragistics.Web.UI.ObjectCollection">The collection to which the setting belongs.</param>
	/// <param name="csm" type="Infragistics.Web.UI.ObjectClientStateManager">The clientStateManager for the object.</param>
	$IG.ColumnFilterSettings.initializeBase(this, [adr, element, props, owner, csm]);
}

$IG.ColumnFilterSettings.prototype =
{
	get_enabled: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ColumnFilterSettings.enabled">
		/// Indicates whether filtering is enabled on the particular column.
		/// </summary>
		/// <value type="Boolean">True if filtering is enabled for the column, false otherwise</value>
		return this._get_clientOnlyValue("fse");
	},
	get_uniqueValueCasing: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.Filtering.uniqueValueCasing">
		/// Indicates how the text of the unique value is displayed if filter type is RowFilter and filtering is not case sensitive for a particular column.
		/// </summary>
		/// <value type="Infragistics.Web.UI.UniqueValueCasing">Location of the filter row</value>    
		return this._get_clientOnlyValue("cfuvc");
	}
}
$IG.ColumnFilterSettings.registerClass('Infragistics.Web.UI.ColumnFilterSettings', $IG.ColumnEditableSetting);




$IG.ColumnFilter = function (obj, element, props, control)
{
	/// <summary locid="T:J#Infragistics.Web.UI.ColumnFilter">
	/// Object that defines a column filter for the grid column.
	/// </summary>
	/// <param name="obj" type="String">The object type.</param>
	/// <param name="element" domElement="true" mayBeNull="true">The html element of the object.</param>
	/// <param name="props" type="Array">An array of objects which are the values for the internal members of the class.</param>
	/// <param name="control" type="Infragistics.Web.UI.Filtering">The filtering behavior to which the column filter belongs.</param>

	var csm = new $IG.ObjectClientStateManager(props[0]);
	$IG.ColumnFilter.initializeBase(this, [obj, element, props, control, csm]); //(this, [adr, element, props, owner, csm]); 

}

$IG.ColumnFilter.prototype =
{
	get_columnKey: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ColumnFilter.columnKey">
		/// Gets the key of the column that the column filter is tied to.
		/// </summary>
		/// <value type="String">Column key</value>
		return this._get_clientOnlyValue("cfk");
	},

	get_columnType: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ColumnFilter.columnType">
		/// Gets the data type of the grid column that the column filter is tied to.		
		/// </summary>
		/// <value type="String">Column type could be one of the following: date, boolean, number or string </value>
		return this._get_clientOnlyValue("cft");
	},

	get_condition: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ColumnFilter.condition">
		/// Rule and value based filtering condition that will apply to the ControlDataField which 
		/// the ColumnFilter is tied to.		
		/// </summary>
		/// <value type="Infragistics.Web.UI.FilteringNodeObject">Filtering condition</value>

		if (this._condition == null)
		{
			this._condition = new $IG.FilteringNodeObject("FilteringNodeObject", this._element, this._objectManager.get_objectProps(0), this);
			this._objectManager.register_object(0, this._condition);
		}
		return this._condition;
	},

	_createObjects: function (objectManager)
	{
		this._objectManager = objectManager;
	},

	dispose: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ColumnFilter.dispose">
		/// Disposes of the object.
		/// </summary>

		this._objectManager = null;
		$IG.ColumnFilter.callBaseMethod(this, "dispose");
	}

}
$IG.ColumnFilter.registerClass('Infragistics.Web.UI.ColumnFilter', $IG.ObjectBase);




$IG.FilteringNodeObject = function (obj, element, props, control)
{
	/// <summary locid="T:J#Infragistics.Web.UI.FilteringNodeObject">
	/// Object that defines rule and value based filtering condition.
	/// </summary>
	/// <param name="obj" type="String">The object type.</param>
	/// <param name="element" domElement="true" mayBeNull="true">The html element of the object.</param>
	/// <param name="props" type="Array">An array of objects which are the values for the internal members of the class.</param>
	/// <param name="control" type="Infragistics.Web.UI.ColumnFilter">The column filter to which the object belongs.</param>

	var csm = new $IG.ObjectClientStateManager(props[0]);
	$IG.FilteringNodeObject.initializeBase(this, [obj, element, props, control, csm]);
	this._columnFilter = this._owner;
	this._gridFiltering = this._columnFilter._owner;
	this._grid = this._gridFiltering._owner;

}
$IG.FilteringNodeObject.prototype =
{
	get_rule: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.FilteringNodeObject.rule">
		/// Gets the filter condition rule. The return type will be one of the following, based on the column type: 
		/// TextFilterRules, NumericFilterRules, DateTimeFilterRules, or BooleanFilterRules
		/// </summary>
		/// <value>The return type will be one of the following, based on the column type: 
		/// TextFilterRules, NumericFilterRules, DateTimeFilterRules, or BooleanFilterRules
		/// </value>

		return this._get_value($IG.FilteringNodeObjectProps.Rule);
	},

	set_rule: function (rule)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.FilteringNodeObject.rule">
		/// Sets the filter condition rule.
		/// </summary>
		/// <param name="rule" optional="false" mayBeNull="false">
		/// The type of the rule will be one of the following, based on the column type:
		/// Infragistics.Web.UI.TextFilterRules, Infragistics.Web.UI.NumericFilterRules,
		/// Infragistics.Web.UI.DateTimeFilterRules, or Infragistics.Web.UI.BooleanFilterRules
		/// </param> 

		this._set_value($IG.FilteringNodeObjectProps.Rule, rule);

		
		var cell = this._get_filterCell();
		var ruleElm = this._gridFiltering._getRuleElement(rule, cell._dropDownBehaviour._targetContainer);
		if (ruleElm != null)
		{
			cell.get_element().childNodes[0].childNodes[0].alt = ruleElm.innerHTML;
			cell.get_element().childNodes[0].childNodes[0].title = ruleElm.innerHTML;
			cell.get_element().childNodes[0].title = ruleElm.innerHTML;
		}
	},

	get_value: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.FilteringNodeObject.value">
		/// Gets the filter condition value. The return type will be one of the following, based on the column type: 
		/// String, Number, Date, or Bool
		/// </summary>
		/// <value>The return type will be one of the following, based on the column type: 
		/// String, Number, Date, or Bool
		/// </value>
		var columnType = this._columnFilter.get_columnType();
		var value = this._get_value($IG.FilteringNodeObjectProps.Value);

		if (columnType == "date")
			value = this._grid._gridUtil._convertServerDateStringToClientObject(value);
		return value;
	},

	set_value: function (value)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.FilteringNodeObject.value">
		/// Sets the filter condition value.
		/// </summary>
		/// <param name="value" optional="false" mayBeNull="false">
		/// The type of the value will be one of the following, based on the column type: 
		/// String, Number, Date
		/// </param>
		var columnType = this._columnFilter.get_columnType();
		if (columnType == "boolean")
			return;

		var column = this._grid.get_columns().get_columnFromKey(this._columnFilter.get_columnKey());
		var cell = this._get_filterCell();
		var valueToSave = cell.__parseValue(value);
		var text = column._formatValue(valueToSave);

		if (columnType == "number")
		{
			var parsedValue = parseFloat(value);
			if (isNaN(parsedValue))
			{
				valueToSave = "";
				text = "";
			}
		}
		else if (columnType == "date")
		{
			cell.__dateAdjusted = true;
			if (value == null)
			{
				valueToSave = "";
				text = "";
			}
			else if (typeof (value) != "object" || typeof (value.getMonth) == "undefined")
			{				
				
				var parsedValue = Date.parseLocale(value);
				if (isNaN(parsedValue) || parsedValue == null || parsedValue == undefined)
				{
					valueToSave = "";
					text = "";
				}
				else
					valueToSave = this._grid._gridUtil._convertClientDateToServerString(parsedValue);
			}
			else
				valueToSave = this._grid._gridUtil._convertClientDateToServerString(valueToSave);
		}
		this._set_value($IG.FilteringNodeObjectProps.Value, valueToSave);
		cell.get_element().childNodes[1].innerHTML = $util.htmlEscapeCharacters(text);
		if (text == "" && $util.IsIE)
		{
			cell.get_element().childNodes[1].appendChild(document.createComment(""));
		}


	},
	_get_filterCell: function ()
	{
		var column = this._grid.get_columns().get_columnFromKey(this._columnFilter.get_columnKey());
		var cell = this._gridFiltering._row.get_cellByColumn(column);
		return cell;
	},
	dispose: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.FilteringNodeObject.dispose">
		/// Disposes of the object.
		/// </summary>

		this._columnFilter = null;
		this._gridFiltering = null;
		this._grid = null;
		$IG.FilteringNodeObject.callBaseMethod(this, "dispose");

	}


}
$IG.FilteringNodeObject.registerClass('Infragistics.Web.UI.FilteringNodeObject', $IG.ObjectBase);


$IG.ClientColumnFilter = function (columnKey, columnType, gridID)
{
	/// <summary locid="T:J#Infragistics.Web.UI.ClientColumnFilter">
	/// Object that defines rule and value based filtering condition. This object does not preserve its state.
	/// </summary>
	/// <param name="columnKey" type="String"> The key of the column that the column filter is tied to. </param>
	/// <param name="columnType" type="String"> The data type of the grid column that the column filter is tied to.
	/// Column type could be one of the following: date, boolean, number or string.
	/// </param>
	/// <param name="gridID" type="String"> The id for the grid to which the column filter belongs. </param>

	this._columnKey = columnKey;
	this._columnType = columnType;
	this._gridID = gridID;
	this._condition = new $IG.ClientCondition($IG.FilteringNodeObjectProps.Rule[1], "", this._columnType, this);
}
$IG.ClientColumnFilter.prototype =
{
	get_columnKey: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ClientColumnFilter.columnKey">
		/// Gets the key of the column that the column filter is tied to.
		/// </summary>
		/// <value type="String">Column key</value>
		return this._columnKey;
	},

	get_condition: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ClientColumnFilter.condition">
		/// Rule and value based filtering condition that will apply to the ControlDataField which 
		/// the column filter is tied to.		
		/// </summary>
		/// <value type="Infragistics.Web.UI.ClientCondition">Filtering condition</value>
		return this._condition;
	},

	get_columnType: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ClientColumnFilter.columnType">
		/// Gets the data type of the grid column that the column filter is tied to.
		/// Column type could be one of the following: date, boolean, number or string.
		/// </summary>
		/// <value type="String">Column type could be one of the following: date, boolean, number or string </value>
		return this._columnType;
	},

	dispose: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ClientColumnFilter.dispose">
		/// Disposes of the object.
		/// </summary>

		if (this._condition)
			this._condition.dispose();
		this._condition = null;
		this._columnKey = null;
		this._columnType = null;
		this._gridID = null;
	}
}
$IG.ClientColumnFilter.registerClass('Infragistics.Web.UI.ClientColumnFilter');



$IG.ClientCondition = function (rule, value, type, columnFilter)
{
	/// <summary locid="T:J#Infragistics.Web.UI.ClientCondition">
	/// Object that defines rule and value based filtering condition. This object does not preserve its state.
	/// </summary>
	/// <param name="rule"> 
	/// The filter condition rule. type will be one of the following, based on the column type:
	/// Infragistics.Web.UI.TextFilterRules, Infragistics.Web.UI.NumericFilterRules, 
	/// Infragistics.Web.UI.DateTimeFilterRules, or Infragistics.Web.UI.BooleanFilterRules
	/// </param>
	/// <param name="value">
	/// The filter condition value. type will be one of the following, based on the
	/// column type: String, Number, Date, or Boolean	
	/// </param>
	/// <param name="type" type="String"> 
	/// The data type of the grid column that the column filter is tied to.
	/// Column type could be one of the following: date, boolean, number or string. 
	/// </param>
	/// <param name="columnFilter" type="Infragistics.Web.UI.ClientColumnFilter"> The column filter to which the object belongs. </param>

	this._type = type;
	this._rule = rule;
	this._value = value;
	this._colKey = columnFilter.get_columnKey();
	this._gridID = columnFilter._gridID;

}
$IG.ClientCondition.prototype =
{
	get_rule: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ClientCondition.rule">
		/// Gets the filter condition rule. The return type will be one of the following, based on the column type:
		/// Infragistics.Web.UI.TextFilterRules, Infragistics.Web.UI.NumericFilterRules, 
		/// Infragistics.Web.UI.DateTimeFilterRules, or Infragistics.Web.UI.BooleanFilterRules
		/// </summary>
		/// <value>The return type will be one of the following, based on the column type:
		/// Infragistics.Web.UI.TextFilterRules, Infragistics.Web.UI.NumericFilterRules, 
		/// Infragistics.Web.UI.DateTimeFilterRules, or Infragistics.Web.UI.BooleanFilterRules
		/// </value>
		return this._rule;
	},

	set_rule: function (rule)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ClientCondition.rule">
		/// Sets the filter condition rule.
		/// </summary>
		/// <param name="rule" optional="false" mayBeNull="false">
		/// The type of the rule will be one of the following, based on the column type:
		/// Infragistics.Web.UI.TextFilterRules, Infragistics.Web.UI.NumericFilterRules, 
		/// Infragistics.Web.UI.DateTimeFilterRules, or Infragistics.Web.UI.BooleanFilterRules
		/// </param>
		this._rule = rule;
		var grid = ig_controls[this._gridID];
		if (grid && grid.Filtering)
		{
			
			var cell = this._get_filterCell();
			var ruleElm = grid.get_behaviors().get_filtering()._getRuleElement(rule, cell._dropDownBehaviour._targetContainer);
			if (ruleElm != null)
			{
				var elm = cell.get_element().childNodes[0].childNodes[0];
				elm.alt = ruleElm.innerHTML;
				elm.title = ruleElm.innerHTML;
				cell.get_element().childNodes[0].title = ruleElm.innerHTML;
			}
		}
		cell = null;
		grid = null;
		ruleElm = null;
	},

	get_value: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ClientCondition.value">
		/// Gets the filter condition value. The return type will be one of
		/// the following, based on the column type: String, Number, Date, or Boolean
		/// </summary>
		/// <value>The return type will be one of the following, based on the column type: 
		/// String, Number, Date, or Boolean
		/// </value>
		var grid = ig_controls[this._gridID];
		if (this._type == "date" && grid)
			return grid._gridUtil._convertServerDateStringToClientObject(this._value);
		return this._value;
	},

	set_value: function (value)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ClientCondition.value">
		/// Sets the filter condition value.
		/// </summary>
		/// <param name="value" optional="false" mayBeNull="false">
		/// The type of the value will be one of the following, based on the column type: 
		/// String, Number, Date, or Bool
		/// </param>

		if (this._type == "boolean")
			return;

		var grid = ig_controls[this._gridID];
		var column = grid.get_columns().get_columnFromKey(this._colKey);
		var filterType = grid.get_behaviors().get_filtering()._filterType;
		var cell = (filterType == $IG.FilteringType.RowFilter ? this._get_filterCell() : null);
		var valueToSave = (filterType == $IG.FilteringType.RowFilter ? cell.__parseValue(value) : value);
		var text = column._formatValue(valueToSave);

		if (this._type == "number")
		{
			var parsedValue = parseFloat(value);
			if (isNaN(parsedValue))
			{
				valueToSave = "";
				text = "";
			}
		}
		else if (this._type == "date")
		{
			if (value == null)
			{
				valueToSave = "";
				text = "";
			}
			else if (typeof (value) != "object" || typeof (value.getMonth) == "undefined")
			{
				
				var parsedValue = Date.parseLocale(value);				
				if (isNaN(parsedValue) || parsedValue == null || parsedValue == undefined)
				{
					valueToSave = "";
					text = "";
				}
				else
					valueToSave = grid._gridUtil._convertClientDateToServerString(parsedValue);
			}
			else
				valueToSave = grid._gridUtil._convertClientDateToServerString(valueToSave);
		}

		this._value = valueToSave;
		if (filterType == $IG.FilteringType.RowFilter)
		{
			cell.get_element().childNodes[1].innerHTML = $util.htmlEscapeCharacters(text);
			if (text == "" && $util.IsIE)
			{
				cell.get_element().childNodes[1].appendChild(document.createComment(""));
			}
		}
		cell = null;
		column = null;
	},

	dispose: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ClientCondition.dispose">
		/// Disposes of the object.
		/// </summary>

		
	},

	_get_filterCell: function ()
	{
		var grid = ig_controls[this._gridID];
		var column = grid.get_columns().get_columnFromKey(this._colKey);
		var cell = grid.get_behaviors().get_filtering()._row.get_cellByColumn(column);
		grid = null;
		column = null;
		return cell;
	}
}
$IG.ClientCondition.registerClass('Infragistics.Web.UI.ClientCondition');






$IG.FilteringAction = function (type, ownerName, object, value, tag)
{
	///<summary locid="T:J#Infragistics.Web.UI.FilteringAction">
	///Object for event arguments used in the Filtering behaviors to make full or partial postbacks.
	///</summary>

	

	var d = new Date()

	var timeOffset = -(d.getTimezoneOffset() * 60000);
	$IG.FilteringAction.initializeBase(this, [type, ownerName, object, value, timeOffset]);
}

$IG.FilteringAction.prototype =
{



}



$IG.FilteringAction.registerClass('Infragistics.Web.UI.FilteringAction', $IG.GridAction);














$IG.ColumnFilterAddedArgs = function (columnFilter)
{



	/// <summary>


	/// Class used as EventArgs while raising ColumnFilterAdded event


	/// </summary>


	/// <param name="columnFilter" type="Infragistics.Web.UI.ColumnFilter">The column filter that was added. </param>



	this._columnFilter = columnFilter;



	$IG.ColumnFilterAddedArgs.initializeBase(this);



}



$IG.ColumnFilterAddedArgs.prototype =
{



	get_columnFilter: function ()
	{



		/// <summary>


		/// Gets the column filter object that needs to be added.


		/// </summary>


		/// <value type="Infragistics.Web.UI.ColumnFilter">The column filter that was added. </value>



		return this._columnFilter;



	}



}



$IG.ColumnFilterAddedArgs.registerClass('Infragistics.Web.UI.ColumnFilterAddedArgs', $IG.EventArgs);














$IG.DataFilteredArgs = function (columnFilters)
{



	/// <summary>


	/// Class used as EventArgs while raising DataFiltered event


	/// </summary>


	/// <param name="columnFilters" type="Array" elementType="Infragistics.Web.UI.ColumnFilter">


	/// The column filter array that was used to filter the grid's data. 


	/// </param>



	this._columnFilters = columnFilters;



	$IG.DataFilteredArgs.initializeBase(this);



}



$IG.DataFilteredArgs.prototype =
{



	get_columnFilters: function ()
	{



		/// <summary>


		/// Gets the column filter array that was used to filter the grid's data.


		/// </summary>


		/// <value type="Array" elementType="Infragistics.Web.UI.ColumnFilter">Column filters </value>



		return this._columnFilters;



	}



}



$IG.DataFilteredArgs.registerClass('Infragistics.Web.UI.DataFilteredArgs', $IG.EventArgs);








$IG.CancelApplyFiltersEventArgs = function (behavior, columnFilters, columnFilterToAdd, checkBoxFiltersToRemove)
{



	///<summary>


	///Object for cancelable event arguments used in the Filtering behavior for the DataFiltering event.


	///</summary>


	/// <param name="behavior" type="Infragistics.Web.UI.Filtering">The filtering behavior. </param>


	/// <param name="columnFilters" type="Array" elementType="Infragistics.Web.UI.ColumnFilter">The column filter which originated on the server, but could have been changed, by which to filter. </param>


	/// <param name="columnFilterToAdd" type="Array" elementType="Infragistics.Web.UI.ClientColumnFilter">The column filter which were created on the client by which to filter. </param>



	$IG.CancelApplyFiltersEventArgs.initializeBase(this, [behavior]);




	this._columnFilters = [];
	this._uniqueValueFiltersToAdd = columnFilterToAdd;
	this._uniqueValueFiltersToDelete = checkBoxFiltersToRemove;


	



	if (columnFilters)
	{


		for (var i = 0; i < columnFilters.length; i++)


			this._columnFilters[i] = columnFilters[i];


	}



	






	if (columnFilterToAdd && behavior._filterType == $IG.FilteringType.RowFilter)
	{



		for (var i = 0; i < columnFilterToAdd.length; i++)


			this._columnFilters[this._columnFilters.length] = columnFilterToAdd[i];



	}



}



$IG.CancelApplyFiltersEventArgs.prototype =
{



	get_columnFilters: function ()
	{



		/// <summary>


		/// Gets the column filters array which will be used to filter the data in the grid.


		/// </summary>


		/// <value type="Array"></value>




		return this._columnFilters;



	},

	/// <summary>
	/// To be used only with ExcelStyle filtering. 
	/// Gets the column filters array of unique value filteres which will be excluded from the filtering criteria.
	/// </summary>
	/// <value type="Array"></value>
	get_uniqueValueFiltersToDelete: function ()
	{
		return this._uniqueValueFiltersToDelete;
	},
	/// <summary>
	/// To be used only with ExcelStyle filtering. 
	/// Gets the column filters array of unique value filteres which will be included from the filtering criteria.
	/// </summary>
	/// <value type="Array"></value>
	get_uniqueValueFiltersToAdd: function ()
	{
		return this._uniqueValueFiltersToAdd;
	},
	_dispose: function ()
	{


		if (this._columnFilters && this._columnFilters.length)
		{


			for (var i = 0; i < this._columnFilters.length; i++)
			{


				





				this._columnFilters[i] = null;


			}


		}


		this._columnFilters = null;

		delete this._uniqueValueFiltersToDelete;
		delete this._uniqueValueFiltersToAdd;
	}



}



$IG.CancelApplyFiltersEventArgs.registerClass('Infragistics.Web.UI.CancelApplyFiltersEventArgs', $IG.CancelBehaviorEventArgs);









$IG.ColumnFilterAddingRemovingEventArgs = function (behavior)
{



	///<summary>


	///Object for event arguments used in the Filtering behavior for Adding/Removing column filters.


	///</summary>


	/// <param name="behavior" type="Infragistics.Web.UI.Filtering">The filtering behavior. </param>



	$IG.ColumnFilterAddingRemovingEventArgs.initializeBase(this, [behavior]);



	


	this._props[1] = 2;



}



$IG.ColumnFilterAddingRemovingEventArgs.prototype =
{
}
$IG.ColumnFilterAddingRemovingEventArgs.registerClass('Infragistics.Web.UI.ColumnFilterAddingRemovingEventArgs', $IG.CancelBehaviorEventArgs);





$IG.FilteringType = function ()
{
	/// <summary locid="T:J#Infragistics.Web.UI.FilteringType">
	/// The enumeration defines where the filter row is displayed.
	/// </summary>
	/// <field name="RowFilter" type="Number" integer="true" static="true">
	/// Displays a row filter.
	/// </field>
	/// <field name="AdvanceFilter" type="Number" integer="true" static="true">
	/// FAllows the creation of more than one condition per column.
	/// </field>
	/// <field name="ExcelStyleFilter" type="Number" integer="true" static="true">
	/// Excel style filtering.
	/// </field>
}
$IG.FilteringType.prototype =
{
	RowFilter: 0,
	ExcelStyleFilter: 1
	//AdvanceFilter: 2
};
$IG.FilteringType.registerEnum("Infragistics.Web.UI.FilteringType");

$IG.FilteringAlignment = function ()
{
	/// <summary locid="T:J#Infragistics.Web.UI.FilteringAlignment">
	/// The enumeration defines where the filter row is displayed.
	/// </summary>
	/// <field name="Top" type="Number" integer="true" static="true">
	/// Filter row is displayed in the header.
	/// </field>
	/// <field name="Bottom" type="Number" integer="true" static="true">
	/// Filter row is displayed in the footer.
	/// </field>
}
$IG.FilteringAlignment.prototype =
{
	Top: 0,
	Bottom: 1
};
$IG.FilteringAlignment.registerEnum("Infragistics.Web.UI.FilteringAlignment");


$IG.UniqueValueCasing = function ()
{
	/// <summary locid="T:J#Infragistics.Web.UI.UniqueValueCasing">
	/// The enumeration defines how the text of the unique value is displayed if filter type is RowFilter and filtering is not case sensitive.
	/// </summary>
	/// <field name="Lower" type="Number" integer="true" static="true">
	/// The text of the unique filter value will be displayed in lower case letters (example: name).
	/// </field>
	/// <field name="Upper" type="Number" integer="true" static="true">
	/// The text of the unique filter value will be displayed in upper case letters(example: NAME).
	/// </field>
	/// <field name="Camel" type="Number" integer="true" static="true">
	/// The text of the unique filter value will be displayed in camel case, where the first letter of the word
	/// is capitalized and all other letters are lower case (example: Name).
	/// </field>
}
$IG.UniqueValueCasing.prototype =
{
	Lower: 0,
	Upper: 1,
	Camel: 2
};
$IG.UniqueValueCasing.registerEnum("Infragistics.Web.UI.UniqueValueCasing");


$IG.FilteringVisibility = function ()
{
	/// <summary locid="T:J#Infragistics.Web.UI.FilteringVisibility">
	/// The enumeration defines whether the filter row is displayed.
	/// </summary>
	/// <field name="Visible" type="Number" integer="true" static="true">
	/// Filter row is visible.
	/// </field>
	/// <field name="Hidden" type="Number" integer="true" static="true">
	/// Filter row is hidden.
	/// </field>
}
$IG.FilteringVisibility.prototype =
{
	Visible: 0,
	Hidden: 1
};
$IG.FilteringVisibility.registerEnum("Infragistics.Web.UI.FilteringVisibility");



$IG.TextFilterRules = function ()
{
	/// <summary locid="T:J#Infragistics.Web.UI.TextFilterRules">
	/// Allowable values for the FilteringNodeObject.set_rule method for string type columns
	/// </summary>

	/// <field name="All" type="Number" integer="true" static="true">
	/// All.
	/// </field>
	/// <field name="Equals" type="Number" integer="true" static="true">
	/// Equals.
	/// </field>
	/// <field name="DoesNotEqual" type="Number" integer="true" static="true">
	/// Does not equal.
	/// </field>
	/// <field name="BeginsWith" type="Number" integer="true" static="true">
	/// Begins with.
	/// </field>	
	/// <field name="EndsWith" type="Number" integer="true" static="true">
	/// Ends with.
	/// </field>
	/// <field name="Contains" type="Number" integer="true" static="true">
	/// Contains.
	/// </field>
	/// <field name="DoesNotContain" type="Number" integer="true" static="true">
	/// Does not contain.
	/// </field>
	/// <field name="IsNull" type="Number" integer="true" static="true">
	///  All null values.
	/// </field>
	/// <field name="IsNotNull" type="Number" integer="true" static="true">
	/// All values which are not null.
	/// </field>
}
$IG.TextFilterRules.prototype =
{
	All: 0,
	Equals: 1,
	DoesNotEqual: 2,
	BeginsWith: 3,
	EndsWith: 4,
	Contains: 5,
	DoesNotContain: 6,
	IsNull: 7,
	IsNotNull: 8
};
$IG.TextFilterRules.registerEnum("Infragistics.Web.UI.TextFilterRules");



$IG.NumericFilterRules = function ()
{
	/// <summary locid="T:J#Infragistics.Web.UI.NumericFilterRules">
	/// Allowable values for the FilteringNodeObject.set_rule method for numeric type columns
	/// </summary>

	/// <field name="All" type="Number" integer="true" static="true">
	/// All.
	/// </field>
	/// <field name="Equals" type="Number" integer="true" static="true">
	/// Equals.
	/// </field>
	/// <field name="DoesNotEqual" type="Number" integer="true" static="true">
	/// Does not equal.
	/// </field>
	/// <field name="GreaterThan" type="Number" integer="true" static="true">
	/// Greater than.
	/// </field>
	/// <field name="GreaterThanOrEqualTo" type="Number" integer="true" static="true">
	/// Greater than or equal to.
	/// </field>
	/// <field name="LessThan" type="Number" integer="true" static="true">
	/// Less than.
	/// </field>
	/// <field name="LessThanOrEqualTo" type="Number" integer="true" static="true">
	/// Less than or equal to.
	/// </field>
	/// <field name="IsNull" type="Number" integer="true" static="true">
	///  All null values.
	/// </field>
	/// <field name="IsNotNull" type="Number" integer="true" static="true">
	/// All values which are not null.
	/// </field>
}
$IG.NumericFilterRules.prototype =
{
	All: 0,
	Equals: 1,
	DoesNotEqual: 2,
	GreaterThan: 3,
	GreaterThanOrEqualTo: 4,
	LessThan: 5,
	LessThanOrEqualTo: 6,
	IsNull: 7,
	IsNotNull: 8
};
$IG.NumericFilterRules.registerEnum("Infragistics.Web.UI.NumericFilterRules");



$IG.DateTimeFilterRules = function ()
{
	/// <summary locid="T:J#Infragistics.Web.UI.DateTimeFilterRules">
	/// Allowable values for the FilteringNodeObject.set_rule method for date type columns
	/// </summary>
	/// <field name="All" type="Number" integer="true" static="true">
	/// All.
	/// </field>
	/// <field name="Equals" type="Number" integer="true" static="true">
	/// Equals.
	/// </field>
	/// <field name="Before" type="Number" integer="true" static="true">
	/// Before.
	/// </field>
	/// <field name="After" type="Number" integer="true" static="true">
	/// After.
	/// </field>
	/// <field name="Tomorrow" type="Number" integer="true" static="true">
	/// Tomorrow.
	/// </field>
	/// <field name="Today" type="Number" integer="true" static="true">
	/// Today.
	/// </field>
	/// <field name="Yesterday" type="Number" integer="true" static="true">
	/// Yesterday.
	/// </field>
	/// <field name="NextWeek" type="Number" integer="true" static="true">
	/// Next week.
	/// </field>
	/// <field name="ThisWeek" type="Number" integer="true" static="true">
	/// This week.
	/// </field>
	/// <field name="LastWeek" type="Number" integer="true" static="true">
	/// Last week.
	/// </field>
	/// <field name="NextMonth" type="Number" integer="true" static="true">
	/// Next month.
	/// </field>
	/// <field name="ThisMonth" type="Number" integer="true" static="true">
	/// This month.
	/// </field>
	/// <field name="LastMonth" type="Number" integer="true" static="true">
	/// Last month.
	/// </field>
	/// <field name="NextQuarter" type="Number" integer="true" static="true">
	/// Next quarter.
	/// </field>
	/// <field name="ThisQuarter" type="Number" integer="true" static="true">
	/// This quarter.
	/// </field>
	/// <field name="LastQuarter" type="Number" integer="true" static="true">
	/// Last quarter.
	/// </field>
	/// <field name="NextYear" type="Number" integer="true" static="true">
	/// Next year.
	/// </field>
	/// <field name="ThisYear" type="Number" integer="true" static="true">
	/// This year.
	/// </field>
	/// <field name="LastYear" type="Number" integer="true" static="true">
	/// Last year.
	/// </field>
	/// <field name="YearToDate" type="Number" integer="true" static="true">
	///Year to date.
	/// </field>
	/// <field name="IsNull" type="Number" integer="true" static="true">
	///  All null values.
	/// </field>
	/// <field name="IsNotNull" type="Number" integer="true" static="true">
	/// All values which are not null.
	/// </field>

}
$IG.DateTimeFilterRules.prototype =
{
	All: 0,
	Equals: 1,
	Before: 2,
	After: 3,
	Tomorrow: 4,
	Today: 5,
	Yesterday: 6,
	NextWeek: 7,
	ThisWeek: 8,
	LastWeek: 9,
	NextMonth: 10,
	ThisMonth: 11,
	LastMonth: 12,
	NextQuarter: 13,
	ThisQuarter: 14,
	LastQuarter: 15,
	NextYear: 16,
	ThisYear: 17,
	LastYear: 18,
	YearToDate: 19,
	IsNull: 20,
	IsNotNull: 21,
	DoesNotEqual: 22
};
$IG.DateTimeFilterRules.registerEnum("Infragistics.Web.UI.DateTimeFilterRules");



$IG.BooleanFilterRules = function ()
{
	/// <summary locid="T:J#Infragistics.Web.UI.BooleanFilterRules">
	/// Allowable values for the FilteringNodeObject.set_rule method for boolean type columns
	/// </summary>
	/// <field name="All" type="Number" integer="true" static="true">
	/// All.
	/// </field>
	/// <field name="True" type="Number" integer="true" static="true">
	/// True.
	/// </field>
	/// <field name="False" type="Number" integer="true" static="true">
	/// False.
	/// </field>
	/// <field name="IsNull" type="Number" integer="true" static="true">
	///  All null values.
	/// </field>
	/// <field name="IsNotNull" type="Number" integer="true" static="true">
	/// All values which are not null.
	/// </field>  
	/// <field name="IsNotTrue" type="Number" integer="true" static="true">
	/// All values which are not true. This enum value will only be
	/// used when filter type is ExcelStyleFiltering
	/// </field>
	/// <field name="IsNotFalse" type="Number" integer="true" static="true">
	/// All values which are not false. This enum value will only be
	/// used when filter type is ExcelStyleFiltering
	/// </field>
}
$IG.BooleanFilterRules.prototype =
{
	All: 0,
	True: 1,
	False: 2,
	IsNull: 3,
	IsNotNull: 4,
	IsNotTrue: 5,
	IsNotFalse: 6
};
$IG.BooleanFilterRules.registerEnum("Infragistics.Web.UI.BooleanFilterRules");






$IG.GridFilteringProps = new function ()
{
	this.Visibility = [$IG.GridBehaviorProps.Count + 0, $IG.FilteringVisibility.Visible];
	this.RuleDropdownZIndex = [$IG.GridBehaviorProps.Count + 1, 100100];
	this.Count = $IG.GridBehaviorProps.Count + 2;
};


$IG.ColumnFilterSettingsProps = new function ()
{
	this.ColumnKey = [$IG.ObjectBaseProps.Count + 0, ""];
	this.Count = $IG.ObjectBaseProps.Count + 1;
};


$IG.ColumnFilterProps = new function ()
{
	this.ColumnKey = [$IG.ObjectBaseProps.Count + 0, ""];
	this.ColumnType = [$IG.ObjectBaseProps.Count + 1, ""];
	this.Count = $IG.ObjectBaseProps.Count + 2;
};


$IG.FilteringNodeObjectProps = new function ()
{
	this.Rule = [$IG.ObjectBaseProps.Count + 0, 0];
	this.Value = [$IG.ObjectBaseProps.Count + 1];
	this.Count = $IG.ObjectBaseProps.Count + 2;
};

