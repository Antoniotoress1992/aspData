/*
* igDataMenuItem.js
* Version 13.2.20132.2007
* Copyright(c) 2001-2013 Infragistics, Inc. All Rights Reserved.
*/



$IG.DataMenuItem = function(adr,element, props, owner, csm, collection, parent)
{
	$IG.DataMenuItem.initializeBase(this, [adr, element, props, owner, csm, collection, parent]);    
	this.initialize();
}

$IG.DataMenuItem.prototype =
{   
    _isActive:false,
	_animation:null,

    initialize: function()
    {
        ///<summary locid="M:J#Infragistics.Web.UI.DataMenuItem.initialize">Initializes the DataMenuItem object.</summary>
    	this._initialClass = this.get_element().className;
    	this._isActive = false;
    	this._initialized = true;
        this._itemCollection._owner = this;
        this._itemGroupSettings = null;
    },
    
    get_level: function()
    {
        ///<summary locid="M:J#Infragistics.Web.UI.DataMenuItem.get_level">
        /// Gets the level of the item on client. Root items are at level 0.
        ///</summary>
        ///<value type="int"></value>
        return this._get_address().split(".").length - 1;
    },

    _navigateOnClick: function (openInNewWindow, modal)
    {
		var url = this._getNavigateUrl();
		var targetFrame = this.get_target() || "_self";
		// L.T. 22/12/2010 60866 Change the links of WDM to have href=# instead of javascrip:void(0). This causes problems on IE6.
		
		if (url && url !== document.URL + '#' && url != "#") try
		{
			
			if(openInNewWindow)
				window.open(url, "_blank");
			else if (modal)
			{
				
				var winWidth = window.outerWidth;
				var winHeight = window.outerHeight;
				var winLeft = window.screenLeft;
				var winTop = window.screenTop;
				window.open(url, '', 'width=' + winWidth + ',height=' +
					winHeight + ',left=' + winLeft + ",top=" + winTop);
			}
			else if (targetFrame == "_self")
				document.location.href = url;
			else
				window.open(url, targetFrame);
		}
		catch(ex){ }
    },

    get_isSeparator:function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.DataMenuItem.isSeparator">Get whether the item is of type separator.</summary>
        ///<value type="Boolean"></value>
        if(this._get_value($IG.DataMenuItemProps.IsSeparator) < 1)
            return false;
        return true;
    },
    
    get_text:function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.DataMenuItem.text">Get the menu item text.</summary>
        ///<value type="String"></value>
        if(this.get_textElement() != null) return this.get_textElement().innerHTML
        return "[Templated Item]";
    },
    
	set_text:function(text)
	{
	    ///<summary locid="P:J#Infragistics.Web.UI.DataMenuItem.text">Set the menu item text.</summary>
		///<param name="text" type="String">Specify item text.</param>
	    $IG.DataMenuItem.callBaseMethod(this, 'set_text', [text]);
	    if(this.get_textElement() != null) this.get_textElement().innerHTML = text; 
	},
	
    get_textElement:function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.DataMenuItem.textElement">Get a reference to the menu item span element.</summary>
        ///<returns domElement="true"></returns>
        return this.get_element().getElementsByTagName("SPAN")[0];
    },
    
    get_isActive: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.DataMenuItem.isActive">Get whether the item is active.</summary>
        ///<value type="Boolean"></value>
        return this._isActive;
    },

    set_active: function(state)
    {
        ///<summary locid="P:J#Infragistics.Web.UI.DataMenuItem.active">Set whether the item is active. Applies active CSS class.</summary>
        ///<param name="state" type="Boolean">Specify whether to activate the item or not.</param>
        this._set_active(state);
		// sync the activation with selection, as we talked on a meeting.
		this._set_selected(state);
    },

	_set_active: function(state)
	{
		if(state && !this._isActive)
        {
            $util.addCompoundClass(this.get_element(), this.get_stateCssClass("Active"));
            this._isActive = true;
        }
        else if(!state && this._isActive)
        {
            $util.removeCompoundClass(this.get_element(), this.get_stateCssClass("Active"));
            this._isActive = false;
        }
	},

	_set_selected: function(value)
	{
        if(value)
        {
            $util.addCompoundClass(this.get_element(), this.get_stateCssClass("Selected"));
        }
        else
        {			
            $util.removeCompoundClass(this.get_element(), this.get_stateCssClass("Selected"));
        }
	},

    
    set_enabled: function(value)
    {
        ///<summary locid="P:J#Infragistics.Web.UI.DataMenuItem.enabled">Set the menu item enabled state.</summary>
        ///<param name="value" type="Boolean">Specify whether to enabled the item.</param>
        this._getFlags().setEnabled(value);
        if (value) {
            $util.removeCompoundClass(this.get_element(), this.get_stateCssClass("Disabled"));
            
            // K.D. September 5th, 2013 Bug #143983 Page loads again even when we cancel itemclick event
            // in fact the issue is that after we enable the item on the client the default href changes
            // from '#' to ''
            var url = this.get_navigateUrl();
            if (url && url !== '#' && url !== this._getNavigateUrl()) {
                this.set_navigateUrl(url);
            }
        } else {
            // K.D. September 12th, 2013 Bug #150775 Unselect the item when disabling it
            if (this.get_selected()) {
                this.set_selected(false);
            }
            $util.addCompoundClass(this.get_element(), this.get_stateCssClass("Disabled"));
        }
    },    
    
    get_selected: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.DataMenuItem.selected">Get whether the item is currently selected.</summary>
        ///<value type="Boolean"></value>
        return this._getFlags().getSelected(this._owner);
    },
    
	set_selected: function(value)
	{
		///<summary locid="P:J#Infragistics.Web.UI.DataMenuItem.selected">
	    /// Set the item selected state.
	    ///</summary>
	    ///<param name="value" type="Boolean">Specify whether to select the item.</param>
		this._set_active(value); // sync selection and activation as styles only!
	    this._set_selected(value);
		this._getFlags().setSelected(value); // state is set separately only from here.
	},

	get_cssClass: function()
	{
	    ///<summary locid="P:J#Infragistics.Web.UI.DataMenuItem.cssClass">Get the CSS class applied to the item.</summary>
	    ///<value type="String"></value>
	    return this._initialClass;
	},
    
    get_stateCssClass: function(state) 
    {
		///<summary locid="P:J#Infragistics.Web.UI.DataMenuItem.stateCssClass">
        /// Get the state CssClass used for this item.
        ///</summary>
        ///<param name="state" type="String">Specify state.(Active | Hover | Selected | Disabled) "" (blank)</param>
        ///<returns type="String">Menu item state CSS class.</returns>
       var menu = this._get_owner();
       var stateVal = "";
       var cssClass = "";
       if(this.get_orientation() == $IG.Orientation.Vertical)
       {
           if(this.get_level() < 1) { stateVal = "mivRoot"+state; }
            else { stateVal = "miv"+state; }
       }
       else
       {
           if(this.get_level() < 1) { stateVal = "mihRoot"+state;}
            else { stateVal = "mih"+state; }       
       }
       if(state.toString().toLowerCase() == "hover")
       {
             cssClass = this._owner._itemSettings.get_HoverCssClass();
       }
       if(state.toString().toLowerCase() == "selected")
       {
             cssClass = this._owner._itemSettings.get_SelectedCssClass();
       }
       if(cssClass != null && cssClass.length > 1) return cssClass;
        else return menu._get_clientOnlyValue(stateVal);
    },
    
    get_anchorElement: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.DataMenuItem.anchorElement">Get a reference to the anchor dom element associated with the item.</summary>
        ///<returns domElement="true"></returns>
        if(!this._anchorElement)
            this._anchorElement =  this.get_element().getElementsByTagName("a")[0];
        return this._anchorElement;
    },

    _getNavigateUrl: function () 
    {
        ///<summary locid="P:J#Infragistics.Web.UI.DataMenuItem.navigateUrl">Get the navigate URL associated with the item.</summary>
        ///<value type="String"></value>
        var a = this.get_anchorElement();
        if (a)
            return a.href;
        else
            return null;        
    },

    get_navigateUrl: function () 
    {
        ///<summary locid="P:J#Infragistics.Web.UI.DataMenuItem.navigateUrl">
        ///Get the navigate URL.
        ///</summary>
        ///<value type="String"></value>
        return this._get_value($IG.NavItemProps.NavigateUrl);   
    },

    set_navigateUrl: function(url) 
    {
        ///<summary locid="P:J#Infragistics.Web.UI.DataMenuItem.navigateUrl">
        /// Set the URL associated with this node object.
        ///</summary>
		///<value type="String" />
        this._set_value($IG.NavItemProps.NavigateUrl, url);
        var a = this.get_anchorElement();
        if (!$util.isNullOrUndefined(a))
            a.href = url;
    },

    get_target : function ()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.DataMenuItem.target">Get the URL target associated with the item.</summary>
        ///<value type="String"></value>
        var a = this.get_anchorElement();
        if(a)
            return a.target;
        else
            return null;
    },
    
    get_defaults:function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.DataMenuItem.defaults"></summary>
        ///<value type="String"></value>
        var defaults = $IG.DataMenuItem.callBaseMethod(this, 'get_defaults')
        return defaults.concat([0,0]);
    },

    get_expanded: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.DataMenuItem.expanded">Get whether the menu item is expanded.</summary>
        ///<value type="Boolean"></value>
	    var val = this._get_value( $IG.DataMenuItemProps.Expanded);
	    return (val == 1) ? true : false;
	},
	
    set_hover : function(value)
    {
        ///<summary locid="P:J#Infragistics.Web.UI.DataMenuItem.hover">Set whether the item is hovered or not.</summary>
        ///<param name="value" type="Boolean">Specify true to appliy the hover CSS class, false otherwise.</param>
        if(value)
        {
            $util.addCompoundClass(this.get_element(), this.get_stateCssClass("Hover"));
        }
        else if(!this.get_expanded())
        {
            $util.removeCompoundClass(this.get_element(), this.get_stateCssClass("Hover"));
        }
    },
    
	set_expanded : function(value) {
		///<summary locid="P:J#Infragistics.Web.UI.DataMenuItem.expanded">
	    /// Set whether to expand the item or not.
	    ///</summary>
	    ///<param name="value" type="Boolean">Specify true to expand the item, false otherwise.</param>
        var val = this._get_value( $IG.DataMenuItemProps.Expanded);
        if(val == value) 
            return;
	    this._set_value( $IG.DataMenuItemProps.Expanded, value);
	},

	_get_subgroup : function()
	{
		var scrollContainer = this._get_owner().get_enableScrolling() ? this._get_scrollContainer() : this.get_element();
		return scrollContainer ? this._get_owner()._child(scrollContainer, "UL", 0) : null;
	},

    _get_scrollContainer: function()
    {
        if($util.isNullOrUndefined(this.__scrollContainerElement))
        {
            var divs = $adrutil.getImmediateElementsByTagName(this.get_element(), "DIV");
            for(var i = 0, len = divs.length; i < len; i++)
            {
                var div = divs[i];
                if(div.id && div.id.indexOf("mkr:sd") != -1)
                    this.__scrollContainerElement = div;
            }
			// L.T. 3/11/2010 48650, 48654 fix add/remove API to work properly, until now it was released untested.
			if(!this.__scrollContainerElement)
			{
				var slider = this._get_sliderContainer();
				if(slider)
					this.__scrollContainerElement = slider.firstChild;
			}
        }
        return this.__scrollContainerElement;
    },

    _set_scrollContainer: function(newElem)
    {
        this.__scrollContainerElement = newElem;
    },

    _get_sliderContainer: function()
    {
		// L.T. 3/11/2010 48650, 48654 fix add/remove API to work properly, until now it was released untested.
		if(!this.__slideContainer && this._owner)
		{
			this.__slideContainer = $get(this._owner._id + "_" + this._get_address());
		}
        return this.__slideContainer;
    },

    _set_sliderContainer: function(containerElem)
    {
        this.__slideContainer = containerElem;
    },

    _displayScrollButton: function(buttonIndex, show)
    {
        this._get_owner()._displayScrollButton(this._get_scrollContainer(), buttonIndex, show);
    },

    _getScrollButtonVisible: function(buttonIndex)
    {
        return this._get_owner()._getScrollButtonVisible($adrutil.getImmediateElementsByTagName(this._get_scrollContainer(), "A")[buttonIndex]);
    },

	_set_animation: function(animation)
	{
		this.__clearAnimation(true);
		this._animation = animation;
	},

	__clearAnimation: function(dispose)
	{
		if (this._animation)
		{
			if (this._animation.get_isAnimating() && this._animation.stop)
				this._animation.stop();

			if(dispose)
			{
				this._animation.dispose();
				this._animation = null;
			}
		}
	},

	_get_animation: function()
	{
		return this._animation;
	},

	get_childItem:function(index, enabled)
	{
	    ///<summary locid="P:J#Infragistics.Web.UI.DataMenuItem.childItem">
	    /// Get the child item at the index specified.
	    /// If enabled is set the children collection will be traveresed for the nearest enabled item (excluding the separator items),
	    /// if the item at specified index is not enabled.
	    ///</summary>
	    ///<param name="index" type="int">Specify index of a child item.</param>
	    ///<param name="enabled" type="Boolean" optional="true">Specify whether to enable the item.</param>
	    ///<returns type="Infragistics.Web.UI.DataMenuItem" mayBeNull="true">Returns the child item at the index specified if it exists.</returns>

	    
        var collection = this.getItems();
        var item = collection.getItem(index);
        var initialItem = item;
        if (!$util.isNullOrUndefined(enabled) && enabled)
        {
            while (item && (!item._getFlags().getEnabled(this._owner) || item.get_isSeparator()))
            {
                item = item.get_nextItem();
            }

            if($util.isNullOrUndefined(item) && index > 0)
            {
                // wrap around and start from the beginning to look for the first enabled item.
                item = collection.getItem(0);
                while (item && (!item._getFlags().getEnabled(this._owner) || item.get_isSeparator()))
                {
                    if(item._get_address() == initialItem._get_address())
                        return null;
                    item = item.get_nextItem();
                }
            }
        }
        return item;
	},
	
	hasChildren:function()
	{
	    ///<summary locid="M:J#Infragistics.Web.UI.DataMenuItem.hasChildren">Get whether the item has children.</summary>
	    ///<value type="Boolean"></value>
	    return !$util.isNullOrUndefined(this._get_subgroup());
	},
	
	getChildrenCount:function()
	{
	    ///<summary locid="M:J#Infragistics.Web.UI.DataMenuItem.getChildrenCount">Get the number of children.</summary>
	    ///<value type="int"></value>
        return this.getItems().getChildrenCount();
	},
	
	get_parentItem:function()
	{
	    ///<summary locid="M:J#Infragistics.Web.UI.DataMenuItem.get_parentItem">Get the parent item of this item.</summary>
	    ///<value type="Infragistics.Web.UI.DataMenuItem" mayBeNull="true"></value>	    
        return this._getUIBehavior().getItemFromElem(this._get_parentLiElement());
	},
	
	open:function()
	{
	    ///<summary locid="M:J#Infragistics.Web.UI.DataMenuItem.open">
	    /// Opens all sub-menus down to this item.
	    ///</summary>
        this._get_owner().__showItem(this);
	},
	
	get_nextItem:function()
	{
	    ///<summary locid="P:J#Infragistics.Web.UI.DataMenuItem.nextItem">Get the next sibling item.</summary>
	    ///<value type="Infragistics.Web.UI.DataMenuItem" mayBeNull="true"></value>
	    var nodeElement = this.get_element();
		if(!$util.isNullOrUndefined(nodeElement))
		{
		    var nextElement = $util.skipTextNodes(nodeElement.nextSibling);
		    if (!$util.isNullOrUndefined(nextElement))
		        return this._getUIBehavior().getItemFromElem(nextElement);
		}
		return null;
	},
	
	get_previousItem:function()
	{
	    ///<summary locid="P:J#Infragistics.Web.UI.DataMenuItem.previousItem">Get the prevous sibling item.</summary>
	    ///<value type="Infragistics.Web.UI.DataMenuItem" mayBeNull="true"></value>
	    var nodeElement = this.get_element();
		if(!$util.isNullOrUndefined(nodeElement))
		{
		    var previousElement = $util.skipTextNodes(nodeElement.previousSibling, true);
		    if (!$util.isNullOrUndefined(previousElement))
		        return this._getUIBehavior().getItemFromElem(previousElement);
		}
		return null;
	
	},
	
	_ensureFlags:function()
	{
	    $IG.DataMenuItem.callBaseMethod(this, '_ensureFlags');
	    this._ensureFlag($IG.ClientUIFlags.Selected, false);
	},
	
   get_orientation : function()
   {
       ///<summary locid="P:J#Infragistics.Web.UI.DataMenuItem.orientation">Get the item orientation.</summary>
       ///<value type="Infragistics.Web.UI.Orientation"></value>

	    
	    if(!this.get_isInitialized()) return;
	    if(this.get_level() < 1)
	    {
	        
	        return this._get_owner().get_orientation();
	    }
	    if(this.get_prentItemsGroupSettings() != null)
            return this.get_prentItemsGroupSettings().get_orientation();
        return $IG.Orientation.Vertical;    
	},
	
	restore_style:function()
	{
		///<summary locid="M:J#Infragistics.Web.UI.DataMenuItem.restore_style">Restore the default item CSS classes.</summary>
        if(this.get_selected())
            $util.addCompoundClass(this.get_element(), this.get_stateCssClass("Selected"));
        if(this._getFlags().getHovered())
            $util.addCompoundClass(this.get_element(), this.get_stateCssClass("Hover"));
        if(!this.get_selected())
            $util.removeCompoundClass(this.get_element(), this.get_stateCssClass("Selected"));
        if(!this._getFlags().getHovered() && !this.get_expanded())
            $util.removeCompoundClass(this.get_element(), this.get_stateCssClass("Hover"));
        if(!this.get_expanded())
            $util.removeCompoundClass(this.get_element(), this.get_stateCssClass("Active"));    
	},
	
	get_itemsGroupSettings:function()
	{
	    ///<summary locid="P:J#Infragistics.Web.UI.DataMenuItem.itemsGroupSettings">Get the item group settings.</summary>
	    ///<value type="Infragistics.Web.UI.DataMenuGroupSettings"></value>
        return this._itemGroupSettings;
	},

    _set_itemsGroupSettings:function(obj)
    {
        this._itemGroupSettings = obj;
        this._itemGroupSettings._set_item(this);
    },

	get_prentItemsGroupSettings:function()
	{
	    ///<summary locid="P:J#Infragistics.Web.UI.DataMenuItem.prentItemsGroupSettings">Get the parent item group settings.</summary>
	    ///<value type="Infragistics.Web.UI.DataMenuGroupSettings"></value>
        var parentItem = this.get_parentItem();
	    if(!$util.isNullOrUndefined(parentItem))
	        return parentItem.get_itemsGroupSettings();
	    return this._owner.get_menuGroupSettings();
	},
	
	isDescendant:function(item)
	{
	    ///<summary locid="M:J#Infragistics.Web.UI.DataMenuItem.isDescendant">
	    /// Get whether this item is descendant of the specified item.
	    ///</summary>
	    ///<param name="item" type="Infragistics.Web.UI.DataMenuItem">Specify an item.</param>
	    ///<returns type="Boolean">Returns true if the current item is child of the specified item.</returns>
        var pItem = this.get_parentItem();
        if(pItem == null)
            return false;
        if( this._get_address() == item._get_address() )
        {
            return true;
        }
        return pItem.isDescendant(item);
	},
	
	calcScrolls:function()
	{
	    scrollObj = new Object();
	    scrollObj.Top = 0;
	    scrollObj.Left = 0;
	    
	    var parent = this.get_element().parentNode;
	    while(parent != null && parent.nodeName != "BODY" && parent.style.position != "static")
	    {
	        scrollObj.Top += parent.scrollTop;
	        scrollObj.Left += parent.scrollLeft;
	        parent = parent.parentNode;
	        if(parent.nodeName == "BODY") break;
	    }
	    
	    return scrollObj;
	},
	
	_toggleClicked: function()
	{
		var oldState = this._get_value($IG.DataMenuItemProps.Clicked, true);
		this._set_value($IG.DataMenuItemProps.Clicked, !oldState);
	},

    _getUIBehavior: function()
    {
        if($util.isNullOrUndefined(this._controlUIBehavior))
        {
            this._controlUIBehavior = this._get_owner()._itemCollection._getUIBehaviorsObj();
        }
        return this._controlUIBehavior;
    },

	_get_parentLiElement: function()
	{
		var elem = this.get_element().parentNode.parentNode;
		if(!this._get_owner().get_enableScrolling())
			return elem;

		var parent = elem.realParent;
		if (parent)
			return parent;
		parent = elem.parentNode;
		return (parent && parent.nodeName == "LI") ? parent : null;
	},

	dispose: function()
	{
	    ///<summary locid="M:J#Infragistics.Web.UI.DataMenuItem.dispose">Disposes the object.</summary>
	    this._initialized = false;
        this._itemGroupSettings = null;
		this.__clearAnimation(true);
        $IG.DataMenuItem.callBaseMethod(this, "dispose");
	}
}
$IG.DataMenuItem.registerClass('Infragistics.Web.UI.DataMenuItem', $IG.NavItem);
