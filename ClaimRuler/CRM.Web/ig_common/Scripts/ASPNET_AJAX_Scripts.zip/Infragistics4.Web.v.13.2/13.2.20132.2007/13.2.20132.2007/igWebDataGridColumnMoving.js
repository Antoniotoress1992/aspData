/*
* igWebDataGridColumnMoving.js
* Version 13.2.20132.2007
* Copyright(c) 2001-2013 Infragistics, Inc. All Rights Reserved.
*/



$IG.ColumnMoving = function (obj, objProps, control, parentCollection, hierarchical)
{
	/// <summary locid="T:J#Infragistics.Web.UI.ColumnMoving">
	/// ColumnMoving behavior object of the grid.
	/// </summary>
	
	$IG.ColumnMoving.initializeBase(this, [obj, objProps, control, parentCollection]);
	this._container = control._elements["container"]; 

	this._horizontalScrollBar = control._elements["hScrBar"]; 
	this._verticalScrollBar = control._elements["vScrBar"];
	this._hierarchical = hierarchical;

	this._gridHasHeaderLayout = control._get_clientOnlyValue("hdlay");
	this._autoGenCols = this._get_clientOnlyValue("agc");

	
	this._header = control._elements["header"];

	if (!this._header)
		return;
	this._headerRow = control._elements["columnHeaderRow"] && control._elements["columnHeaderRow"].length ? control._elements["columnHeaderRow"][0] : control._elements["columnHeaderRow"]; 
	if (!control._get_clientOnlyValue("shH"))
		this._headerRow = null;

	this._dataTbl = control._elements["dataTbl"];
	this._topDragIndicatorCssClass = this._get_clientOnlyValue("tdic"); 
	this._middleDragIndicatorCssClass = this._get_clientOnlyValue("mdic"); 
	this._bottomDragIndicatorCssClass = this._get_clientOnlyValue("bdic"); 
	this._dragMarkupCssClass = this._get_clientOnlyValue("dmc");

	this._headerRowDragStyle = this._get_clientOnlyValue("hds");

	this._dragDropBehaviors = new Array();

	this._currentDraggingAction = this.__createDragActionManager();

	this._headerDiv = ((control._elements["headerContent"].parentNode && control._elements["headerContent"].parentNode.tagName == "DIV") ? control._elements["headerContent"].parentNode : null);

	if (this._hierarchical)
	{
		
		this._grid._gridUtil = new $IG.HierarchicalGridUtility(this._grid);
		var groupingEnabled = this._grid._get_band().get_groupingSettings().get_enableColumnGrouping();
		if (groupingEnabled)
		{
			this._onGroupingDragStartHandler = Function.createDelegate(this, this._onGroupingDragStart);
			this._grid._gridUtil._registerEventListener(this._grid, "GroupingDragStart", this._onGroupingDragStartHandler);
			this._headerRowDragStyle = $IG.HeaderDragStyle.Follow;
			this._groupingOn = true;
		}
	}
}
$IG.ColumnMoving.prototype =
{
	
	get_ColumnMoveSettings: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.ColumnMoving.ColumnMoveSettings">
		///Returns an array of the ColumnMoveSettings available.
		///</summary>
		///<value type="Infragistics.Web.UI.ColumnMoveSettings" ></value>
		return this._ColumnMoveSettings;
	},
	

	
	set_HeaderDragMarkup: function (markup)
	{
		///<summary locid="P:J#Infragistics.Web.UI.ColumnMoving.HeaderDragMarkup">
		///Sets the markup that will be used for the drag indicator.
		///</summary>
		///<param name="markup" domElement="true">The custom markup that will be used in place of the header.</param>

		if (!this._currentDraggingAction.dragMarkup)
			return;

		this._container.removeChild(this._currentDraggingAction.dragMarkup);

		this._currentDraggingAction.dragMarkup = markup;
		this._currentDraggingAction.dragMarkup.style.position = "absolute";

		if (this._container.childNodes.length > 0)
			this._container.insertBefore(this._currentDraggingAction.dragMarkup, this._container.firstChild);
		else
			this._container.appendChild(this._currentDraggingAction.dragMarkup);

	},
	get_HeaderDragMarkup: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.ColumnMoving.HeaderDragMarkup">
		///Returns the markup that will be used for the drag indicator.
		///</summary>
		///<returns domElement="true"></returns>

		if (!this._currentDraggingAction.dragMarkup)
			return;

		return this._currentDraggingAction.dragMarkup;
	},
	set_HeaderDragMarkupOpacity: function (opacity)
	{
		///<summary locid="P:J#Infragistics.Web.UI.ColumnMoving.HeaderDragMarkupOpacity">
		///Sets the opacity that will be applied to the header drag markup.
		///</summary>
		///<param name="opacity" type="Number">The new opacity value to be used for the header drag markup</param>

		if (!this._currentDraggingAction.dragMarkup)
			return;

		//this._currentDraggingAction.activeDDBehavior.set_dragMarkupOpacity(opacity);
		this._currentDraggingAction.opacity = opacity;
		$util.setOpacity(this._currentDraggingAction.dragMarkup, this._currentDraggingAction.opacity);

	},
	get_HeaderDragMarkupOpacity: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.ColumnMoving.HeaderDragMarkupOpacity">
		///Returns the opacity that will be applied to the header drag markup.
		///</summary>
		///<value type="Number"></value>

		if (!this._currentDraggingAction.dragMarkup)
			return;

		return this._currentDraggingAction.opacity;
	},
	
	
	dispose: function ()
	{
		///<summary locid="M:J#Infragistics.Web.UI.ColumnMoving.dispose">
		///Disposes of the column moving behavior.
		///</summary>
		if (!this._grid || !this._header)
			return;
		if (this._ColumnMoveSettingSingleton)
		{
			this._ColumnMoveSettingSingleton.onPropertyChanging = null;
			this._ColumnMoveSettingSingleton.dispose();
			this._ColumnMoveSettingSingleton = null;
		}

		for (var i = 0; i < this._dragDropBehaviors.length; i++)
		{
			if (this._hierarchical && this._groupingOn && this._grid && this._grid._get_mainGrid())
				this._grid._get_mainGrid()._decrementMovingBehaviorsCount();
			if (this._dragDropBehaviors[i] && (!this._groupingOn || (this._grid._get_mainGrid() && this._grid._get_mainGrid()._getMovingBehaviorsCount() == 0)))
			{
				this._dragDropBehaviors[i].dispose();
				delete this._dragDropBehaviors[i];
			}
			else if (this._dragDropBehaviors[i])
			{
				var events = this._dragDropBehaviors[i].get_events();
				events.removeDragStartHandler(this._dragStartHandler);
				events.removeDragMoveHandler(this._dragMoveHandler);
				events.removeDragCancelHandler(this._dragCancelHandler);
				events.removeDragEndHandler(this._dragEndHandler);
				events.removeDropHandler(this._dragDropHandler);
			}
		}
		delete this._dragDropBehaviors;
		this._internalColumnSelectionChangingHandler = null;
		this._currentDraggingAction = null;
		this._container = null;
		this._headerRow = null;
		this._header = null;
		this._dataTbl = null;
		this._topDragIndicatorCssClass = null;
		this._middleDragIndicatorCssClass = null;
		this._bottomDragIndicatorCssClass = null;

		if (this._hierarchical)
		{
			if (this._onGroupingDragStartHandler)
			{
				this._grid._gridUtil._unregisterEventListener(this._grid, "GroupingDragStart", this._onGroupingDragStartHandler);
				delete this._onGroupingDragStartHandler;
			}
			if (this._ancestorGridHScrollBars)
			{
				for (var x = 0; x < this._ancestorGridHScrollBars.length; ++x)
					this._ancestorGridHScrollBars[x] = null;
				delete this._ancestorGridHScrollBars;
			}
			if (this._ancestorGridVScrollBars)
			{
				for (var x = 0; x < this._ancestorGridVScrollBars.length; ++x)
					this._ancestorGridVScrollBars[x] = null;
				delete this._ancestorGridVScrollBars;
			}
			if (this._ancestorGridElements)
			{
				for (var x = 0; x < this._ancestorGridElements.length; ++x)
					this._ancestorGridElements[x] = null;
				delete this._ancestorGridElements;
			}
			delete this._hierarchical;
			delete this._groupingOn;
			delete this._hasHorizontalScroll;
		}
		delete this._columnFixing;
		delete this._summaryRow;
		$IG.ColumnMoving.callBaseMethod(this, "dispose");
	},


	_moveColumn: function (startIndex, endIndex, columnObj, sourceColumnRegion)
	{
		///<summary
		/// Moves a WebDataGrid column starting at startIndex and positions it at endIndex.
		/// This method could be used only for client-side sorting when EnableClientRendering
		/// is set to true.
		///</summary>

		var grid = this._grid;
		var startInd = startIndex;
		var endInd = endIndex;
		var index = 0;
		var adjustForCellOffset = true;

		var header = columnObj._headerElement;
		var headerRow = header.parentNode;
		var footer = columnObj._footerElement;
		var footerRow = (footer ? footer.parentNode : null);

		var tableTemplate = $("<div></div>").html(grid._tableTemplate);
		var rowTemplate = tableTemplate[0].firstChild;

		var auxRows = grid._get_auxRows();
		for (var i = 0; i < auxRows.length; i++)
		{
			auxRows[i] = auxRows[i].get_element();
		}

		
		if (this._summaryRow)
		{
			var sumCount = this._summaryRow._maxSumCount;

			for (var i = 0; i < sumCount; i++)
			{
				var sumRowElement = grid._elements["footSumRow" + i];
				if (sumRowElement)
					auxRows[auxRows.length] = sumRowElement;
			}
		}

		if (this._columnFixing)
		{
			if (sourceColumnRegion == $IG.ColRegion.Unfixed)
			{
				adjustForCellOffset = false;
				for (var i = 0; i < rowTemplate.childNodes.length; i++)
				{
					var spanTD = rowTemplate.childNodes[i];
					if (this._columnFixing.__isColSpanForUnfixedCols(spanTD))
					{
						rowTemplate = this._columnFixing.__getTRElemForUnfixedCellsFromSpanTd(spanTD);
						var tmpAuxRows = [];
						for (var j = 0; j < auxRows.length; j++)
						{
							var auxSpanElem = auxRows[j].childNodes[i];
							tmpAuxRows[j] = this._columnFixing.__getTRElemForUnfixedCellsFromSpanTd(auxSpanElem);
						}
						auxRows = tmpAuxRows;
						break;
					}
				}
				startInd = startInd - this._columnFixing.get_leftFixedCount();
				endInd = endInd - this._columnFixing.get_leftFixedCount();
			}
			else if (sourceColumnRegion == $IG.ColRegion.RightFixed && this._columnFixing._unfixedCount > 1)
			{
				var unifxedCount = this._columnFixing._unfixedCount - 1;
				startInd = startInd - unifxedCount;
				endInd = endInd - unifxedCount;
			}
		}
		if (adjustForCellOffset)
		{
			var indexOffset = grid._get_cellIndexOffset();
			startInd += indexOffset;
			endInd += indexOffset;
			index -= indexOffset;
		}

		var column = rowTemplate.childNodes[startInd];

		if (endInd + 1 > rowTemplate.childNodes.length)
		{
			rowTemplate.removeChild(column);
			rowTemplate.appendChild(column);

			headerRow.removeChild(header);
			headerRow.appendChild(header);

			for (var i = 0; i < auxRows.length; i++)
			{
				var auxColumn = auxRows[i].childNodes[startInd];
				auxRows[i].removeChild(auxColumn);
				auxRows[i].appendChild(auxColumn);
			}

			if (footer && footerRow)
			{
				footerRow.removeChild(footer);
				footerRow.appendChild(footer);
			}
		}
		else
		{
			var beforeColumn = rowTemplate.childNodes[endInd];
			rowTemplate.removeChild(column);
			rowTemplate.insertBefore(column, beforeColumn);

			var beforeHeader = headerRow.childNodes[endInd];
			headerRow.removeChild(header);
			headerRow.insertBefore(header, beforeHeader);

			for (var i = 0; i < auxRows.length; i++)
			{
				var auxColumn = auxRows[i].childNodes[startInd];
				var auxBeforeColumn = auxRows[i].childNodes[endInd];
				auxRows[i].removeChild(auxColumn);
				auxRows[i].insertBefore(auxColumn, auxBeforeColumn);
			}

			if (footer && footerRow)
			{
				var beforeFooter = footerRow.childNodes[endInd];
				footerRow.removeChild(footer);
				footerRow.insertBefore(footer, beforeFooter);
			}
		}

		startInd = startIndex;
		endInd = endIndex;

		if (endInd > startInd)
			endInd--;

		var copyColumns = [];
		var numColumns = grid.get_columns().get_length();
		var movedColObj = null;
		for (var i = 0; i < numColumns; i++)
		{
			var currentColumn = grid._gridUtil._getColumnFromVisibleIndex(i);
			copyColumns[i] = currentColumn.get_index();
			if (columnObj == currentColumn)
				movedColObj = copyColumns[i];
		}

		copyColumns.splice(startInd, 1);
		copyColumns.splice(endInd, 0, movedColObj);
		for (var i = 0; i < copyColumns.length; i++)
			grid.get_columns().get_column(copyColumns[i])._set_visibleIndex(i);
		grid._tableTemplate = tableTemplate.html();
		grid._applyClientBinding(true);
	},

	_createCollections: function (collectionsManager)
	{
		this._ColumnMoveSettings = collectionsManager.register_collection(0, $IG.ColumnMoveSettings);
		var collectionItems = collectionsManager._collections[0];
		for (var columnKey in collectionItems)
			this._ColumnMoveSettings._addObject($IG.ColumnMoveSetting, null, columnKey);
		this._ColumnMoveSettingSingleton = this.__createMoveSettingSingleton();
	},
	_initializeComplete: function ()
	{

		if (!this._header)
			return;

		this._summaryRow = this._grid.get_behaviors().get_summaryRow();

		this._columnFixing = this._grid.get_behaviors().getBehaviorFromInterface($IG.IColumnFixingBehavior);
		if (this._hierarchical && this._grid._get_mainGrid().get_gridView()._dragDropGrpBehavior)
		{
			this._dragDropBehaviors[0] = this._grid._get_mainGrid().get_gridView()._dragDropGrpBehavior;
			this._grid._get_mainGrid()._incrementMovingBehaviorsCount();
		}
		else if (this._columnFixing)
		{
			for (var i = 0; i < this._columnFixing.get_headerRegions().length; i++)
				this._dragDropBehaviors[i] = new $IG.DragDropBehavior();
		}
		else
			this._dragDropBehaviors[0] = new $IG.DragDropBehavior();

		this.__createDragDropBehavior();
	},

	

	

	__createDragDropBehavior: function ()
	{
		if (this._headerRow)
		{
			for (var i = this._dragDropBehaviors.length - 1; i >= 0; i--)
			{
				var events = this._dragDropBehaviors[i].get_events();
				this._dragDropBehaviors[i].addTargetElement(document.body, true);
				var headerContent = this._grid._elements["headerContent"];
				var colHeaders = this._columnFixing ? this._columnFixing.get_headerRegions()[i] : headerContent.getElementsByTagName("TH");
				var columnCount = colHeaders.length - 1;
				for (var j = columnCount; j >= 0; j--)
				{
					var canCheck = (colHeaders[j].parentNode && colHeaders[j].parentNode.getAttribute);
					
					for (var k = 0; k < colHeaders[j].childNodes.length; k++)
					{
						if (colHeaders[j].childNodes[k] && (colHeaders[j].childNodes[k].tagName == "SPAN" || colHeaders[j].childNodes[k].tagName == "DIV"))
						{
							if (!canCheck || (canCheck && colHeaders[j].parentNode.getAttribute("mkr") != "sizeHeaderRow"))
								this._dragDropBehaviors[i].addSourceElement(colHeaders[j].childNodes[k]);
						}
					}
					if (!canCheck || (canCheck && colHeaders[j].parentNode.getAttribute("mkr") != "sizeHeaderRow"))
						this._dragDropBehaviors[i].addSourceElement(colHeaders[j]);
				}
				this._dragDropBehaviors[i].addDragChannels([this._grid._id + "_colMovingRegion" + i]);
				this._dragDropBehaviors[i].addDropChannels([this._grid._id + "_colMovingRegion" + i]);
				this._dragDropBehaviors[i].set_moveCursor("default", false);

				this._dragStartHandler = Function.createDelegate(this, this._dragStart);
				events.addDragStartHandler(this._dragStartHandler);
				this._dragMoveHandler = Function.createDelegate(this, this._dragMove);
				events.addDragMoveHandler(this._dragMoveHandler);
				this._dragCancelHandler = Function.createDelegate(this, this._dragCancel);
				events.addDragCancelHandler(this._dragCancelHandler);
				this._dragEndHandler = Function.createDelegate(this, this._dragEnd);
				events.addDragEndHandler(this._dragEndHandler);
				this._dragDropHandler = Function.createDelegate(this, this._dragDrop);
				events.addDropHandler(this._dragDropHandler);

				if ($util.IsFireFox)
					events.__addHandler("_MouseDown", Function.createDelegate(this._grid, this._grid._dragableElemMouseDown));
			}
		}


	},

	__gatherEventArgs: function ()
	{
		return [this, this._currentDraggingAction.currentSourceColumn,
															  this._currentDraggingAction.currentColumnMovingGroup,
															  this._currentDraggingAction.startingWidth,
															  this._currentDraggingAction.currentColumnMovingGroupWidths];
	},

	__createDropIndicator: function ()
	{
		if (this._currentDraggingAction.dropIndicatorCreated)
			return;
		this._currentDraggingAction.topDropIndicator = document.createElement("div");
		this._currentDraggingAction.topDropIndicator.style.position = "absolute";
		this._currentDraggingAction.topDropIndicator.className = this._topDragIndicatorCssClass;

		if (this._container.childNodes.length > 0)
			this._container.insertBefore(this._currentDraggingAction.topDropIndicator, this._container.firstChild);
		else
			this._container.appendChild(this._currentDraggingAction.topDropIndicator);

		this._currentDraggingAction.middleDropIndicator = document.createElement("div");
		this._currentDraggingAction.middleDropIndicator.style.position = "absolute";
		this._currentDraggingAction.middleDropIndicator.className = this._middleDragIndicatorCssClass;

		this._container.insertBefore(this._currentDraggingAction.middleDropIndicator, this._container.firstChild);

		this._currentDraggingAction.bottomDropIndicator = document.createElement("div");
		this._currentDraggingAction.bottomDropIndicator.style.position = "absolute";
		this._currentDraggingAction.bottomDropIndicator.className = this._bottomDragIndicatorCssClass;

		this._container.insertBefore(this._currentDraggingAction.bottomDropIndicator, this._container.firstChild);

		this._currentDraggingAction.dropIndicatorCreated = true;

	},

	__hideDropIndicator: function ()
	{
		if (!this._currentDraggingAction.dropIndicatorCreated)
			return;

		this._currentDraggingAction.topDropIndicator.style.visibility = "hidden";
		this._currentDraggingAction.topDropIndicator.style.display = "none";

		this._currentDraggingAction.middleDropIndicator.style.visibility = "hidden";
		this._currentDraggingAction.middleDropIndicator.style.display = "none";

		this._currentDraggingAction.bottomDropIndicator.style.visibility = "hidden";
		this._currentDraggingAction.bottomDropIndicator.style.display = "none";

		this._currentDraggingAction.dropIndicatorHidden = true;
	},

	__showDropIndicator: function ()
	{
		if (!this._currentDraggingAction.dropIndicatorCreated)
			return;

		this._currentDraggingAction.topDropIndicator.style.visibility = "visible";
		this._currentDraggingAction.topDropIndicator.style.display = "";

		this._currentDraggingAction.middleDropIndicator.style.visibility = "visible";
		this._currentDraggingAction.middleDropIndicator.style.display = "";

		this._currentDraggingAction.bottomDropIndicator.style.visibility = "visible";
		this._currentDraggingAction.bottomDropIndicator.style.display = "";
		this._currentDraggingAction.dropIndicatorHidden = false;
	},

	__destroyDropIndicator: function ()
	{
		this._currentDraggingAction.topDropIndicator = null;

		this._currentDraggingAction.middleDropIndicator = null;

		this._currentDraggingAction.bottomDropIndicator = null;

		this._currentDraggingAction.dropIndicatorCreated = false;
	},

	__createMoveSetting: function ()
	{
		var props = new Array();
		var csm = new $IG.ObjectClientStateManager(props);
		var clientProps = new Array();
		var length = $IG.ColumnMoveSettingProps.Count;
		for (var i = 0; i < length; i++)
			clientProps.push(null);
		props.push(clientProps);
		var ColumnMoveSetting = new $IG.ColumnMoveSetting(null, null, null, null, csm);
		ColumnMoveSetting._set_owner(this);
		return ColumnMoveSetting;
	},
	__createMoveSettingSingleton: function ()
	{   



		var props = new Array();
		var csm = new $IG.ObjectClientStateManager(props);
		var clientProps = new Array();
		var length = $IG.ColumnMoveSettingProps.Count;
		for (var i = 0; i < length; i++)
			clientProps.push(null);
		props.push(clientProps);
		var singleton = new $IG.ColumnMoveSetting(null, null, null, null, csm);
		singleton._set_owner(this);

		singleton["__isSingleton"] = true;
		singleton["__tempColumnId"] = "_Unassigned_";
		singleton.onPropertyChanging = Function.createDelegate(this, this.__propertyChanging);

		return singleton;
	},
	__propertyChanging: function (propName, value)
	{
		
		var exsingleton = this._ColumnMoveSettingSingleton;
		var clientState = exsingleton._csm.get_clientState();
		this._ColumnMoveSettings._addExistingObject(exsingleton, exsingleton["__tempColumnId"], clientState);
		exsingleton["__tempColumnId"] = null;
		this._ColumnMoveSettingSingleton.onPropertyChanging = null;
		
		this._ColumnMoveSettingSingleton = this.__createMoveSettingSingleton();
	},

	__getColumnMoveSettingFromHeader: function (headerElem)
	{
		


		var column = this._grid._gridUtil._getColumnFromHeader(headerElem);
		if (!column) return null;

		var moveSetting = this.get_ColumnMoveSettings()._getObjectByAdr(column.get_key());
		if (moveSetting == null)
		{
			moveSetting = this._ColumnMoveSettingSingleton;
			this._ColumnMoveSettingSingleton.__tempColumnId = column.get_key();
		}
		return moveSetting;
	},

	__getColumnRegionFromHeader: function (headerElem)
	{
		if (this._columnFixing)
		{
			var column = (this._gridHasHeaderLayout ? this._grid._gridUtil._get_HeaderLayoutColumnFromKey(headerElem.getAttribute("key")) : this._grid._gridUtil._getColumnFromHeader(headerElem));
			if (!column)
				return -1;
			var side = (column._parentFixedDir != undefined ? column._parentFixedDir : column._fixedDirection);
			switch (side)
			{
				case 0:
					return $IG.ColRegion.LeftFixed;
					break;
				case 1:
					return $IG.ColRegion.RightFixed;
					break;
				default:
					return $IG.ColRegion.Unfixed;
			}
		}
	},

	__getTargetFromPoint: function (manager, x, y)
	{
		if (!manager._draggingMarkup)
			return;
		
		if (manager._dragShell)
			manager._dragShell.style.display = "none";

		manager._draggingMarkup.style.display = "none";

		var elemAtPoint = manager.elementFromPoint(x, y);

		
		if (manager._dragShell)
			manager._dragShell.style.display = "";

		manager._draggingMarkup.style.display = "";

		return this.__validateElem(manager, elemAtPoint, x, y);
	},

	__validateElem: function (manager, elemAtPoint, x, y)
	{
		

		var headerContent = this._grid._elements["headerContent"];
		var targets = headerContent.getElementsByTagName("TH");
		var count = 0;
		if (this._columnFixing)
		{
			var currentDragRgn = -1;
			if (this._currentDraggingAction.elementDragged)
				currentDragRgn = this.__getColumnRegionFromHeader(this._currentDraggingAction.elementDragged);

			targets = new Array();

			for (var i = 0; i < this._columnFixing.get_headerRegions().length; i++)
			{
				if (currentDragRgn != i)
				{
					for (var j = 0; j < this._columnFixing.get_headerRegions()[i].length; j++)
					{
						targets[count] = this._columnFixing.get_headerRegions()[i][j];
						count++
					}
				}
			}
			if (currentDragRgn != -1 && this._columnFixing.get_headerRegions()[currentDragRgn])
			{
				for (var j = 0; j < this._columnFixing.get_headerRegions()[currentDragRgn].length; j++)
				{
					targets[count] = this._columnFixing.get_headerRegions()[currentDragRgn][j];
					count++
				}
			}
		}


		
		var i = -1;
		count = targets.length;
		var elem = null;
		var headerLeftEdge = null;
		var headerRightEdge = null;
		var headerTopEdge = null;
		var headerBottomEdge = null;

		var gridEdgeLeft = $util.getLocation(this._container).x;
		var gridEdgeRight = gridEdgeLeft + this._container.offsetWidth;

		if (x > gridEdgeRight || x < gridEdgeLeft)
			return null;

		
		while (++i < count)
		{
			elem = targets[i];

			



			
			//headerLeftEdge = /*($util.IsOpera && this._horizontalScrollBar) ? $util.getLocation(elem).x - this._horizontalScrollBar.scrollLeft :*/$util.getLocation(elem).x;
			//headerRightEdge = headerLeftEdge + elem.offsetWidth;
			//headerTopEdge = $util.getLocation(elem).y;
			//headerBottomEdge = headerTopEdge + elem.offsetHeight;
			
			var w, width = elem.offsetWidth, xy = $util.getLocation(elem);
			
			if (width + 3 > elem.parentNode.offsetWidth || $util.getStyleValue(null, "display", elem) == "none")
				width = 0;
			if (width > 200) try
			{
				w = elem.style.width;
				if (w && w.indexOf('px') > 0)
				{
					w = parseFloat(w);
					if (w > 20 && w + 100 < width)
						width = w;
				}
			} catch (ex) { }
			headerLeftEdge = xy.x;
			headerRightEdge = headerLeftEdge + width;
			headerTopEdge = xy.y;
			headerBottomEdge = headerTopEdge + elem.offsetHeight;

			




			if (elemAtPoint)
			{
				if (elem != null && (elem == elemAtPoint || ((elemAtPoint.contains && elemAtPoint.contains(elem)) || (!elemAtPoint.contains && $util.isChild(elemAtPoint, elem)))) && ((headerLeftEdge <= x && x <= headerRightEdge) && (headerTopEdge <= y && y <= headerBottomEdge) && elem.tagName == "TH") || ((headerLeftEdge <= x && x <= headerRightEdge) && (headerTopEdge <= y && y <= headerBottomEdge) && elem.tagName == "TH"))
					return { target: elem, element: elem, elemAtPoint: elemAtPoint };
			}
			else
			{
				

				if ((headerLeftEdge <= x && x <= headerRightEdge) && (headerTopEdge <= y && y <= headerBottomEdge) && elem.tagName == "TH")
					return { target: elem, element: elem, elemAtPoint: elemAtPoint };
			}
		}
		return null;
	},

	__hideDragMarkup: function ()
	{
		var markup = null;
		this.__hideDropIndicator();
		markup = this._currentDraggingAction.dragMarkup;
		markup.style.visibility = "hidden";
		markup.style.display = "none";
	},
	__createDragActionManager: function ()
	{
		// This is a hitTest object.  The idea is that all the info for the current drag is recorded on a single object, so we know
		// across events what we are working with, it should make the dragging cancelable since we can revert things back to where
		// they were. 
		// Should I make a private method to build this?  Yep, that's a good idea.*/
		var _currentDraggingAction = new Object();
		
		_currentDraggingAction.elementDragged = null;

		
		_currentDraggingAction.sourceColumn = null;

		
		_currentDraggingAction.targetColumn = null;

		
		_currentDraggingAction.targetElement = null;

		
		_currentDraggingAction.sourceColumnIndex = null;

		
		_currentDraggingAction.targetColumnIndex = null;

		

		_currentDraggingAction.sourceRegion = null;

		
		_currentDraggingAction.isDragEligible = false;

		
		_currentDraggingAction.opacity = 60;

		
		_currentDraggingAction.dragMarkup = null;

		
		_currentDraggingAction.topDropIndicator = null;
		
		_currentDraggingAction.middleDropIndicator = null;
		
		_currentDraggingAction.bottomDropIndicator = null;

		
		_currentDraggingAction.dropIndicatorCreated = false;

		
		_currentDraggingAction.dragCanceled = false;

		
		_currentDraggingAction.dropIndicatorHidden = false;

		
		_currentDraggingAction.activeDDBehavior = null;

		
		_currentDraggingAction.lastMousePosition_X = null;

		
		_currentDraggingAction._doNotCancelStart = false;

		
		_currentDraggingAction._groupingGrid = null;
		if (this._hierarchical)
			this._grid._get_mainGrid()._groupingGrid = null;

		return _currentDraggingAction;
	},

	_get_verticalAdjust: function (isDrop)
	{
		
		
		
		var gridVScroll = (this._verticalScrollBar && !$util.IsSafari && !$util.IsIE8 && !$util.IsIE9Plus && !$util.IsOpera ? this._verticalScrollBar.scrollTop : 0);
		if (this._hierarchical && this._ancestorGridVScrollBars)
		{
			for (var x = 0; x < this._ancestorGridVScrollBars.length; ++x)
			{
				if (this._ancestorGridVScrollBars[x])
				{
					if (!$util.IsFireFox)
						gridVScroll -= this._ancestorGridVScrollBars[x].scrollTop;
				}
			}
		}
		return gridVScroll;
	},
	_get_horizontalAdjust: function (xPos)
	{
		if (this._hierarchical && this._ancestorGridHScrollBars)
		{
			for (var x = 0; x < this._ancestorGridHScrollBars.length; ++x)
			{
				if (this._ancestorGridHScrollBars[x])
				{
					if (!$util.IsFireFox)
						xPos -= this._ancestorGridHScrollBars[x].scrollLeft;
				}
			}
		}
		return xPos;
	},

	__displayDropIndicator: function (headerElement, targetSide, moveCursor)
	{
		if (!this._currentDraggingAction.elementDragged)
			return;

		this._currentDraggingAction.sourceColumn = this._grid._gridUtil._getColumnFromHeader(this._currentDraggingAction.elementDragged);
		this._currentDraggingAction.targetColumn = this._grid._gridUtil._getColumnFromHeader(headerElement);
		this._currentDraggingAction.targetElement = headerElement;
		if ((this._currentDraggingAction.targetColumn && this._currentDraggingAction.sourceColumn)
			|| (this._gridHasHeaderLayout && this._currentDraggingAction.elementDragged && this._currentDraggingAction.targetElement
			&& this._currentDraggingAction.elementDragged.getAttribute("rgn") != null && this._currentDraggingAction.targetElement.getAttribute("rgn") != null))
		{
			
			if (!this._gridHasHeaderLayout)
				this._currentDraggingAction.sourceColumnIndex = this._currentDraggingAction.sourceColumn.get_visibleIndex();
			else
				this._currentDraggingAction.sourceColumnIndex = parseInt(this._currentDraggingAction.elementDragged.getAttribute("colVsblIdx"));

			if (this._currentDraggingAction.dropIndicatorCreated == false)
				this.__createDropIndicator();
			else if (this._currentDraggingAction.dropIndicatorHidden && moveCursor != "not-allowed")
				this.__showDropIndicator();

			var headerTopEdge = $util.getLocation(this._header).y;

			var headerHeightAdj = 0;
			if (this._gridHasHeaderLayout)
			{
				var dragedKey = this._currentDraggingAction.elementDragged.getAttribute("key");
				var srcColumn = this._grid._gridUtil._get_HeaderLayoutColumnFromKey(dragedKey);
				var elemHeaderTopEdge = $util.getLocation(srcColumn.get_headerElement()).y;
				headerHeightAdj = elemHeaderTopEdge - headerTopEdge;
				headerTopEdge = elemHeaderTopEdge;
			}

			var gridVScroll = this._get_verticalAdjust(true);

			this._currentDraggingAction.topDropIndicator.style.marginTop = headerTopEdge + gridVScroll - this._cntnrLoc.y - ($util.IsIE6 ? Math.round(this._currentDraggingAction.topDropIndicator.offsetHeight / 2) : this._currentDraggingAction.topDropIndicator.offsetHeight) + "px";

			this._currentDraggingAction.middleDropIndicator.style.marginTop = headerTopEdge + gridVScroll - this._cntnrLoc.y + "px";
			this._currentDraggingAction.middleDropIndicator.style.height = this._header.offsetHeight - headerHeightAdj + "px";

			this._currentDraggingAction.bottomDropIndicator.style.marginTop = headerTopEdge + gridVScroll - this._cntnrLoc.y + this._header.offsetHeight - headerHeightAdj + "px";


			var centerAdjustValue = Math.round(this._currentDraggingAction.topDropIndicator.offsetWidth / 2);
			
			
			var headerLeftEdge = $util.getLocation(headerElement).x;

			var gridEdgeLeft = $util.getLocation(this._headerDiv).x;
			var gridEdgeRight = gridEdgeLeft + this._headerDiv.offsetWidth;

			var dropIndicatorPositionX = headerLeftEdge - centerAdjustValue;
			if (targetSide == $IG.TargetSide.Left)
			{
				if (dropIndicatorPositionX < gridEdgeLeft)
					dropIndicatorPositionX = gridEdgeLeft;
				
				if (this._hierarchical && this._ancestorGridElements)
				{
					for (var i = 0; i < this._ancestorGridElements.length; ++i)
					{
						if (this._ancestorGridElements[i])
						{
							var parentGridEdgeLeft = $util.getLocation(this._ancestorGridElements[i]).x;
							if (dropIndicatorPositionX < parentGridEdgeLeft)
							{
								dropIndicatorPositionX = parentGridEdgeLeft;
								break;
							}
						}
					}
				}
				if (!this._gridHasHeaderLayout)
					this._currentDraggingAction.targetColumnIndex = this._currentDraggingAction.targetColumn.get_visibleIndex();
				else
					this._currentDraggingAction.targetColumnIndex = parseInt(this._currentDraggingAction.targetElement.getAttribute("colVsblIdx"));
			}
			else if (targetSide == $IG.TargetSide.Right)
			{
				dropIndicatorPositionX = dropIndicatorPositionX + headerElement.offsetWidth;
				if (dropIndicatorPositionX > gridEdgeRight)
					dropIndicatorPositionX = gridEdgeRight;
				
				if (this._hierarchical && this._ancestorGridElements)
				{
					for (var i = 0; i < this._ancestorGridElements.length; ++i)
					{
						if (this._ancestorGridElements[i])
						{
							var parentGridEdgeLeft = $util.getLocation(this._ancestorGridElements[i]).x;
							var parentGridEdgeRight = parentGridEdgeLeft + this._ancestorGridElements[i].offsetWidth;
							if (dropIndicatorPositionX > parentGridEdgeRight)
							{
								dropIndicatorPositionX = parentGridEdgeRight;
							}
						}
					}
				}
				if (!this._gridHasHeaderLayout)
					this._currentDraggingAction.targetColumnIndex = this._currentDraggingAction.targetColumn.get_visibleIndex() + 1;
				else
					this._currentDraggingAction.targetColumnIndex = parseInt(this._currentDraggingAction.targetElement.getAttribute("colVsblIdx")) + 1;
			}

			
			
			
			var gridScroll = (this._horizontalScrollBar && !this._columnFixing && !$util.IsSafari && !$util.IsIE8 && !$util.IsIE9Plus && !$util.IsOpera) ? this._horizontalScrollBar.scrollLeft : 0;

			
			var xPos = gridScroll + dropIndicatorPositionX - this._cntnrLoc.x;
			xPos = this._get_horizontalAdjust(xPos);
			this._currentDraggingAction.topDropIndicator.style.marginLeft = xPos + "px";
			this._currentDraggingAction.middleDropIndicator.style.marginLeft = xPos + "px";
			this._currentDraggingAction.bottomDropIndicator.style.marginLeft = xPos + "px";
		}
		else
		{
			


			if (headerElement.nextSibling)
			{
				this._currentDraggingAction.targetColumn = this._grid._gridUtil._getColumnFromHeader(headerElement.nextSibling);
				this._currentDraggingAction.targetElement = headerElement.nextSibling;
			}
		}
	},
	
	_isInThisGridHeader: function (headerTH)
	{
		var header = headerTH.parentNode;
		while (!(header.getAttribute && header.getAttribute('mkr') == "header"))
			header = header.parentNode;
		return header == this._grid._elements["header"];
	},

	
	

	
	
	_dragStart: function (behavior, evntArgs)
	{
		
		if (this._grid._get_isAjaxCallInProgress() || (this._hierarchical && this._grid._get_mainGrid() && this._grid._get_mainGrid()._get_isAjaxCallInProgress()))
			return;
		
		
		var target = evntArgs.get_manager().get_sourceElement();
		while (target.tagName != "TH" && target.parentNode)
			target = target.parentNode;

		if (!target || target.tagName != "TH")
			return;

		//If we're resizing I need to come up with a way to determine when our drag event will be canceled.
		//ColumnResizing checks for a border, if there is none they give a 3px area where clicking and dragging will
		//trigger a resize operation.  So I need to do the opposite here, grabbing a border, or anywhere a border should
		//be will not trigger a move.

		
		if (this._hierarchical)
			this._getScrollBarElements();

		var elemBounds = Sys.UI.DomElement.getBounds(target);
		this._cntnrLoc = $util.getLocation(this._container);
		this._headerBounds = Sys.UI.DomElement.getBounds(this._header);

		var brw = $util.getStyleValue(null, "borderRightWidth", target);
		brw = parseInt(brw);
		if (isNaN(brw))
			brw = 3;
		else if (brw < 3) brw = 3;
		var blw = 3;
		blw = $util.getStyleValue(null, "borderLeftWidth", target);
		blw = parseInt(blw);
		if (isNaN(blw))
			blw = 3;
		else
			if (blw < 3)
				blw = 3;

		
		var rightBorderPos = elemBounds.x + elemBounds.width - brw - 1;

		
		if ((this._groupingOn && this._currentDraggingAction._groupingGrid != this._grid) || (this._hierarchical && !this._groupingOn && (this._grid._get_mainGrid()._groupingGrid || !this._isInThisGridHeader(target))))
			return;
		this._currentDraggingAction.elementDragged = target;
		this._currentDraggingAction.sourceColumn = this._grid._gridUtil._getColumnFromHeader(this._currentDraggingAction.elementDragged);

		var columnSetting = null;
		if (this._currentDraggingAction.sourceColumn)
			columnSetting = this._ColumnMoveSettings.getItemFromColumnKey(this._currentDraggingAction.sourceColumn.get_key());
		var dragedKey = null;
		if (this._gridHasHeaderLayout)
		{
			dragedKey = this._currentDraggingAction.elementDragged.getAttribute("key");
			this._currentDraggingAction.sourceColumn = this._grid.get_columns().get_columnFromKey(dragedKey);
			columnSetting = this._ColumnMoveSettings.getItemFromColumnKey(dragedKey);
		}

		this._paddingTop = 0;
		if (this._currentDraggingAction.sourceColumn)
		{
			var headerElem = this._currentDraggingAction.sourceColumn.get_headerElement();
			this._paddingTop = Sys.UI.DomElement.getBounds(headerElem).y - this._headerBounds.y;
		}
		else if (this._gridHasHeaderLayout && !this._currentDraggingAction.elementDragged.getAttribute("grpFld") && this._currentDraggingAction.elementDragged)
		{
			this._paddingTop = Sys.UI.DomElement.getBounds(this._currentDraggingAction.elementDragged).y - this._headerBounds.y;
		}
		
		
		var leftBorderArea = Math.abs(evntArgs.get_x() - elemBounds.x);
		
		if (this._grid._mouseBetweenColumns || evntArgs.get_x() >= rightBorderPos || leftBorderArea <= blw || (!this._currentDraggingAction.sourceColumn && (this._gridHasHeaderLayout && (!this._currentDraggingAction.elementDragged || (this._currentDraggingAction.elementDragged && !this._currentDraggingAction.elementDragged.getAttribute("grpFld")))))
			|| (columnSetting && !columnSetting.get_enableMove()))
		{
			evntArgs.set_cancel(!this._currentDraggingAction._doNotCancelStart);
			return;
		}		
		behavior.set_dragMarkup(document.createElement("div"));

		this.__createHeader();
		var dragMarkup = this._currentDraggingAction.dragMarkup;

		dragMarkup.style.width = this._currentDraggingAction.elementDragged.offsetWidth + "px";
		var dragMarkupHeight = this._header.offsetHeight;
		var headerHeight = dragMarkupHeight;
		this.__parentHeight = 0;
		if (this._gridHasHeaderLayout)
		{
			var headerLayoutColumn = this._grid._gridUtil._get_HeaderLayoutColumnFromKey(dragedKey);
			if (headerLayoutColumn)
			{
				var columnOwner = headerLayoutColumn._get_parent();
				while (columnOwner != this._grid)
				{
					this.__parentHeight += columnOwner.get_headerElement().offsetHeight;
					columnOwner = columnOwner._get_parent();
				}
			}
			dragMarkupHeight -= this.__parentHeight;
		}
		dragMarkup.style.height = dragMarkupHeight + "px";

		if (this._dragMarkupCssClass)
			dragMarkup.firstChild.className = this._dragMarkupCssClass;
		else
		{
			dragMarkup.firstChild.firstChild.className = this._header.className;
			dragMarkup.firstChild.firstChild.firstChild.className = this._currentDraggingAction.elementDragged.className;
		}
		dragMarkup.firstChild.firstChild.firstChild.innerHTML = this._currentDraggingAction.elementDragged.innerHTML;
		
		this._cleanupDragMarkup(dragMarkup);

		var y;
		var gridVScroll = this._get_verticalAdjust(false);

		if (this._headerRowDragStyle == $IG.HeaderDragStyle.Slide && (this._currentDraggingAction.sourceColumn || (this._gridHasHeaderLayout && !this._currentDraggingAction.elementDragged.getAttribute("grpFld") && this._currentDraggingAction.elementDragged)))
			y = this._headerBounds.y + gridVScroll - this._cntnrLoc.y - this._paddingTop + 2 * this.__parentHeight + "px";
		else
			y = evntArgs.get_y() + gridVScroll - this._cntnrLoc.y - this._paddingTop - Math.round(headerHeight / 2) + this.__parentHeight + "px";


		dragMarkup.style.marginTop = y;
		
		var xPos = evntArgs.get_x() - this._cntnrLoc.x - Math.round(dragMarkup.offsetWidth / 2);
		xPos = this._get_horizontalAdjust(xPos);
		dragMarkup.style.marginLeft = xPos + "px";


		var args = this.__raiseClientEvent("HeaderDragStart", $IG.HeaderDragStartEventArgs, [this,
				   this._currentDraggingAction.sourceColumn,
				   false]);
		if (args != null && args.get_cancel())
		{
			this._currentDraggingAction.dragCanceled = true;
			this.__hideDragMarkup();
			evntArgs.set_cancel(true);
			return;
		}
		this._currentDraggingAction.dragCanceled = false;

		this._currentDraggingAction.activeDDBehavior = behavior;

		

		if (this._GridScrollTimerId == null && !$util.IsOpera)
			this._GridScrollTimerId = setInterval(Function.createDelegate(this, this.__scrollColumnIntoView), 50);


	},
	
	_cleanupDragMarkup: function (markup)
	{
		var childNodes = markup.childNodes;
		var childCount = childNodes.length;
		for (var x = childCount - 1; x >= 0; --x)
		{
			var child = childNodes[x];
			if (child && child.tagName == "INPUT" && child.type == "hidden")
				markup.removeChild(child);
			this._cleanupDragMarkup(child);
		}
	},
	_dragMove: function (behavior, evntArgs)
	{
		
		if (!this._currentDraggingAction || !this._currentDraggingAction.activeDDBehavior)
			return;
		var args = this.__raiseClientEvent("HeaderMove", $IG.HeaderMoveEventArgs, [this,
		this._currentDraggingAction.sourceColumn,
		this._currentDraggingAction.dragMarkup,
		false]);
		if (args != null && args.get_cancel())
		{
			evntArgs.get_manager().endDrag(true);
			return;
		}

		var headerDragElement = this._currentDraggingAction.dragMarkup;
		if (!headerDragElement)
			return;

		
		
		
		
		var mousePosition_X = (this._horizontalScrollBar && !this._columnFixing && !$util.IsSafari && !$util.IsIE8 && !$util.IsIE9Plus && !$util.IsOpera) ? evntArgs.get_x() + this._horizontalScrollBar.scrollLeft : evntArgs.get_x();
		var gridVScroll = this._get_verticalAdjust(false);
		var mousePosition_Y = evntArgs.get_y();

		
		this._currentDraggingAction.lastMousePosition_X = evntArgs.get_x();

		var topEdge = $util.getLocation(this._headerRow).y;
		var bottomEdge = $util.getLocation(this._headerRow).y + this._headerRow.offsetHeight;


		var verticalMidPointOnHeader = Math.round((topEdge + bottomEdge) / 2);

		var y;

		
		if (this._headerRowDragStyle == $IG.HeaderDragStyle.Slide && (this._currentDraggingAction.sourceColumn || (this._gridHasHeaderLayout && !this._currentDraggingAction.elementDragged.getAttribute("grpFld") && this._currentDraggingAction.elementDragged)))
			y = this._headerBounds.y + gridVScroll - this._cntnrLoc.y - this._paddingTop + 2 * this.__parentHeight + "px";
		else
			y = evntArgs.get_y() + gridVScroll - this._cntnrLoc.y - this._paddingTop - Math.round(headerDragElement.offsetHeight / 2) + this.__parentHeight + "px";

		headerDragElement.style.marginTop = y;
		
		
		var xPos = mousePosition_X - this._cntnrLoc.x - Math.round(headerDragElement.offsetWidth / 2);
		xPos = this._get_horizontalAdjust(xPos);
		headerDragElement.style.marginLeft = xPos + "px";

		//if (this._headerRowDragStyle == $IG.HeaderDragStyle.Slide && this._currentDraggingAction.sourceColumn)
		//{
		
		//	headerDragElement.style.top = $util.getLocation(this._header).y - (parseInt($util.getStyleValue(null, "paddingBottom", this._currentDraggingAction.sourceColumn.get_headerElement())) + parseInt($util.getStyleValue(null, "paddingTop", this._currentDraggingAction.sourceColumn.get_headerElement()))) + "px";
		//}

		var headerElement = this.__getTargetFromPoint(evntArgs.get_manager(), evntArgs.get_x(),
			(!this._gridHasHeaderLayout ? verticalMidPointOnHeader : evntArgs.get_y()));
		if (headerElement == null)
			return;

		headerElement = headerElement.element;
		//var headerElement = this.__getTargetFromPoint(evntArgs.get_manager(), evntArgs.get_x(), /*verticalMidPointOnHeader*/evntArgs.get_y()).element;

		var headerElementoffsetLeft = $util.getLocation(headerElement).x;
		var headerElementoffsetWidth = headerElement.offsetWidth;

		var horizontalMidPointOnHeader = Math.round(headerElementoffsetLeft + Math.round(headerElementoffsetWidth / 2));

		if (this._groupingOn && this._grid._get_mainGrid().get_gridView()._overGroupArea)
		{
			this.__hideDropIndicator();
			return;
		}

		if (horizontalMidPointOnHeader != null)
		{
			if (evntArgs.get_x() < horizontalMidPointOnHeader)//Left side of target column.
				this.__displayDropIndicator(headerElement, $IG.TargetSide.Left, behavior._moveCursor);
			else //Right side of target column.
				this.__displayDropIndicator(headerElement, $IG.TargetSide.Right, behavior._moveCursor);

		}
		if (this._gridHasHeaderLayout && headerElement.getAttribute("rgn") != null)
		{
			if (headerElement.getAttribute("rgn") != this._currentDraggingAction.elementDragged.getAttribute("rgn") ||
				(this._columnFixing && this.__getColumnRegionFromHeader(headerElement) != this.__getColumnRegionFromHeader(this._currentDraggingAction.elementDragged)))
			{
				behavior.set_moveCursor("not-allowed", false);
				this.__hideDropIndicator();
			}
			else
			{
				behavior.set_moveCursor("default", false);
				this.__showDropIndicator();
			}
		}
		else if (this._columnFixing)
		{
			if (!this._currentDraggingAction.sourceColumn || !this._currentDraggingAction.targetColumn)
				return;
			var sourceColumnRegion = this.__getColumnRegionFromHeader(this._currentDraggingAction.sourceColumn.get_headerElement());
			var targetColumnRegion = this.__getColumnRegionFromHeader(this._currentDraggingAction.targetColumn.get_headerElement());
			if (sourceColumnRegion != targetColumnRegion)
			{
				behavior.set_moveCursor("not-allowed", false);
				
				this.__hideDropIndicator();
			}
			else
			{
				behavior.set_moveCursor("default", false);
				
				this.__showDropIndicator();
			}
		}

		if (this._headerRowDragStyle == $IG.HeaderDragStyle.Slide)
		{

			var headerRowHeight = (this._gridHasHeaderLayout ? this._header.offsetHeight : this._headerRow.offsetHeight);
			var topBuffer = verticalMidPointOnHeader - (headerRowHeight * 3) <= 0 ? 0 : verticalMidPointOnHeader - (headerRowHeight * 3);
			var bottomBuffer = verticalMidPointOnHeader + (headerRowHeight * 3) <= 0 ? 0 : verticalMidPointOnHeader + (headerRowHeight * 3);
			if (mousePosition_Y < topBuffer || mousePosition_Y > bottomBuffer)
			{
				this.__hideDragMarkup();
			}
			else
			{
				
				if (behavior._moveCursor != "not-allowed")
					this.__showDropIndicator();

				markup = this._currentDraggingAction.dragMarkup;
				markup.style.visibility = "visible";
				markup.style.display = "";
			}

		}

	},


	_dragCancel: function (behavior, evntArgs)
	{
		this._currentDraggingAction.dragCanceled = true;
		this._currentDraggingAction._groupingGrid = null;
		if (this._hierarchical)
			this._grid._get_mainGrid()._groupingGrid = null;
	},
	_dragEnd: function (behavior, evntArgs)
	{
		
		if (!this._currentDraggingAction || !this._currentDraggingAction.activeDDBehavior)
			return;
		if (this._GridScrollTimerId != null)
			this._GridScrollTimerId = clearInterval(this._GridScrollTimerId);
		if (this._currentDraggingAction.dragMarkup)
		{
			this._container.removeChild(this._currentDraggingAction.dragMarkup);
			this._currentDraggingAction.dragMarkup = null;
		}
		this.__hideDropIndicator();
		this.__raiseClientEvent("HeaderDragEnd", $IG.HeaderDragEndEventArgs, [this,
				   this._currentDraggingAction.dragCanceled,
				   false]);
	},

	__createHeader: function ()
	{
		var table = document.createElement("TABLE");
		var row = table.insertRow(-1);
		var cell = row.appendChild(document.createElement("TH"));
		table.vAlign = "top";
		table.style.position = "absolute";
		table.childNodes[0].style.height = "100%";
		cell.style.height = "100%";
		if (this._container.childNodes.length > 0)
			this._container.insertBefore(table, this._container.firstChild);
		else
			this._container.appendChild(table);
		$util.setOpacity(table, this._currentDraggingAction.opacity);
		this._currentDraggingAction.dragMarkup = table;
	},

	__scrollColumnIntoView: function ()
	{
		
		if (this._hierarchical)
		{
			if (!this._hasHorizontalScroll)
				return;
			var scrollContainer = this._container;
			var edgeLeft = gridEdgeLeft = $util.getLocation(scrollContainer).x;
			var edgeRight = gridEdgeRight = gridEdgeLeft + scrollContainer.offsetWidth;
			var maxScroll = this._horizontalScrollBar.scrollWidth - this._horizontalScrollBar.clientWidth;
			var lefts = [];
			var rights = [];
			if (this._ancestorGridElements)
			{
				for (var x = 0, y = this._ancestorGridElements.length - 1; x < this._ancestorGridElements.length && y >= 0; ++x, --y)
				{
					if (this._ancestorGridElements[x])
					{
						var tempEdgeLeft = $util.getLocation(this._ancestorGridElements[x]).x;
						lefts[x] = tempEdgeLeft;
						if (tempEdgeLeft > edgeLeft)
							edgeLeft = tempEdgeLeft;
						var tempEdgeRight = tempEdgeLeft + this._ancestorGridElements[x].offsetWidth;
						rights[x] = tempEdgeRight;
						if (tempEdgeRight < edgeRight)
							edgeRight = tempEdgeRight;
					}
				}
			}
			var whdgElement = this._grid._get_mainGrid()._element;
			var whdgEdgeLeft = $util.getLocation(whdgElement).x;
			var whdgEdgeRight = whdgEdgeLeft + whdgElement.offsetWidth;
			if (this._currentDraggingAction.lastMousePosition_X < edgeLeft)
			{
				for (var i = this._ancestorGridHScrollBars.length - 1; i >= -1; --i)
				{
					if (i > -1)
					{
						if (this._ancestorGridHScrollBars[i] && (gridEdgeLeft < whdgEdgeLeft || gridEdgeLeft < lefts[i]) && this._ancestorGridHScrollBars[i].scrollLeft > 0)
						{
							this._ancestorGridHScrollBars[i].scrollLeft = (this._ancestorGridHScrollBars[i].scrollLeft - 20) < 0 ? 0 : this._ancestorGridHScrollBars[i].scrollLeft - 20;
							break;
						}
					}
					else if (this._horizontalScrollBar.scrollLeft > 0)
					{
						this._horizontalScrollBar.scrollLeft = (this._horizontalScrollBar.scrollLeft - 20) < 0 ? 0 : this._horizontalScrollBar.scrollLeft - 20;
					}
				}
			}
			if (this._currentDraggingAction.lastMousePosition_X > edgeRight)
			{
				for (var i = 0; i <= this._ancestorGridHScrollBars.length; ++i)
				{
					if (i < this._ancestorGridHScrollBars.length)
					{
						if (this._ancestorGridHScrollBars[i] && (gridEdgeRight > whdgEdgeRight || gridEdgeRight > rights[i]))
						{
							maxScroll = this._ancestorGridHScrollBars[i].scrollWidth - this._ancestorGridHScrollBars[i].clientWidth;
							if (this._ancestorGridHScrollBars[i].scrollLeft < maxScroll)
							{
								this._ancestorGridHScrollBars[i].scrollLeft = (this._ancestorGridHScrollBars[i].scrollLeft + 20) > maxScroll ? maxScroll : this._ancestorGridHScrollBars[i].scrollLeft + 20;
								break;
							}
						}
					}
					else if (this._horizontalScrollBar.scrollLeft < maxScroll)
					{
						this._horizontalScrollBar.scrollLeft = (this._horizontalScrollBar.scrollLeft + 20) > maxScroll ? maxScroll : this._horizontalScrollBar.scrollLeft + 20;
					}
				}
			}
			this._cntnrLoc = $util.getLocation(this._container);
		}
		else
		{
			if (!this._horizontalScrollBar)
				return;

			var scrollContainer = this._columnFixing ? this._columnFixing.__getFirstScrollDiv() : this._container;
			var gridEdgeLeft = $util.getLocation(scrollContainer).x;
			var gridEdgeRight = gridEdgeLeft + scrollContainer.offsetWidth;
			var maxScroll = this._horizontalScrollBar.scrollWidth - this._horizontalScrollBar.clientWidth;

			if (this._currentDraggingAction.lastMousePosition_X < gridEdgeLeft && this._horizontalScrollBar.scrollLeft > 0)
				this._horizontalScrollBar.scrollLeft = (this._horizontalScrollBar.scrollLeft - 20) < 0 ? 0 : this._horizontalScrollBar.scrollLeft - 20;

			if (this._currentDraggingAction.lastMousePosition_X > gridEdgeRight && this._horizontalScrollBar.scrollLeft < maxScroll)
				this._horizontalScrollBar.scrollLeft = (this._horizontalScrollBar.scrollLeft + 20) > maxScroll ? maxScroll : this._horizontalScrollBar.scrollLeft + 20;
		}
	},

	

	__altRaiseClientEvent: function ()
	{
		args = new $IG.HeaderDroppedEventArgs([this,
			this._currentDraggingAction.sourceColumn,
			this._currentDraggingAction.targetColumnIndex,
			false]);
		args._props[1] = 2;
		this._owner._raiseClientEventEnd(args);
	},

	_dragDrop: function (behavior, evntArgs)
	{
		this._currentDraggingAction._groupingGrid = null;
		if (this._hierarchical)
			this._grid._get_mainGrid()._groupingGrid = null;

		//If the source or target column are null we have a problem.
		if ((!this._gridHasHeaderLayout && (!this._currentDraggingAction.sourceColumn || !this._currentDraggingAction.targetColumn))
			|| (this._gridHasHeaderLayout && (!this._currentDraggingAction.elementDragged || !this._currentDraggingAction.targetElement)))
			return;

		var sourceColumnRegion = null;
		//If column fixing is enabled we should ensure that the columns being moved belong to the same region.
		if (this._columnFixing)
		{
			var srcElem = (this._gridHasHeaderLayout ? this._currentDraggingAction.elementDragged : this._currentDraggingAction.sourceColumn.get_headerElement());
			var trgElem = (this._gridHasHeaderLayout ? this._currentDraggingAction.targetElement : this._currentDraggingAction.targetColumn.get_headerElement());
			sourceColumnRegion = this.__getColumnRegionFromHeader(srcElem);
			var targetColumnRegion = this.__getColumnRegionFromHeader(trgElem);
			if (sourceColumnRegion != targetColumnRegion)
				return;
		}
		if (this._gridHasHeaderLayout && this._currentDraggingAction.elementDragged.getAttribute("rgn") !=
			this._currentDraggingAction.targetElement.getAttribute("rgn"))
			return;

		//If there's no drop indicator then just cancel the move.
		if (this._currentDraggingAction.dropIndicatorHidden)
			return;

		//Don't move a column to it's original position.
		if ((this._currentDraggingAction.targetColumnIndex == this._currentDraggingAction.sourceColumnIndex) || (this._currentDraggingAction.targetColumnIndex == this._currentDraggingAction.sourceColumnIndex + 1))
			return;

		if (this._hierarchical && this._grid._overGroupArea)
			return;

		args = this.__raiseClientEvent("HeaderDropped", $IG.HeaderDroppedEventArgs, [this,
			this._currentDraggingAction.sourceColumn,
			this._currentDraggingAction.targetColumnIndex,
			false]);

		if (args != null && args.get_cancel())
		{
			evntArgs.get_manager().endDrag(true);
			this._currentDraggingAction.dragCanceled = true;
			return;
		}

		var columnMoveSerial = { "SourceColumn": (!this._gridHasHeaderLayout ? this._currentDraggingAction.sourceColumn.get_key() : this._currentDraggingAction.elementDragged.getAttribute("key")),
			"OriginalIndex": this._currentDraggingAction.sourceColumnIndex, "TargetIndex": this._currentDraggingAction.targetColumnIndex
		};

		if (this._hierarchical && !this._autoGenCols && this._grid._get_band()._hasColumnWithKey((!this._gridHasHeaderLayout ? this._currentDraggingAction.sourceColumn.get_key() : this._currentDraggingAction.elementDragged.getAttribute("key"))))
		{
			var mainGrid = this._grid._get_mainGrid();
			var actionInfo = new Object();
			actionInfo.bandAdr = this._grid._get_band()._get_bandIndexAddress();
			actionInfo.moveInfo = columnMoveSerial;
			actionInfo.gridAdr = "";
			var action = new $IG.HierarchicalGridAction("moveCol", mainGrid, actionInfo);
			mainGrid._actionList.add_transaction(action);
			mainGrid._postAction((mainGrid._enableAjax ? 2 : 1));
		}
		else
		{
			if (this._owner.get_enableClientRendering() && !this._gridHasHeaderLayout)
				this._moveColumn(columnMoveSerial.OriginalIndex, columnMoveSerial.TargetIndex, this._currentDraggingAction.sourceColumn, sourceColumnRegion);
			else
			{
				this._owner._actionList.add_transaction(new $IG.GridAction("HeaderDropped", this.get_name(), this, Sys.Serialization.JavaScriptSerializer.serialize(columnMoveSerial),
					(!this._gridHasHeaderLayout ? this._currentDraggingAction.sourceColumn.get_key() : this._currentDraggingAction.elementDragged.getAttribute("key")))
					, true);

				if (!this._grid._enableAjax)
					this._owner._postAction(1);
				else
				{
					if (!$util.IsSafari)
					{
						args = new $IG.HeaderDroppedEventArgs([this,
			this._currentDraggingAction.sourceColumn,
			this._currentDraggingAction.targetColumnIndex,
			false]);
						args._props[1] = 2;
						this._owner._raiseClientEventEnd(args);

					}
					else 
						setTimeout(Function.createDelegate(this, this.__altRaiseClientEvent), 50);
				}
			}
		}

	},

	

	_onGroupingDragStart: function (args)
	{
		this._currentDraggingAction._groupingGrid = args.grid;
		this._grid._get_mainGrid()._groupingGrid = args.grid;
		if (this._hierarchical && this._grid._band == args.band)
		{
			args.movingAllowed = this._ColumnMoveSettings.getItemFromColumnKey(args.column.get_key()).get_enableMove();
			this._currentDraggingAction._doNotCancelStart = args.doNotcancel;
		}
	},
	
	_getScrollBarElements: function ()
	{
		if (this._initializedScrollElements || !this._hierarchical)
			return;
		this._initializedScrollElements = true;
		if (this._ancestorGridHScrollBars == null)
			this._ancestorGridHScrollBars = [];
		if (this._ancestorGridVScrollBars == null)
			this._ancestorGridVScrollBars = [];
		if (this._ancestorGridElements == null)
			this._ancestorGridElements = [];
		var parentRow = this._grid.get_parentRow();
		this._hasHorizontalScroll = this._horizontalScrollBar != null;
		while (parentRow != null)
		{
			var grid = parentRow.get_grid();
			this._ancestorGridHScrollBars[this._ancestorGridHScrollBars.length] = grid._elements["hScrBar"];
			this._hasHorizontalScroll = this._hasHorizontalScroll && grid._elements["hScrBar"] != null;
			this._ancestorGridVScrollBars[this._ancestorGridVScrollBars.length] = grid._elements["vScrBar"];
			this._ancestorGridElements[this._ancestorGridElements.length] = grid._elements["container"];
			parentRow = grid.get_parentRow();
		}
	}
}

$IG.ColumnMoving.registerClass('Infragistics.Web.UI.ColumnMoving', $IG.GridBehavior, $IG.IColumnMovingBehavior);


$IG.HeaderDragStartEventArgs = function (args)
{
	///<summary locid="T:J#Infragistics.Web.UI.HeaderDragStartEventArgs">
	///Event arguments object that is passed into the PageIndexChanging event handler.
	///</summary>	

	// First parameter of the event args object associated with the 
	// behavior must be a reference to the behavior itself. This is essential
	// for proper async call back handling.
	$IG.HeaderDragStartEventArgs.initializeBase(this, [args[0]]);
	this._sourceColumn = args[1];

}
$IG.HeaderDragStartEventArgs.prototype =
{
	get_column: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.HeaderDragStartEventArgs.column">
		///Returns which column is being used as the drag source for the move action.
		///</summary>
		///<value type="Infragistics.Web.UI.GridColumn"></value>
		return this._sourceColumn;
	}
}
$IG.HeaderDragStartEventArgs.registerClass('Infragistics.Web.UI.HeaderDragStartEventArgs', $IG.CancelBehaviorEventArgs);




$IG.HeaderDroppedEventArgs = function (args)
{
	$IG.HeaderDroppedEventArgs.initializeBase(this, [args[0]]);
	this._sourceColumn = args[1];
	this._targetIndex = args[2];
	this._cancelled = args[3];
	this._context = {};
	this._context["behavior"] = args[0].get_name();
	this._name = "HeaderDropped";
}
$IG.HeaderDroppedEventArgs.prototype =
{
	get_column: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.HeaderDragStartEventArgs.column">
		///Returns the column which is being used as the drag source for the move action.
		///</summary>
		///<value type="Infragistics.Web.UI.GridColumn"></value>
		return this._sourceColumn;
	},

	get_targetIndex: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.HeaderDragStartEventArgs.targetIndex">
		///Returns the index that the column is being moved to.
		///</summary>
		///<value type="Number" integer="true"></value>
		return this._targetIndex;
	},

	get_cancelled: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.HeaderDragStartEventArgs.cancelled">
		/// Returns if the move action was cancelled.
		///</summary>
		///<value type="Boolean"></value>
		return this._cancelled;
	}
}
$IG.HeaderDroppedEventArgs.registerClass('Infragistics.Web.UI.HeaderDroppedEventArgs', $IG.CancelBehaviorEventArgs);


$IG.HeaderMoveEventArgs = function (args)
{
	///<summary locid="T:J#Infragistics.Web.UI.HeaderMoveEventArgs">
	///Event arguments object that is passed into the PageIndexChanging event handler.
	///</summary>	
	



	$IG.HeaderMoveEventArgs.initializeBase(this, [args[0]]);
	this._sourceColumn = args[1];
	this._dragElement = args[2];
}
$IG.HeaderMoveEventArgs.prototype =
{
	get_column: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.HeaderMoveEventArgs.column">
		///Returns which column is being used as the drag source for the move action.
		///</summary>
		///<value type="Infragistics.Web.UI.GridColumn"></value>
		return this._sourceColumn;
	},
	get_dragElement: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.HeaderMoveEventArgs.dragElement">
		/// Returns the drag markup element.
		///</summary>
		///<returns domElement="true"></returns>
		return this._dragElement;
	}
}
$IG.HeaderMoveEventArgs.registerClass('Infragistics.Web.UI.HeaderMoveEventArgs', $IG.CancelBehaviorEventArgs);


$IG.HeaderDragEndEventArgs = function (args)
{
	$IG.HeaderDragEndEventArgs.initializeBase(this, [args[0]]);
	this._moveCanceled = args[1];

}
$IG.HeaderDragEndEventArgs.prototype =
{
	get_moveCanceled: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.HeaderMoveEventArgs.moveCanceled">
		///Returns true if the move operation was canceled at any point, false otherwise.
		///</summary>
		///<value type="Boolean"></value>
		return this._moveCanceled;
	}
}
$IG.HeaderDragEndEventArgs.registerClass('Infragistics.Web.UI.HeaderDragEndEventArgs', $IG.EventArgs);


$IG.ColumnMoveSettings = function (control, clientStateManager, index, manager)
{
	/// <summary locid="T:J#Infragistics.Web.UI.ColumnMoveSettings">
	/// A collection of ColumnMoveSetting objects.
	/// </summary>
	$IG.ColumnMoveSettings.initializeBase(this, [control, clientStateManager, index, manager]);
}
$IG.ColumnMoveSettings.prototype =
{
	getItemFromColumnKey: function (columnKey)
	{
		///<summary locid="M:J#Infragistics.Web.UI.ColumnMoveSettings.getItemFromColumnKey">
		///Returns the ColumnMoveSetting with the specified column key
		///</summary>
		///<param name="columnKey" type="String">The key of the column to return the settings for.</param>
		///<returns type="Infragistics.Web.UI.ColumnMoveSetting"></returns>
		var moveSetting = this._getObjectByAdr(columnKey);

		if (!moveSetting && (this._control._grid.get_columns().get_columnFromKey(columnKey) || this._control._grid._gridUtil._get_HeaderLayoutColumnFromKey(columnKey)))
		{
			moveSetting = this._control.__createMoveSetting();

			var clientState = moveSetting._csm.get_clientState();

			this._addExistingObject(moveSetting, columnKey, clientState);
			
		}
		return moveSetting;
	}
}
$IG.ColumnMoveSettings.registerClass('Infragistics.Web.UI.ColumnMoveSettings', $IG.ObjectCollection);


$IG.ColumnMoveSetting = function (adr, element, props, owner, csm)
{
	/// <summary locid="T:J#Infragistics.Web.UI.ColumnMoveSetting">
	/// ColumnMoveSetting object of the grid. 
	/// </summary>
	$IG.ColumnMoveSetting.initializeBase(this, [adr, element, props, owner, csm]);

	
	this.__isDirty = false;
}
$IG.ColumnMoveSetting.prototype =
{
	__set_property: function (propName, value, fireEvent)
	{
		if (fireEvent)
		{
			


			if (this.onPropertyChanging)
			{
				this.onPropertyChanging(propName);
			}
		}
		this._set_value(propName, value);
	},
	get_enableMove: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.ColumnMoveSetting.enableMove">
		/// Returns the EnableMove value from the ColumnMoveSetting object.
		///</summary>
		///<value type="Boolean"></value>
		return this._get_value($IG.ColumnMoveSettingProps.EnableMove, true);
	},
	set_enableMove: function (value)
	{
		///<summary locid="P:J#Infragistics.Web.UI.ColumnMoveSetting.enableMove">
		/// Sets the EnableMove value from the ColumnMoveSetting object.
		///</summary>
		///<param name="value" type="Boolean">The new value for enabling moving on the column</param>
		this.__set_property($IG.ColumnMoveSettingProps.EnableMove, value, true);
	},

	onPropertyChanging: function (propName)
	{
	}
}
$IG.ColumnMoveSetting.registerClass('Infragistics.Web.UI.ColumnMoveSetting', $IG.ColumnSetting);



$IG.ColumnMoveSettingProps = new function ()
{
	var count = $IG.ColumnSettingProps.Count;
	this.EnableMove = [count++, true];
	this.Count = count;
};


$IG.HeaderDragStyle = function ()
{
	///<summary locid="T:J#Infragistics.Web.UI.HeaderDragStyle">
	/// The drag style of the header element.
	///</summary>
	/// <field name="Slide" type="Number" integer="true" static="true">Move only on the X axis.</field>
	/// <field name="Follow" type="Number" integer="true" static="true">Follow the mouse.</field>
}
$IG.HeaderDragStyle.prototype =
{
	/// <summary>
	/// Move only on the X axis.
	/// </summary>
	Slide: 0,

	/// <summary>
	/// Follow the mouse.
	/// </summary>
	Follow: 1

};
$IG.HeaderDragStyle.registerEnum("Infragistics.Web.UI.HeaderDragStyle");



$IG.TargetSide = function ()
{
	///<summary locid="T:J#Infragistics.Web.UI.TargetSide">
	/// The region that a column belongs to.
	///</summary>
	/// <field name="Left" type="Number" integer="true" static="true">On the left side of the header.</field>
	/// <field name="Right" type="Number" integer="true" static="true">On the right side of the header.</field>
}
$IG.TargetSide.prototype =
{
	/// <summary>
	/// On the left side of the header.
	/// </summary>
	Left: 0,

	/// <summary>
	/// On the right side of the header.
	/// </summary>
	Right: 1

};
$IG.TargetSide.registerEnum("Infragistics.Web.UI.TargetSide");

$IG.ColumnMovingProps = new function ()
{
	var DragStyle = [$IG.GridBehaviorProps.Count + 0, $IG.HeaderDragStyle.Slide];
	var count = $IG.GridBehaviorProps.Count + 1;

	this.Count = count;
};


